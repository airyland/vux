
  <template>
    <div class="component-box" :class="demos.length ? 'components-with-toc' : ''">

      <div :class="demos.length ? 'component-header-v2' : 'component-header-v1'">
        <a class="anchor" id="intro">Popup</a>
        <div class="title-box">

          <el-badge value="Beta" v-if="isBeta">
            <h1 class="vux-component-name">Popup</h1>
          </el-badge>
          <h1 v-else class="vux-component-name">Popup</h1>

          <p class="component-extra-links">
            <a href="https://vux.li/demos/v2/#/component/popup" target="_blank">demo url</a>
            <a v-if="!demos.length" href="https://github.com/airyland/vux/blob/v2/src/demos/Popup.vue" target="_blank" @click.prevent="showSourceCode">demo source code</a>
            <a href="https://github.com/airyland/vux/blob/v2/src/components/popup/metas.yml" target="_blank">edit document</a>
            <a href="https://github.com/airyland/vux/blob/v2/src/components/popup/" target="_blank">component source code</a>
            <el-popover trigger="hover" v-if="hasReady">
              <div style="width:100%;text-align:center;">
                <img class="qr" width="100" src="https://qr.vux.li/api.php?text=https%3A%2F%2Fvux.li%2Fdemos%2Fv2%2F%23%2Fcomponent%2Fpopup"/>
              </div>
              <a href="javascript:" slot="reference">
              view demos on mobile
              </a>
            </el-popover>
          </p>

          <div class="component-description">
            <template v-if="false">
            
            </template>
          </div>

        </div>

        <div v-if="!demos.length" class="component-demo" style="width:377px;height:600px;display:inline-block;border:1px solid #ececec;border-radius:5px;overflow:hidden;z-index:2500;">
          <iframe src="https://vux.li/demos/v2?locale=en&transition=none/#/component/popup" width="375" height="600" border="0" frameborder="0"></iframe>
        </div>
        <div class="toc">
          <ul v-for="t in toc">
            <li>
              <a :href="'#' + (t.anchor || t.title)">{{ t.title }}</a>
              <ul v-if="t.list" v-for="_t in t.list">
                <li><a :href="'#' + _t.anchor">{{ _t.title.slice(0, 12) }}</a></li>
              </ul>
            </li>
          </ul>
        </div>
      
        <template v-if="needImport">
          <a class="anchor" id="install">Install</a>
          <h2>Install</h2>
          <el-tabs>
            <el-tab-pane label="Local Registration">
              <div class="import-code-box">
              <el-tooltip content="click to copy" placement="top">
                <span
                  v-clipboard:copy="localImportCode"
                  v-clipboard:success="onCopy"
                  v-clipboard:error="onCopyError">
                  <el-icon class="el-icon-document"></el-icon>
                </span>
              </el-tooltip>
              <pre class="hljs"><code><span class="hljs-keyword">import</span> { Popup } <span class="hljs-keyword">from</span> <span class="hljs-string">'vux'</span>

<span class="hljs-keyword">export</span> <span class="hljs-keyword">default</span> {
  <span class="hljs-attr">components</span>: {
    Popup
  }
}</code></pre>
            </div>
            </el-tab-pane>
            <el-tab-pane label="Global Registration">
              <div class="import-code-box">
                <el-tooltip content="click to copy" placement="top">
                  <span
                    v-clipboard:copy="globalImportCode"
                    v-clipboard:success="onCopy"
                    v-clipboard:error="onCopyError">
                    <el-icon class="el-icon-document"></el-icon>
                  </span>
                </el-tooltip>
                <pre class="hljs"><code><span class="hljs-comment">// you can also register globally</span>

<span class="hljs-keyword">import</span> Vue <span class="hljs-keyword">from</span> <span class="hljs-string">'vue'</span>
<span class="hljs-keyword">import</span> { Popup } <span class="hljs-keyword">from</span> <span class="hljs-string">'vux'</span>

Vue.component(<span class="hljs-string">'popup'</span>, Popup)
</code></pre>
              </div> 
            </el-tab-pane>
          </el-tabs>   
        </template>

        <template v-else>
          <div class="tip">
            <p>You don't need to import this component.</p>
          </div>
        </template>

        <div class="tip" style="width:600px;" v-if="metas.tip">
          
        </div>
      
        <h2 v-if="metas.example">example</h2>
        <div v-if="metas.example" style="width:600px;">
          
        </div>
      </div>

      <div v-if="metas.extra && metas.extra['en']">
        
      </div>
      <div v-if="metas.extra && !metas.extra['en']">
        
      </div>
      
      <a v-if="demos.length" class="anchor" id="examples">Examples</a>
      <br/>
      <template v-if="demos.length" v-for="demo in demos">
        <a class="anchor" :id="'examples:' + demo.title">{{ demo.title }}</a>
        <br/>
        <div class="demo-header">
          <span class="demo-title">{{ demo.title }}</span>
        </div>
        <div class="demos" :style="{height: demo.height}">
          <div class="demo-iframe-box">
            <lazy-component>
              <iframe
                :src="domain + '?no-background-color=' + demo.noBackgroundColor +'&locale=en&transition=none&hide-nav=true&hide-tab-bar=true#/components/' + demo.file"
                width="375"
                height="600"
                border="0"
                frameborder="0"
                style="margin: 0 auto;"></iframe>
            </lazy-component>
          </div>
          <div class="demo-code-box" :style="{overflow: demo.height === demo.oriHeight ? 'hidden' : 'scroll'}">
            <div v-html="demo.code" contenteditable></div>
            <div v-if="demo.height === demo.oriHeight" class="demo-code-masker" @click="demo.height='auto'">
              <div>
                  <img class="demo-qr" width="100" :src="'https://qr.vux.li/api.php?text=' + encodeURIComponent(domain + '?locale=en#/components/' + demo.file)"/>
                  <br/>
                  <span>
                    <el-icon class="el-icon-arrow-left"/>
                    <el-icon class="el-icon-arrow-right"/>
                    Show code
                  <br/>
                  <!--<span class="demo-path">src/demos/{{ demo.file }}.vue</span>-->
                </span>
              </div>
            </div>
            <span v-if="demo.height === 'auto'" class="hide-code" @click="demo.height=demo.oriHeight">
              <el-icon class="el-icon-close"></el-icon>
            </span>
          </div>
        </div>
      </template>

      <template v-for="component in componentList">
        <div>
          <a v-if="componentList.length > 1" class="anchor" :id="'components:' + component.name">{{ component.name }}</a>
          <a v-else class="anchor" id="api">API</a>
          <br/>
          <h2
            v-show="componentList.length > 1"
            class="vux-component-name-sub-item">{{ component.name }}</h2>
            
          <template v-if="component.meta.items && component.meta.description">
            <div v-html="component.meta.description"></div>
          </template>

          <template v-if="component.meta.props">
            <h2>Props</h2>
            <table>
              <thead>
                <tr>
                  <td>name</td>
                  <td style="width:48px;">type</td>
                  <td>default</td>
                  <td>description</td>
                  <td>required version</td>
                </tr>
              </thead>
              <tbody>
                <tr v-for="(prop, i) in component.meta.props">
                  <td class="prop-name">
                    <el-tooltip content="click to copy" placement="left" :hide-after="0" :open-delay="50">
                      <span
                      v-clipboard:copy="i"
                      v-clipboard:success="onCopy">{{ i }}</span>
                    </el-tooltip>
                  </td>
                  <td v-html="getTypeHTML(prop.type)"></td>
                  <td>{{ prop.default}}</td>
                  <td v-html="prop['en'].replace(/`(.*?)`/g, '<code>$1</code>')"></td>
                  <td>{{ prop.version || '--'}}</td>
                </tr>
              </tbody>
            </table>
          </template>

          <template v-if="component.meta.events">
            <h2>Events</h2>
            <table>
              <thead>
                <tr>
                  <td>name</td>
                  <td>params</td>
                  <td>description</td>
                  <td>required version</td>
                </tr>
              </thead>
              <tbody>
                <tr v-for="(event, i) in component.meta.events">
                  <td class="prop-name">
                    <el-tooltip content="click to copy" placement="left" :hide-after="0" :open-delay="50">
                      <span
                      v-clipboard:copy="'@' + i"
                      v-clipboard:success="onCopy">@{{ i }}</span>
                    </el-tooltip>
                  </td>
                  <td v-html="event.params ? event.params.replace(/`(.*?)`/g, '<code>$1</code>') : '--'"></td>
                  <td v-html="event['en'] ? event['en'].replace(/`(.*?)`/g, '<code>$1</code>') : '--'"></td>
                  <td>{{ event['version'] || '--' }}</td>
                </tr>
              </tbody>
            </table>
          </template>
      

          <template v-if="component.meta.slots">
            <h2>Slots</h2>
            <table>
              <thead>
                <tr>
                  <td>name</td>
                  <td>description</td>
                  <td>required version</td>
                </tr>
              </thead>
              <tbody>
                <tr v-for="(slot, i) in component.meta.slots" :class="{'slot-disabled': slot['status'] === 'deprecated'}">
                  <td class="prop-name">
                    <el-tooltip content="click to copy" placement="left" :hide-after="0" :open-delay="50">
                      <span
                      v-clipboard:copy="i"
                      v-clipboard:success="onCopy">{{ i === 'default' ? 'default' : i }}</span>
                    </el-tooltip>
                  </td>
                  <td v-html="slot['en'] ? slot['en'].replace(/`(.*?)`/g, '<code>$1</code>') : ''"></td>
                  <td>{{ slot['version'] || '--' }}</td>
                </tr>
              </tbody>
            </table>
          </template>
          
          <template v-if="component.meta.methods">
            <h2>Functions</h2>
            <table>
              <thead>
                <tr>
                  <td>name</td>
                  <td>params</td>
                  <td>description</td>
                  <td>required version</td>
                </tr>
              </thead>
              <tbody>
                <tr v-for="(method, i) in component.meta.methods">
                  <td class="prop-name">
                    <el-tooltip content="click to copy" placement="left" :hide-after="0" :open-delay="50">
                      <span
                      v-clipboard:copy="i"
                      v-clipboard:success="onCopy">{{ i }}</span>
                    </el-tooltip>
                  </td>
                  <td v-html="method['params'] ? method['params'].replace(/`(.*?)`/g, '<code>$1</code>') : ''"></td>
                  <td v-html="method['en'].replace(/`(.*?)`/g, '<code>$1</code>')"></td>
                  <td>{{ method['version'] }}</td>
                </tr>
              </tbody>
            </table>
          </template>

          <template v-if="component.meta.variables">
            <a class="anchor" id="variables">Variables</a>
            <br/>
            <h2>Variables</h2>
            <table>
              <thead>
                <tr>
                  <td>name</td>
                  <td>default</td>
                  <td>description</td>
                  <td>inherited name</td>
                </tr>
              </thead>
              <tbody>
                <tr v-for="(variable, i) in component.meta.variables">
                  <td class="prop-name">
                    <el-tooltip content="click to copy" placement="left" :hide-after="0" :open-delay="50">
                      <span
                      v-clipboard:copy="'@' + variable.name"
                      v-clipboard:success="onCopy">@{{ variable.name }}</span>
                    </el-tooltip>
                  </td>
                  <td>
                    <em
                      :ref="'propColor' + i"
                      v-if="!$refs['propColor' + i] || ($refs['propColor' + i][0] && $refs['propColor' + i][0].style.backgroundColor)"
                      class="prop-color"
                      :style="{ backgroundColor: variable.value }">
                    </em>
                    {{ variable.value }}
                  </td>
                  <td>{{ variable['desc']['en'] || '--' }}</td>
                  <td>{{ variable.inherited_name }}</td>
                </tr>
              </tbody>
            </table>
          </template>
      
          <template v-if="component.meta.tips && component.meta.tips['en']">
            <a class="anchor" id="tips">Tips</a>
            <br>
            <h2>Tips</h2>
            <div>
              <ul>
                <li v-for="tip in component.meta.tips['en']">
                <el-tag size="mini" type="success" class="component-tip-tag">Q</el-tag> <span class="component-tip-question">{{ tip.q }}</span>
                <div v-html="tip.a" class="tip-answer-box"></div>
                </li>
              </ul>
            </div>
          </template>
        </div>
      </template>

      <!--<h2>社区相关讨论</h2>
      [即将上线]
      -->
    
      <br>
      <div v-if="issues.length">
        <a class="anchor" id="Issues">Issues</a>
        <br/>
        <h2>Related issues</h2>
        <ul>
          <li v-for="issue in issues"><a target="_blank" :href="issue.html_url">#{{ issue.number}} <span style="color:#666;">{{ issue.title }}</span></a></li>
        </ul>
      </div>
      <br>
    
      <div v-if="gitMetas">
        <a class="anchor" id="contributors">Contributors</a>
        <h2>Contributors</h2>
        <p>Total commits quantity: {{ gitMetas.commitCount }}，Total contributors quantity: {{gitMetas.commitUniqueCount}}
        </p>
        <a v-for="person in gitMetas.commitMembers" class="contributor-item" :href="'https://github.com/' + person.authorName" target="_blank" :title="'contribute' + person.count">{{person.authorName}}</a>
      </div>
      <br>

      <div v-if="metas.changes">
        <a class="anchor" id="changelog">Changelog</a>
        <br/>
        <h2>Releases</h2>
        <ul v-if="metas.changes">
          <template v-for="(changelog, version) in metas.changes">
            <li v-for="log in changelog['en']">
              <router-link :to="'/en/changelog/' + version + '.html'" class="changelog-version">{{version}}</router-link> {{log}}
            </li>
          </template>
        </ul>
      </div>

      <h2 v-if="metas.references">Referrences</h2>
      <ul v-if="metas.references">
        <li v-for="link in metas.references['en']">
          <a :href="link.link" target="_blank">{{link.title}}</a>
        </li>
      </ul>

      <el-dialog
        class="sourcec-code-dialog"
        top="0"
        width="80%"
        :visible.sync="sourceCodeDialogVisibility">
        <div class="code-box" contenteditable v-html="demoCode"></div>
      </el-dialog>

    </div>
  </template>


  <script>
  import Axios from 'axios'

  // const metas = require('json-loader!yaml-loader!../../../src/components/popup/metas.yml')
  const metas = {
  "category": {
    "en": "Feedback",
    "zh-CN": "弹窗提示"
  },
  "icon": "&#xe61e;",
  "tags": {
    "en": [
      "popup",
      "dialog"
    ],
    "zh-CN": [
      "弹窗"
    ]
  },
  "props": {
    "value": {
      "type": "Boolean",
      "en": "visibility of popup, use `v-model` for binding",
      "zh-CN": "是否关闭，使用`v-model`绑定"
    },
    "height": {
      "type": "String",
      "default": "auto",
      "en": "popup height, works when position is top or bottom",
      "zh-CN": "高度，设置`100%`为整屏高度。当 position 为 top 或者 bottom 时有效。"
    },
    "hide-on-blur": {
      "type": "Boolean",
      "default": true,
      "en": "if closing popup when mask being clicked",
      "zh-CN": "点击遮罩时是否自动关闭"
    },
    "is-transparent": {
      "version": "v2.1.1-rc.9",
      "type": "Boolean",
      "default": false,
      "en": "if using transparent background",
      "zh-CN": "是否为透明背景"
    },
    "width": {
      "version": "v2.2.1-rc.6",
      "type": "String",
      "default": "auto",
      "en": "if you want to set 100% width, you should use this prop. only works when position is left or right",
      "zh-CN": "设置 100% 宽度必须使用该属性。在 position 为 left 或者 right 时有效。"
    },
    "position": {
      "version": "v2.2.1-rc.6",
      "type": "String",
      "default": "bottom",
      "en": "popup position, shoule be one of ['left', 'right', 'top', 'bottom']",
      "zh-CN": "位置，可取值 ['left', 'right', 'top', 'bottom']"
    },
    "show-mask": {
      "version": "v2.2.1-rc.6",
      "type": "Boolean",
      "default": true,
      "en": "whether show mask",
      "zh-CN": "是否显示遮罩"
    },
    "popup-style": {
      "version": "v2.5.2",
      "type": "Object",
      "en": "popup style",
      "zh-CN": "弹窗样式，可以用于强制指定 z-index"
    },
    "hide-on-deactivated": {
      "version": "v2.5.5",
      "type": "Boolean",
      "default": true,
      "en": "whether hide popup on deactived event when using keep-alive",
      "zh-CN": "是否在 deactived 事件触发时自动关闭，避免在路由切换时依然显示弹窗"
    },
    "should-rerender-on-show": {
      "version": "v2.9.0",
      "type": "Boolean",
      "default": false,
      "en": "whether rerender body on show",
      "zh-CN": "是否在显示时重新渲染内容区域(以及滚动到顶部)，适用于每次显示弹窗需要重新获取数据初始化的场景"
    },
    "should-scroll-top-on-show": {
      "version": "v2.9.0",
      "type": "Boolean",
      "default": false,
      "en": "whether scroll top on show，add class vux-scrollable if you customize the scrollable div",
      "zh-CN": "是否在显示时自动滚动到顶部，当你自定义滚动容器时需要手动为该容器加上类名 vux-scrollable"
    }
  },
  "events": {
    "on-hide": {
      "en": "emits when then popup is closed",
      "zh-CN": "关闭时触发"
    },
    "on-show": {
      "en": "emits when the popup shows",
      "zh-CN": "显示时触发"
    },
    "on-first-show": {
      "en": "emits at the first time the popup shows",
      "zh-CN": "第一次显示时触发，可以在该事件回调里初始化数据或者界面"
    }
  },
  "slots": {
    "default": {
      "en": "content body",
      "zh-CN": "弹窗主体内容"
    }
  },
  "changes": {
    "v2.9.1": {
      "en": [
        "[fix] fixed popup has black border on the right #2651"
      ],
      "zh-CN": [
        "[fix] 修正弹出框右边有黑边 #2651"
      ]
    },
    "v2.9.0": {
      "en": [
        "[feature] support prop:should-rerender-on-show for forcing rerendering #2598",
        "[feature] support prop:should-scroll-top-on-show for forcing scrolling top #2598"
      ],
      "zh-CN": [
        "[feature] 支持 should-rerender-on-show 实现每次打开重新渲染 #2598",
        "[feature] 支持自动滚动到顶部 #2598"
      ]
    },
    "v2.5.12": {
      "en": [
        "[fix] clean vux-modal-open on beforeDestroy and deactivated #1921"
      ],
      "zh-CN": [
        "[fix] 在 beforeDestroy 和 deactivated 事件中清除设置于 body 上的 vux-modal-open 类名 #1921"
      ]
    },
    "v2.5.11": {
      "en": [
        "[fix] add vux-modal-open only when global config:$layout is VIEW_BOX #1893"
      ],
      "zh-CN": [
        "[fix] 仅在全局配置 $layout = VIEW_BOX 时用 fixed body 的形式阻止页面滚动 #1893"
      ]
    },
    "v2.5.10": {
      "en": [
        "[fix] Fix class helper typo issue #1893"
      ],
      "zh-CN": [
        "[fix] 修复 class 工具函数拼写错误 #1893"
      ]
    },
    "v2.5.9": {
      "en": [
        "[fix] Fix layout errors when body not set 100% width #1867"
      ],
      "zh-CN": [
        "[feature] 修复当body没有设置100%宽度时出现的布局错乱问题 #1867"
      ]
    },
    "v2.5.5": {
      "en": [
        "[feature] Auto hide popup on deactived #1774"
      ],
      "zh-CN": [
        "[feature] 在 deactived 事件触发时自动关闭，避免在路由切换时依然显示弹窗，可以使用 prop:hide-on-deactivated 进行禁用 #1774"
      ]
    },
    "v2.5.2": {
      "en": [
        "[feature] Add prop:popup-style #1656"
      ],
      "zh-CN": [
        "[feature] 支持弹窗样式设置 prop:popup-style #1656"
      ]
    },
    "v2.3.7": {
      "en": [
        "[fix] Fix missing mask when initial value is true #1555"
      ],
      "zh-CN": [
        "[fix] 修复默认值为 true 时遮罩没有显示的问题 #1555"
      ]
    },
    "v2.3.3": {
      "en": [
        "[enhance] Set max-height:100% by default",
        "[feature] Support prop:max-height",
        "[fix] disable mask scrolling on mobile #1475 @xiaobinhong1"
      ],
      "zh-CN": [
        "[enhance] 默认 max-height 设为 100%，避免不设置高度时内容过长无法滚动",
        "[feature] 支持 prop:max-height",
        "[fix] 禁止遮罩层在手机上滚动 #1475 @xiaobinhong1"
      ]
    },
    "v2.2.2": {
      "en": [
        "[fix] Fix mask closing issue in some situation. #1312"
      ],
      "zh-CN": [
        "[fix] 修复在某些情况下遮罩被错误关闭的问题 #1312"
      ]
    },
    "v2.2.1-rc.6": {
      "en": [
        "[fix] Fix popup classname get lost",
        "[feature] Support prop:show-mask",
        "[feature] Support prop:position",
        "[feature] Support prop:width"
      ],
      "zh-CN": [
        "[fix] 修复 popup 类名丢失问题",
        "[feature] 支持 prop:show-mask 隐藏遮罩",
        "[feature] 支持 prop:position 设定位置",
        "[feature] 支持 prop:width 设定左右位置时的宽度"
      ]
    },
    "v2.1.1-rc.11": {
      "en": [
        "[fix] Fix wrong overflowScrolling when mask is disabled"
      ],
      "zh-CN": [
        "[fix] 修复遮罩禁用点击时错误设置 overflowScrolling 的问题"
      ]
    },
    "v2.1.1-rc.9": {
      "en": [
        "[enhance] Better mask transition",
        "[feature] Support tranparent background",
        "[feature] Support less variable: @popup-background-color"
      ],
      "zh-CN": [
        "[enhance] 更流畅的遮罩层动画",
        "[feature] 支持透明背景",
        "[feature] 支持背影颜色变量 @popup-background-color"
      ]
    },
    "v2.1.1-rc.6": {
      "en": [
        "[fix] Fix wrong setting of overflow-scrolling when using multi popup on Safari #1015 @think2011"
      ],
      "zh-CN": [
        "[fix] 修复 Safari 上关闭第二个popup导致的问题 #1015 @think2011"
      ]
    },
    "v2.1.1-rc.1": {
      "en": [
        "[fix] Fix overflow-scrolling setting in safari #311 @linhaobin"
      ],
      "zh-CN": [
        "[fix] 修复 `overflow-scrolling` 设置逻辑遗漏问题 #311 @linhaobin"
      ]
    }
  },
  "variables": [
    {
      "name": "popup-picker-header-text-color",
      "value": "#04BE02",
      "is_inherited": true,
      "inherited_name": "@theme-color",
      "desc": {}
    },
    {
      "name": "popup-picker-header-bg-color",
      "value": "#fbf9fe",
      "is_inherited": false,
      "inherited_name": "",
      "desc": {}
    },
    {
      "name": "popup-picker-header-font-size",
      "value": "16px",
      "is_inherited": false,
      "inherited_name": "",
      "desc": {}
    },
    {
      "name": "popup-picker-header-cancel-text-color",
      "value": "#828282",
      "is_inherited": false,
      "inherited_name": "",
      "desc": {}
    },
    {
      "name": "popup-background-color",
      "value": "#eee",
      "is_inherited": false,
      "inherited_name": "",
      "desc": {}
    },
    {
      "name": "popup-header-height",
      "value": "44px",
      "is_inherited": false,
      "inherited_name": "",
      "desc": {}
    },
    {
      "name": "popup-header-bg-color",
      "value": "#fbf9fe",
      "is_inherited": false,
      "inherited_name": "",
      "desc": {}
    },
    {
      "name": "popup-header-font-size",
      "value": "16px",
      "is_inherited": false,
      "inherited_name": "",
      "desc": {}
    },
    {
      "name": "popup-header-left-text-color",
      "value": "#828282",
      "is_inherited": false,
      "inherited_name": "",
      "desc": {}
    },
    {
      "name": "popup-header-right-text-color",
      "value": "#04BE02",
      "is_inherited": true,
      "inherited_name": "@theme-color",
      "desc": {}
    },
    {
      "name": "popup-header-title-text-color",
      "value": "#222",
      "is_inherited": false,
      "inherited_name": "",
      "desc": {}
    },
    {
      "name": "popup-header-left-text-padding",
      "value": "15px",
      "is_inherited": false,
      "inherited_name": "",
      "desc": {}
    },
    {
      "name": "popup-header-right-text-padding",
      "value": "15px",
      "is_inherited": false,
      "inherited_name": "",
      "desc": {}
    }
  ]
}
  const demos = []

  let componentList = []
  if (Array.isArray(metas.items)) {
    try {
      metas.items.forEach((item, index) => {
        const meta = {
          name: item,
          meta: metas[item]
        }
        if (meta.meta.props === null) {
          delete meta.meta.props
        }
        if (index === metas.items.length - 1) {
          if (meta.meta) {
            meta.meta.variables = metas.variables
          }
        }
        componentList.push(meta)
      })
    } catch (e) {
      console.log(e)
    }
  } else {
    componentList.push({
      meta: metas
    })
  }
  const gitMetas = require('./popup_git_metas.json')
  const demoCode = decodeURIComponent(`%3Cpre%20class%3D%22hljs%22%3E%3Ccode%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Etemplate%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ediv%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Egroup%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ex-switch%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Etitle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22Default%20popup%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Ev-model%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22show%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ex-switch%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ex-switch%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Etitle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22Full%20popup%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Ev-model%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22show1%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ex-switch%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ex-switch%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Etitle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22Multi%20popup%20(first)%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Ev-model%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22show3%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ex-switch%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ex-switch%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Etitle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22Mask%20disable%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Ev-model%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22show5%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ex-switch%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ex-switch%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Etitle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22Popup%20address%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Ev-model%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22show6%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ex-switch%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ex-switch%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Etitle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22default%20max-height%3D100%25%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Ev-model%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22show12%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ex-switch%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ex-switch%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Etitle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22set%20max-height%3D50%25%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Ev-model%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22show13%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ex-switch%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Egroup%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Egroup%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ex-switch%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Etitle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22donot%20force%20rerender%20on%20open%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Ev-model%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22show15%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ex-switch%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ex-switch%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Etitle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22force%20rerender%20on%20open%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Ev-model%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22show14%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ex-switch%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Egroup%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Egroup%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ex-switch%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Etitle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22scroll%20top%20on%20show%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Einline-desc%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22default%20scrollable%20div%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Ev-model%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22show17%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ex-switch%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ex-switch%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Etitle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22scroll%20top%20on%20show%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Einline-desc%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22custom%20scrollable%20div%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Ev-model%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22show16%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ex-switch%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Egroup%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ediv%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Ev-transfer-dom%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Epopup%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Ev-model%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22show%22%3C%2Fspan%3E%20%40%3Cspan%20class%3D%22hljs-attr%22%3Eon-hide%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22log('hide')%22%3C%2Fspan%3E%20%40%3Cspan%20class%3D%22hljs-attr%22%3Eon-show%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22log('show')%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ediv%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Eclass%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22popup0%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Egroup%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ex-switch%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Etitle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22Another%20XSwitcher%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Ev-model%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22show%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ex-switch%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ex-switch%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Etitle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22Show%20Toast%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Ev-model%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22showToast%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ex-switch%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Egroup%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ediv%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Epopup%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ediv%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Etoast%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Ev-model%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22showToast%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3EYou%20did%20it!%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Etoast%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ediv%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Ev-transfer-dom%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Epopup%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Ev-model%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22show1%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Eheight%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22100%25%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ediv%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Eclass%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22popup1%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Egroup%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ex-switch%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Etitle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22Another%20XSwitcher%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Ev-model%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22show1%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ex-switch%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Egroup%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ediv%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Epopup%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ediv%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ediv%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Ev-transfer-dom%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Epopup%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Ev-model%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22show3%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ediv%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Eclass%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22popup2%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Egroup%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ex-switch%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Etitle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22Multi%20Popup%20(first)%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Ev-model%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22show3%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ex-switch%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ex-switch%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Etitle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22Multi%20Popup%20(second)%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Ev-model%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22show4%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ex-switch%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Egroup%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%20%20%20%20this%20is%20the%20first%20popup%0A%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ediv%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Epopup%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ediv%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ediv%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Ev-transfer-dom%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Epopup%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Ev-model%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22show4%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ediv%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Eclass%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22popup2%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Egroup%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ex-switch%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Etitle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22Multi%20Popup%20(second)%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Ev-model%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22show4%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ex-switch%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Egroup%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%20%20%20%20this%20is%20the%20second%20popup%0A%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ediv%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Epopup%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ediv%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ediv%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Ev-transfer-dom%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Epopup%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Ev-model%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22show5%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Ahide-on-blur%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3Efalse%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ediv%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Eclass%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22popup2%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Egroup%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ex-switch%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Etitle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22Mask%20disable%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Ev-model%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22show5%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ex-switch%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Egroup%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%20%20%20%20The%20mask%20cannot%20be%20clicked!%0A%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ediv%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Epopup%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ediv%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ediv%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Ev-transfer-dom%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Epopup%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Ev-model%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22show6%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ediv%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Eclass%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22popup1%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Egroup%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ex-switch%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Etitle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22Popup%20address%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Ev-model%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22show6%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ex-switch%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Egroup%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Egroup%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ex-address%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Atitle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22title6%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Ev-model%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22value6%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Alist%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22addressData%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Eplaceholder%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22%E8%AF%B7%E9%80%89%E6%8B%A9%E5%9C%B0%E5%9D%80%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Einline-desc%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22%E5%8F%AF%E4%BB%A5%E8%AE%BE%E7%BD%AEplaceholder%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Apopup-style%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22%7BzIndex%3A%20502%7D%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ex-address%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Egroup%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ediv%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Epopup%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ediv%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Egroup%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ex-switch%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Etitle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22transparent%20background%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Ev-model%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22show7%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ex-switch%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Egroup%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ediv%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Ev-transfer-dom%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Epopup%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Ev-model%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22show7%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Eheight%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22270px%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Eis-transparent%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ediv%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Estyle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22width%3A%2095%25%3Bbackground-color%3A%23fff%3Bheight%3A250px%3Bmargin%3A0%20auto%3Bborder-radius%3A5px%3Bpadding-top%3A10px%3B%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Egroup%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ecell%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Etitle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22Product%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Evalue%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22Donate%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ecell%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ecell%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Etitle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22Total%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Evalue%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22%2410.24%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ecell%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Egroup%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ediv%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Estyle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22padding%3A20px%2015px%3B%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ex-button%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Etype%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22primary%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3EPay%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ex-button%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ex-button%3C%2Fspan%3E%20%40%3Cspan%20class%3D%22hljs-attr%22%3Eclick.native%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22show7%20%3D%20false%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3ECancel%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ex-button%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ediv%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ediv%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Epopup%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ediv%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Egroup%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Etitle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22set%20position%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ex-switch%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Etitle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22left(100%25%20width)%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Ev-model%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22show8%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ex-switch%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ex-switch%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Etitle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22right%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Ev-model%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22show9%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ex-switch%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ex-switch%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Etitle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22top(no%20mask)%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Ev-model%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22show10%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ex-switch%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ex-switch%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Etitle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22bottom%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Ev-model%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22show11%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ex-switch%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Egroup%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ediv%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Ev-transfer-dom%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Epopup%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Ev-model%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22show8%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Eposition%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22left%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Ewidth%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22100%25%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ediv%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Eclass%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22position-horizontal-demo%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Espan%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Eclass%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22vux-close%22%3C%2Fspan%3E%20%40%3Cspan%20class%3D%22hljs-attr%22%3Eclick%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22show8%20%3D%20false%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Espan%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ediv%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Epopup%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ediv%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ediv%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Ev-transfer-dom%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Epopup%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Ev-model%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22show9%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Eposition%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22right%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ediv%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Estyle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22width%3A200px%3B%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ediv%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Epopup%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ediv%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ediv%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Ev-transfer-dom%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Epopup%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Ev-model%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22show10%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Eposition%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22top%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Ashow-mask%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22false%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ediv%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Eclass%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22position-vertical-demo%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%20%20I'm%20on%20top.%20Hide%20in%201s.%0A%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ediv%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Epopup%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ediv%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ediv%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Ev-transfer-dom%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Epopup%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Ev-model%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22show11%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Eposition%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22bottom%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ediv%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Eclass%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22position-vertical-demo%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%20%20I'm%20on%20bottom.%0A%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ediv%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Epopup%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ediv%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ediv%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Ev-transfer-dom%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Epopup%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Ev-model%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22show12%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Eposition%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22bottom%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Egroup%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ecell%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Ev-for%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22i%20in%2020%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Akey%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22i%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Atitle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22i%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ecell%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Egroup%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ediv%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Estyle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22padding%3A%2015px%3B%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ex-button%3C%2Fspan%3E%20%40%3Cspan%20class%3D%22hljs-attr%22%3Eclick.native%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22show12%20%3D%20false%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Eplain%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Etype%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22primary%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%20Close%20Me%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ex-button%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ediv%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Epopup%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ediv%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ediv%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Ev-transfer-dom%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Epopup%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Ev-model%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22show17%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Eposition%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22bottom%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Eshould-scroll-top-on-show%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Egroup%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ecell%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Ev-for%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22i%20in%2020%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Akey%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22i%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Atitle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22i%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ecell%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Egroup%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ediv%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Estyle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22padding%3A%2015px%3B%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ex-button%3C%2Fspan%3E%20%40%3Cspan%20class%3D%22hljs-attr%22%3Eclick.native%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22show17%20%3D%20false%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Eplain%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Etype%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22primary%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%20Close%20Me%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ex-button%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ediv%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Epopup%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ediv%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ediv%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Ev-transfer-dom%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Epopup%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Ev-model%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22show14%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Eposition%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22bottom%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Eshould-rerender-on-show%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ediv%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Etoggle-text%3C%2Fspan%3E%20%40%3Cspan%20class%3D%22hljs-attr%22%3Eclick.native%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22show14%20%3D%20false%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Etoggle-text%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ediv%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Epopup%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ediv%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ediv%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Ev-transfer-dom%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Epopup%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Ev-model%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22show15%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Eposition%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22bottom%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ediv%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Etoggle-text%3C%2Fspan%3E%20%40%3Cspan%20class%3D%22hljs-attr%22%3Eclick.native%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22show15%20%3D%20false%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Etoggle-text%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ediv%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Epopup%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ediv%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ediv%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Ev-transfer-dom%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Epopup%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Ev-model%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22show16%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Eposition%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22bottom%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Eshould-scroll-top-on-show%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Etoggle-text%3C%2Fspan%3E%20%40%3Cspan%20class%3D%22hljs-attr%22%3Eclick.native%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22show16%20%3D%20false%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Escrollable%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Eclass%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22vux-scrollable%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Etoggle-text%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Epopup%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ediv%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ediv%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Ev-transfer-dom%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Epopup%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Ev-model%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22show13%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Eposition%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22bottom%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Emax-height%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%2250%25%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Egroup%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ecell%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Ev-for%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22i%20in%2020%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Akey%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22i%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Atitle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22i%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ecell%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Egroup%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ediv%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Estyle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22padding%3A%2015px%3B%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ex-button%3C%2Fspan%3E%20%40%3Cspan%20class%3D%22hljs-attr%22%3Eclick.native%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22show13%20%3D%20false%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Eplain%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Etype%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22primary%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%20Close%20Me%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ex-button%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ediv%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Epopup%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ediv%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%0A%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ediv%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Etemplate%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%0A%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Escript%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22javascript%22%3E%0A%3Cspan%20class%3D%22hljs-keyword%22%3Eimport%3C%2Fspan%3E%20%7B%20TransferDom%2C%20Popup%2C%20Group%2C%20Cell%2C%20XButton%2C%20XSwitch%2C%20Toast%2C%20XAddress%2C%20ChinaAddressData%20%7D%20%3Cspan%20class%3D%22hljs-keyword%22%3Efrom%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-string%22%3E'vux'%3C%2Fspan%3E%0A%0A%3Cspan%20class%3D%22hljs-keyword%22%3Eimport%3C%2Fspan%3E%20ToggleText%20%3Cspan%20class%3D%22hljs-keyword%22%3Efrom%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-string%22%3E'.%2FToggleText'%3C%2Fspan%3E%0A%0A%3Cspan%20class%3D%22hljs-keyword%22%3Eexport%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-keyword%22%3Edefault%3C%2Fspan%3E%20%7B%0A%20%20%3Cspan%20class%3D%22hljs-attr%22%3Edirectives%3C%2Fspan%3E%3A%20%7B%0A%20%20%20%20TransferDom%0A%20%20%7D%2C%0A%20%20%3Cspan%20class%3D%22hljs-attr%22%3Ecomponents%3C%2Fspan%3E%3A%20%7B%0A%20%20%20%20Popup%2C%0A%20%20%20%20Group%2C%0A%20%20%20%20Cell%2C%0A%20%20%20%20XSwitch%2C%0A%20%20%20%20Toast%2C%0A%20%20%20%20XAddress%2C%0A%20%20%20%20XButton%2C%0A%20%20%20%20ToggleText%0A%20%20%7D%2C%0A%20%20data%20()%20%7B%0A%20%20%20%20%3Cspan%20class%3D%22hljs-keyword%22%3Ereturn%3C%2Fspan%3E%20%7B%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3EaddressData%3C%2Fspan%3E%3A%20ChinaAddressData%2C%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3Eshow%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-literal%22%3Efalse%3C%2Fspan%3E%2C%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3Eshow1%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-literal%22%3Efalse%3C%2Fspan%3E%2C%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3Eshow3%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-literal%22%3Efalse%3C%2Fspan%3E%2C%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3Eshow4%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-literal%22%3Efalse%3C%2Fspan%3E%2C%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3Eshow5%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-literal%22%3Efalse%3C%2Fspan%3E%2C%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3Eshow6%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-literal%22%3Efalse%3C%2Fspan%3E%2C%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3Etitle6%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-string%22%3E'%E9%BB%98%E8%AE%A4%E7%A9%BA%E7%9A%84'%3C%2Fspan%3E%2C%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3Evalue6%3C%2Fspan%3E%3A%20%5B%5D%2C%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3Eshow7%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-literal%22%3Efalse%3C%2Fspan%3E%2C%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3EshowToast%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-literal%22%3Efalse%3C%2Fspan%3E%2C%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3Eshow8%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-literal%22%3Efalse%3C%2Fspan%3E%2C%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3Eshow9%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-literal%22%3Efalse%3C%2Fspan%3E%2C%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3Eshow10%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-literal%22%3Efalse%3C%2Fspan%3E%2C%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3Eshow11%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-literal%22%3Efalse%3C%2Fspan%3E%2C%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3Eshow12%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-literal%22%3Efalse%3C%2Fspan%3E%2C%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3Eshow13%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-literal%22%3Efalse%3C%2Fspan%3E%2C%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3Eshow14%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-literal%22%3Efalse%3C%2Fspan%3E%2C%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3Eshow15%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-literal%22%3Efalse%3C%2Fspan%3E%2C%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3Eshow16%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-literal%22%3Efalse%3C%2Fspan%3E%2C%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3Eshow17%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-literal%22%3Efalse%3C%2Fspan%3E%0A%20%20%20%20%7D%0A%20%20%7D%2C%0A%20%20%3Cspan%20class%3D%22hljs-attr%22%3Emethods%3C%2Fspan%3E%3A%20%7B%0A%20%20%20%20log%20(str)%20%7B%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-built_in%22%3Econsole%3C%2Fspan%3E.log(str)%0A%20%20%20%20%7D%0A%20%20%7D%2C%0A%20%20%3Cspan%20class%3D%22hljs-attr%22%3Ewatch%3C%2Fspan%3E%3A%20%7B%0A%20%20%20%20show10%20(val)%20%7B%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-keyword%22%3Eif%3C%2Fspan%3E%20(val)%20%7B%0A%20%20%20%20%20%20%20%20setTimeout(%3Cspan%20class%3D%22hljs-function%22%3E%3Cspan%20class%3D%22hljs-params%22%3E()%3C%2Fspan%3E%20%3D%26gt%3B%3C%2Fspan%3E%20%7B%0A%20%20%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-keyword%22%3Ethis%3C%2Fspan%3E.show10%20%3D%20%3Cspan%20class%3D%22hljs-literal%22%3Efalse%3C%2Fspan%3E%0A%20%20%20%20%20%20%20%20%7D%2C%20%3Cspan%20class%3D%22hljs-number%22%3E1000%3C%2Fspan%3E)%0A%20%20%20%20%20%20%7D%0A%20%20%20%20%7D%0A%20%20%7D%0A%7D%0A%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Escript%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%0A%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Estyle%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Elang%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22less%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Escoped%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22undefined%22%3E%0A%40import%20'~vux%2Fsrc%2Fstyles%2Fclose.less'%3B%0A%0A.popup0%20%7B%0A%20%20padding-bottom%3A15px%3B%0A%20%20height%3A200px%3B%0A%7D%0A.popup1%20%7B%0A%20%20width%3A100%25%3B%0A%20%20height%3A100%25%3B%0A%7D%0A.popup2%20%7B%0A%20%20padding-bottom%3A15px%3B%0A%20%20height%3A400px%3B%0A%7D%0A.position-vertical-demo%20%7B%0A%20%20background-color%3A%20%23ffe26d%3B%0A%20%20color%3A%20%23000%3B%0A%20%20text-align%3A%20center%3B%0A%20%20padding%3A%2015px%3B%0A%7D%0A.position-horizontal-demo%20%7B%0A%20%20position%3A%20relative%3B%0A%20%20height%3A%20100%25%3B%0A%20%20.vux-close%20%7B%0A%20%20%20%20position%3A%20absolute%3B%0A%20%20%20%20top%3A%2050%25%3B%0A%20%20%20%20left%3A%2050%25%3B%0A%20%20%20%20transform%3A%20translateX(-50%25)%20translateY(-50%25)%20scale(4)%3B%0A%20%20%20%20color%3A%20%23000%3B%0A%20%20%7D%0A%7D%0A%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Estyle%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%3C%2Fcode%3E%3C%2Fpre%3E`)

  const domainMap = {
    'development': 'http://localhost:8080/',
    'production': 'https://vux.li/demos/v2/'
  }

  export default {
    head: {
      title: 'Popup component tutorial | VUX - Vue.js Mobile UI Component Framework',
      meta: [{
        name: 'description',
        content: 'Vue component popup for the VUX framework.'
      }, {
        name: 'keywords',
        content: 'popup, vue-popup, vux-popup, vue mobile components'
      }, {
        property: 'og:title',
        content: 'Popup component tutorial | VUX - Vue.js Mobile UI Component Framework'
      }, {
        property: 'og:description',
        content: 'Vue component popup for the VUX framework.'
      }],
      // https://support.google.com/webmasters/answer/189077?hl=en
      link: [{"rel":"alternate","hreflang":"zh-CN","href":"/zh-CN/components/popup.html"}],
      script: [
        {
          innerHTML:'{"@context":"http://schema.org/","@type":"SoftwareApplication","name":"Vue Component popup","screenshot":"","description":"Vue.js component for VUX","url":"/en/components/popup.html","applicationCategory":"Component","author":{"@type":"Organization","name":"VUX","url":"https://vux.li"},"downloadUrl":"https://vux.li","softwareVersion":"2.9.2","aggregateRating":{"@type":"AggregateRating","ratingValue":5,"reviewCount":52},"operatingSystem":"iOS >= 7, Android >= 4.1","offers":{"@type":"Offer","price":0,"priceCurrency":"USD","availability":"http://schema.org/InStock"}}',
          type: 'application/ld+json'
        }
      ],
      __dangerouslyDisableSanitizers: ['script']
    },
    filters: {
      parseCode (str) {
        return str.replace(/`(.*?)`/g, '<code>$1</code>')
      }
    },
    async mounted () {
      const rs = await Axios.get('https://api.github.com/search/issues?q=repo:airyland/vux%20label:component/' + this.componentName)
      this.issues = rs.data.items
      this.hasReady = true
    },
    watch: {
      async sourceCodeDialogVisibility (val) {
        if (val) {
          await this.$nextTick()
          const mask = document.querySelector('.v-modal')
          mask && mask.addEventListener('click', () => {
            this.sourceCodeDialogVisibility = false
          })
        }
      }
    },
    methods: {
      onCopyError () {
        this.$message({
          type: 'error',
          message: 'copy fail!'
        })
      },
      onCopy () {
        this.$message({
          type: 'success',
          message: 'copy done!'
        })
      },
      showSourceCode () {
        this.sourceCodeDialogVisibility = true
      },
      getTypeHTML (type) {
        type = type || 'String'
        if (/,/.test(type)) {
          const list = type.split(',').map(function (one) {
            return one.replace(/^s+|s+$/g, '')
          }).map(function (one) {
            const type = one ?  one.toLowerCase() : 'string'
            return '<span class="type">' + type + '</span>'
          })
          return list.join('<br>')
        } else {
          type = type ?  type.toLowerCase() : 'string'
          return '<span class="type">' + type + '</span>'
        }
      }
    },
    computed: {
      lang () {
        if (this.$route.path.indexOf('/en/') !== -1) {
          return 'en'
        }
        if (this.$route.path.indexOf('/zh-CN/') !== -1) {
          return 'zh-CN'
        }
        return 'en'
      }
    },
    data () {
      return {
        demos,
        isBeta: false,
        hasReady: false,
        issues: [],
        componentName: 'popup',
        demoCode,
        sourceCodeDialogVisibility: false,
        showQr: false,
        metas: metas,
        gitMetas,
        componentList,
        localImportCode: `import { Popup } from 'vux'

export default {
  components: {
    Popup
  }
}`,
        globalImportCode: `// you can also register globally

import Vue from 'vue'
import { Popup } from 'vux'

Vue.component('popup', Popup)
`,
        needImport: true,
        toc: [],
        domain: domainMap[process.env.NODE_ENV]
      }
    }
  }
  </script>

  <style>
  .component-box {
    position: relative;
  }
  .component-demo {
    position: absolute;
    right: 5px;
    top: 15px;
  }
  .prop-color {
    display: inline-block;
    width: 10px;
    height: 10px;
    border: 1px solid #aaa;
  }
  .changelog-version {
    width: 110px;
    display: inline-block;
  }
  .component-extra-links {
    position: relative;
    font-size: 12px;
  }
  .component-extra-links a {
    padding-right: 10px;
    color: #999;
  }
  </style>
    