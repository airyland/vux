
  <template>
    <div class="component-box" :class="demos.length ? 'components-with-toc' : ''">

      <div :class="demos.length ? 'component-header-v2' : 'component-header-v1'">
        <a class="anchor" id="intro">VChart</a>
        <div class="title-box">

          <el-badge value="Beta" v-if="isBeta">
            <h1 class="vux-component-name">VChart</h1>
          </el-badge>
          <h1 v-else class="vux-component-name">VChart</h1>

          <p class="component-extra-links">
            <a href="https://vux.li/demos/v2/#/components/v-chart/home" target="_blank">demo url</a>
            <a v-if="!demos.length" href="https://github.com/airyland/vux/blob/v2/src/demos/VChart.vue" target="_blank" @click.prevent="showSourceCode">demo source code</a>
            <a href="https://github.com/airyland/vux/blob/v2/src/components/v-chart/metas.yml" target="_blank">edit document</a>
            <a href="https://github.com/airyland/vux/blob/v2/src/components/v-chart/" target="_blank">component source code</a>
            <el-popover trigger="hover" v-if="hasReady">
              <div style="width:100%;text-align:center;">
                <img class="qr" width="100" src="https://qr.vux.li/api.php?text=https%3A%2F%2Fvux.li%2Fdemos%2Fv2%2F%23%2Fcomponents%2Fv-chart%2Fhome"/>
              </div>
              <a href="javascript:" slot="reference">
              view demos on mobile
              </a>
            </el-popover>
          </p>

          <div class="component-description">
            <template v-if="true">
            <p>VChart 基于<a href="https://antv.alipay.com/zh-cn/f2/3.x/">F2@蚂蚁金服(MIT license)</a>封装的图表组件。</p>
<p>F2 是专为移动端定制的一套开箱即用的可视化解决方案，具有精简、高性能、易扩展的特性，适用于对性能、大小、扩展性要求严苛的场景。</p>
<p>组件部分属性可能未列出，可以直接参考 <a href="https://antv.alipay.com/zh-cn/f2/3.x/api/index.html">F2文档</a></p>

            </template>
          </div>

        </div>

        <div v-if="!demos.length" class="component-demo" style="width:377px;height:600px;display:inline-block;border:1px solid #ececec;border-radius:5px;overflow:hidden;z-index:2500;">
          <iframe src="https://vux.li/demos/v2?locale=en&transition=none/#/component/v-chart" width="375" height="600" border="0" frameborder="0"></iframe>
        </div>
        <div class="toc">
          <ul v-for="t in toc">
            <li>
              <a :href="'#' + (t.anchor || t.title)">{{ t.title }}</a>
              <ul v-if="t.list" v-for="_t in t.list">
                <li><a :href="'#' + _t.anchor">{{ _t.title.slice(0, 12) }}</a></li>
              </ul>
            </li>
          </ul>
        </div>
      
        <template v-if="needImport">
          <a class="anchor" id="install">Install</a>
          <h2>Install</h2>
          <el-tabs>
            <el-tab-pane label="Local Registration">
              <div class="import-code-box">
              <el-tooltip content="click to copy" placement="top">
                <span
                  v-clipboard:copy="localImportCode"
                  v-clipboard:success="onCopy"
                  v-clipboard:error="onCopyError">
                  <el-icon class="el-icon-document"></el-icon>
                </span>
              </el-tooltip>
              <pre class="hljs"><code><span class="hljs-keyword">import</span> { VChart, VLine, VArea, VBar, VPie, VPoint, VScale, VAxis, VGuide, VTooltip, VLegend, VGuide } <span class="hljs-keyword">from</span> <span class="hljs-string">'vux'</span>

<span class="hljs-keyword">export</span> <span class="hljs-keyword">default</span> {
  <span class="hljs-attr">components</span>: {
    VChart,
    VLine,
    VArea,
    VBar,
    VPie,
    VPoint,
    VScale,
    VAxis,
    VGuide,
    VTooltip,
    VLegend,
    VGuide
  }
}</code></pre>
            </div>
            </el-tab-pane>
            <el-tab-pane label="Global Registration">
              <div class="import-code-box">
                <el-tooltip content="click to copy" placement="top">
                  <span
                    v-clipboard:copy="globalImportCode"
                    v-clipboard:success="onCopy"
                    v-clipboard:error="onCopyError">
                    <el-icon class="el-icon-document"></el-icon>
                  </span>
                </el-tooltip>
                <pre class="hljs"><code><span class="hljs-comment">// you can also register globally</span>

<span class="hljs-keyword">import</span> Vue <span class="hljs-keyword">from</span> <span class="hljs-string">'vue'</span>
<span class="hljs-keyword">import</span> { VChart, VLine, VArea, VBar, VPie, VPoint, VScale, VAxis, VGuide, VTooltip, VLegend, VGuide } <span class="hljs-keyword">from</span> <span class="hljs-string">'vux'</span>

Vue.component(<span class="hljs-string">'v-chart'</span>, VChart)
Vue.component(<span class="hljs-string">'v-line'</span>, VLine)
Vue.component(<span class="hljs-string">'v-area'</span>, VArea)
Vue.component(<span class="hljs-string">'v-bar'</span>, VBar)
Vue.component(<span class="hljs-string">'v-pie'</span>, VPie)
Vue.component(<span class="hljs-string">'v-point'</span>, VPoint)
Vue.component(<span class="hljs-string">'v-scale'</span>, VScale)
Vue.component(<span class="hljs-string">'v-axis'</span>, VAxis)
Vue.component(<span class="hljs-string">'v-guide'</span>, VGuide)
Vue.component(<span class="hljs-string">'v-tooltip'</span>, VTooltip)
Vue.component(<span class="hljs-string">'v-legend'</span>, VLegend)
Vue.component(<span class="hljs-string">'v-guide'</span>, VGuide)
</code></pre>
              </div> 
            </el-tab-pane>
          </el-tabs>   
        </template>

        <template v-else>
          <div class="tip">
            <p>You don't need to import this component.</p>
          </div>
        </template>

        <div class="tip" style="width:600px;" v-if="metas.tip">
          
        </div>
      
        <h2 v-if="metas.example">example</h2>
        <div v-if="metas.example" style="width:600px;">
          
        </div>
      </div>

      <div v-if="metas.extra && metas.extra['en']">
        
      </div>
      <div v-if="metas.extra && !metas.extra['en']">
        
      </div>
      
      <a v-if="demos.length" class="anchor" id="examples">Examples</a>
      <br/>
      <template v-if="demos.length" v-for="demo in demos">
        <a class="anchor" :id="'examples:' + demo.title">{{ demo.title }}</a>
        <br/>
        <div class="demo-header">
          <span class="demo-title">{{ demo.title }}</span>
        </div>
        <div class="demos" :style="{height: demo.height}">
          <div class="demo-iframe-box">
            <lazy-component>
              <iframe
                :src="domain + '?no-background-color=' + demo.noBackgroundColor +'&locale=en&transition=none&hide-nav=true&hide-tab-bar=true#/components/' + demo.file"
                width="375"
                height="600"
                border="0"
                frameborder="0"
                style="margin: 0 auto;"></iframe>
            </lazy-component>
          </div>
          <div class="demo-code-box" :style="{overflow: demo.height === demo.oriHeight ? 'hidden' : 'scroll'}">
            <div v-html="demo.code" contenteditable></div>
            <div v-if="demo.height === demo.oriHeight" class="demo-code-masker" @click="demo.height='auto'">
              <div>
                  <img class="demo-qr" width="100" :src="'https://qr.vux.li/api.php?text=' + encodeURIComponent(domain + '?locale=en#/components/' + demo.file)"/>
                  <br/>
                  <span>
                    <el-icon class="el-icon-arrow-left"/>
                    <el-icon class="el-icon-arrow-right"/>
                    Show code
                  <br/>
                  <!--<span class="demo-path">src/demos/{{ demo.file }}.vue</span>-->
                </span>
              </div>
            </div>
            <span v-if="demo.height === 'auto'" class="hide-code" @click="demo.height=demo.oriHeight">
              <el-icon class="el-icon-close"></el-icon>
            </span>
          </div>
        </div>
      </template>

      <template v-for="component in componentList">
        <div>
          <a v-if="componentList.length > 1" class="anchor" :id="'components:' + component.name">{{ component.name }}</a>
          <a v-else class="anchor" id="api">API</a>
          <br/>
          <h2
            v-show="componentList.length > 1"
            class="vux-component-name-sub-item">{{ component.name }}</h2>
            
          <template v-if="component.meta.items && component.meta.description">
            <div v-html="component.meta.description"></div>
          </template>

          <template v-if="component.meta.props">
            <h2>Props</h2>
            <table>
              <thead>
                <tr>
                  <td>name</td>
                  <td style="width:48px;">type</td>
                  <td>default</td>
                  <td>description</td>
                  <td>required version</td>
                </tr>
              </thead>
              <tbody>
                <tr v-for="(prop, i) in component.meta.props">
                  <td class="prop-name">
                    <el-tooltip content="click to copy" placement="left" :hide-after="0" :open-delay="50">
                      <span
                      v-clipboard:copy="i"
                      v-clipboard:success="onCopy">{{ i }}</span>
                    </el-tooltip>
                  </td>
                  <td v-html="getTypeHTML(prop.type)"></td>
                  <td>{{ prop.default}}</td>
                  <td v-html="prop['en'].replace(/`(.*?)`/g, '<code>$1</code>')"></td>
                  <td>{{ prop.version || '--'}}</td>
                </tr>
              </tbody>
            </table>
          </template>

          <template v-if="component.meta.events">
            <h2>Events</h2>
            <table>
              <thead>
                <tr>
                  <td>name</td>
                  <td>params</td>
                  <td>description</td>
                  <td>required version</td>
                </tr>
              </thead>
              <tbody>
                <tr v-for="(event, i) in component.meta.events">
                  <td class="prop-name">
                    <el-tooltip content="click to copy" placement="left" :hide-after="0" :open-delay="50">
                      <span
                      v-clipboard:copy="'@' + i"
                      v-clipboard:success="onCopy">@{{ i }}</span>
                    </el-tooltip>
                  </td>
                  <td v-html="event.params ? event.params.replace(/`(.*?)`/g, '<code>$1</code>') : '--'"></td>
                  <td v-html="event['en'] ? event['en'].replace(/`(.*?)`/g, '<code>$1</code>') : '--'"></td>
                  <td>{{ event['version'] || '--' }}</td>
                </tr>
              </tbody>
            </table>
          </template>
      

          <template v-if="component.meta.slots">
            <h2>Slots</h2>
            <table>
              <thead>
                <tr>
                  <td>name</td>
                  <td>description</td>
                  <td>required version</td>
                </tr>
              </thead>
              <tbody>
                <tr v-for="(slot, i) in component.meta.slots" :class="{'slot-disabled': slot['status'] === 'deprecated'}">
                  <td class="prop-name">
                    <el-tooltip content="click to copy" placement="left" :hide-after="0" :open-delay="50">
                      <span
                      v-clipboard:copy="i"
                      v-clipboard:success="onCopy">{{ i === 'default' ? 'default' : i }}</span>
                    </el-tooltip>
                  </td>
                  <td v-html="slot['en'] ? slot['en'].replace(/`(.*?)`/g, '<code>$1</code>') : ''"></td>
                  <td>{{ slot['version'] || '--' }}</td>
                </tr>
              </tbody>
            </table>
          </template>
          
          <template v-if="component.meta.methods">
            <h2>Functions</h2>
            <table>
              <thead>
                <tr>
                  <td>name</td>
                  <td>params</td>
                  <td>description</td>
                  <td>required version</td>
                </tr>
              </thead>
              <tbody>
                <tr v-for="(method, i) in component.meta.methods">
                  <td class="prop-name">
                    <el-tooltip content="click to copy" placement="left" :hide-after="0" :open-delay="50">
                      <span
                      v-clipboard:copy="i"
                      v-clipboard:success="onCopy">{{ i }}</span>
                    </el-tooltip>
                  </td>
                  <td v-html="method['params'] ? method['params'].replace(/`(.*?)`/g, '<code>$1</code>') : ''"></td>
                  <td v-html="method['en'].replace(/`(.*?)`/g, '<code>$1</code>')"></td>
                  <td>{{ method['version'] }}</td>
                </tr>
              </tbody>
            </table>
          </template>

          <template v-if="component.meta.variables">
            <a class="anchor" id="variables">Variables</a>
            <br/>
            <h2>Variables</h2>
            <table>
              <thead>
                <tr>
                  <td>name</td>
                  <td>default</td>
                  <td>description</td>
                  <td>inherited name</td>
                </tr>
              </thead>
              <tbody>
                <tr v-for="(variable, i) in component.meta.variables">
                  <td class="prop-name">
                    <el-tooltip content="click to copy" placement="left" :hide-after="0" :open-delay="50">
                      <span
                      v-clipboard:copy="'@' + variable.name"
                      v-clipboard:success="onCopy">@{{ variable.name }}</span>
                    </el-tooltip>
                  </td>
                  <td>
                    <em
                      :ref="'propColor' + i"
                      v-if="!$refs['propColor' + i] || ($refs['propColor' + i][0] && $refs['propColor' + i][0].style.backgroundColor)"
                      class="prop-color"
                      :style="{ backgroundColor: variable.value }">
                    </em>
                    {{ variable.value }}
                  </td>
                  <td>{{ variable['desc']['en'] || '--' }}</td>
                  <td>{{ variable.inherited_name }}</td>
                </tr>
              </tbody>
            </table>
          </template>
      
          <template v-if="component.meta.tips && component.meta.tips['en']">
            <a class="anchor" id="tips">Tips</a>
            <br>
            <h2>Tips</h2>
            <div>
              <ul>
                <li v-for="tip in component.meta.tips['en']">
                <el-tag size="mini" type="success" class="component-tip-tag">Q</el-tag> <span class="component-tip-question">{{ tip.q }}</span>
                <div v-html="tip.a" class="tip-answer-box"></div>
                </li>
              </ul>
            </div>
          </template>
        </div>
      </template>

      <!--<h2>社区相关讨论</h2>
      [即将上线]
      -->
    
      <br>
      <div v-if="issues.length">
        <a class="anchor" id="Issues">Issues</a>
        <br/>
        <h2>Related issues</h2>
        <ul>
          <li v-for="issue in issues"><a target="_blank" :href="issue.html_url">#{{ issue.number}} <span style="color:#666;">{{ issue.title }}</span></a></li>
        </ul>
      </div>
      <br>
    
      <div v-if="gitMetas">
        <a class="anchor" id="contributors">Contributors</a>
        <h2>Contributors</h2>
        <p>Total commits quantity: {{ gitMetas.commitCount }}，Total contributors quantity: {{gitMetas.commitUniqueCount}}
        </p>
        <a v-for="person in gitMetas.commitMembers" class="contributor-item" :href="'https://github.com/' + person.authorName" target="_blank" :title="'contribute' + person.count">{{person.authorName}}</a>
      </div>
      <br>

      <div v-if="metas.changes">
        <a class="anchor" id="changelog">Changelog</a>
        <br/>
        <h2>Releases</h2>
        <ul v-if="metas.changes">
          <template v-for="(changelog, version) in metas.changes">
            <li v-for="log in changelog['en']">
              <router-link :to="'/en/changelog/' + version + '.html'" class="changelog-version">{{version}}</router-link> {{log}}
            </li>
          </template>
        </ul>
      </div>

      <h2 v-if="metas.references">Referrences</h2>
      <ul v-if="metas.references">
        <li v-for="link in metas.references['en']">
          <a :href="link.link" target="_blank">{{link.title}}</a>
        </li>
      </ul>

      <el-dialog
        class="sourcec-code-dialog"
        top="0"
        width="80%"
        :visible.sync="sourceCodeDialogVisibility">
        <div class="code-box" contenteditable v-html="demoCode"></div>
      </el-dialog>

    </div>
  </template>


  <script>
  import Axios from 'axios'

  // const metas = require('json-loader!yaml-loader!../../../src/components/v-chart/metas.yml')
  const metas = {
  "icon": "&#xe663;",
  "category": {
    "en": "Chart",
    "zh-CN": "图表"
  },
  "beta": true,
  "description": "\nVChart 基于[F2@蚂蚁金服(MIT license)](https://antv.alipay.com/zh-cn/f2/3.x/)封装的图表组件。\n\nF2 是专为移动端定制的一套开箱即用的可视化解决方案，具有精简、高性能、易扩展的特性，适用于对性能、大小、扩展性要求严苛的场景。\n\n组件部分属性可能未列出，可以直接参考 [F2文档](https://antv.alipay.com/zh-cn/f2/3.x/api/index.html)\n",
  "changes": {
    "next": {
      "en": [
        "[enhance] v-point can set size and shape, v-line can set shape"
      ],
      "zh-CN": [
        "[enhance] v-point 可以设置size和shape, v-line 可以设置shape"
      ]
    }
  },
  "tips": {
    "zh-CN": [
      {
        "q": "全局设置分辨率(devicePixelRatio)",
        "a": "<pre class=\"hljs\"><code>\n<span class=\"hljs-comment\">// 入口文件处设置</span>\nVue.prototype.$devicePixelRatio = <span class=\"hljs-number\">2</span>\n\n</code></pre>\n"
      },
      {
        "q": "自定义渲染行为",
        "a": "<p>在面对复杂的渲染逻辑时，直接使用组件无法满足。此时可以这样处理：</p>\n<pre class=\"hljs\"><code>\n<span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">v-chart</span>\n  <span class=\"hljs-attr\">prevent-render</span>\n  @<span class=\"hljs-attr\">on-render</span>=<span class=\"hljs-string\">\"renderVChart\"</span>&gt;</span><span class=\"hljs-tag\">&lt;/<span class=\"hljs-name\">v-chart</span>&gt;</span>\n\n</code></pre>\n<pre class=\"hljs\"><code>\nmethods: {\n  renderVChart ({ chart }) {\n    <span class=\"hljs-comment\">// do what you want</span>\n  }\n}\n\n</code></pre>\n"
      },
      {
        "q": "修改子组件配置不会自动刷新",
        "a": "<p>是的，考虑到移动端更多是展示而不是操作，暂时不支持自动刷新。</p>\n"
      },
      {
        "q": "为什么我自己封装时会报错",
        "a": "<p>要先了解 Vue 组件的生命周期，在 canvas 元素未 mounted 前 F2 无法正确渲染。</p>\n<pre class=\"hljs\"><code>\nmounted () {\n  <span class=\"hljs-keyword\">this</span>.$nextTick(( =&gt; {\n    <span class=\"hljs-comment\">// do what you want with F2</span>\n  })\n}\n\n</code></pre>\n"
      }
    ]
  },
  "items": [
    "v-chart",
    "v-line",
    "v-area",
    "v-bar",
    "v-pie",
    "v-point",
    "v-scale",
    "v-axis",
    "v-guide",
    "v-tooltip",
    "v-legend",
    "v-guide"
  ],
  "v-chart": {
    "props": {
      "prevent-render": {
        "version": "v2.9.1",
        "type": "boolean",
        "default": false,
        "en": "whether prevent rendering",
        "zh-CN": "是否自定义渲染逻辑"
      },
      "prevent-default": {
        "version": "v2.9.1",
        "type": "boolean",
        "default": false,
        "en": "whether prevent default behavior",
        "zh-CN": "是否阻止默认行为"
      }
    },
    "events": {
      "on-render": {
        "version": "v2.9.1",
        "params": "`({ chart })`",
        "en": "fires before render",
        "zh-CN": "渲染前触发，一般用于配合 `prevent-render` 自定义渲染逻辑"
      }
    },
    "methods": {
      "rerender": {
        "version": "v2.9.1",
        "en": "destroy and re-render canvas",
        "zh-CN": "清除并重新渲染"
      },
      "repaint": {
        "version": "v2.9.1",
        "en": "repain canvas",
        "zh-CN": "重新渲染"
      },
      "destroy": {
        "version": "v2.9.1",
        "en": "destroy chart",
        "zh-CN": "销毁图表，canvas dom 元素不会销毁"
      }
    }
  },
  "v-point": {
    "description": "<p>点，用于点图的构建。Point 为 <code>Geometry</code> 的一部分，和其他图表组件一致，支持 shape, color, series-field 等。完整属性文档写参照 <a href=\"https://antv.alipay.com/zh-cn/f2/3.x/api/geometry.html\">F2 Geometry</a>。</p>\n",
    "props": null
  },
  "v-line": {
    "description": "<div class=\"tip\">\n<p>折线图，完整属性文档写参照 <a href=\"https://antv.alipay.com/zh-cn/f2/3.x/api/geometry.html\">F2 Geometry</a></p>\n</div>\n",
    "props": {
      "shape": {
        "version": "v2.9.1",
        "type": "String",
        "en": "shape type, one of `line`, `smooth`, `dash`",
        "zh-CN": "线条形状，可选值 `line`(默认), `smooth`(平滑线), `dash`(虚线)"
      },
      "series-field": {
        "version": "v2.9.1",
        "type": "String",
        "en": "alias to color, specify color value or which field to color",
        "zh-CN": "用于绘制多组线条时的分组字段名。该属性相当于 F2 里的 `color`，出于理解和设置方便使用 `series-field`"
      },
      "colors": {
        "version": "v2.9.1",
        "type": "String,Array",
        "en": "colors, use default colors if not specified",
        "zh-CN": "线条颜色，可以为单个颜色或者颜色列表。不指定时使用默认颜色。"
      }
    }
  },
  "v-guide": {
    "description": "<div class=\"tip\">\n<p>辅助元素，完整属性文档写参照 <a href=\"https://antv.alipay.com/zh-cn/f2/3.x/api/guide.html\">F2 Guide</a></p>\n</div>\n",
    "props": {
      "type": {
        "version": "v2.9.1",
        "type": "String",
        "en": "guide type, one of `line`, `text`, `tag`, `rect`, `html`, `arc`",
        "zh-CN": "辅助元素类型，可以为 `line`, `text`, `tag`, `rect`, `html`, `arc`"
      },
      "options": {
        "version": "v2.9.1",
        "type": "Object",
        "en": "guide options",
        "zh-CN": "辅助元素属性对象。你也可以在 template 里将属性分开写，不需要使用该 prop，同时使用时属性会被合并。"
      }
    },
    "tips": {
      "zh-CN": [
        {
          "q": "全局设置分辨率(devicePixelRatio)",
          "a": "<pre class=\"hljs\"><code>\n<span class=\"hljs-comment\">// 入口文件处设置</span>\nVue.prototype.$devicePixelRatio = <span class=\"hljs-number\">2</span>\n\n</code></pre>\n"
        },
        {
          "q": "自定义渲染行为",
          "a": "<p>在面对复杂的渲染逻辑时，直接使用组件无法满足。此时可以这样处理：</p>\n<pre class=\"hljs\"><code>\n<span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">v-chart</span>\n  <span class=\"hljs-attr\">prevent-render</span>\n  @<span class=\"hljs-attr\">on-render</span>=<span class=\"hljs-string\">\"renderVChart\"</span>&gt;</span><span class=\"hljs-tag\">&lt;/<span class=\"hljs-name\">v-chart</span>&gt;</span>\n\n</code></pre>\n<pre class=\"hljs\"><code>\nmethods: {\n  renderVChart ({ chart }) {\n    <span class=\"hljs-comment\">// do what you want</span>\n  }\n}\n\n</code></pre>\n"
        },
        {
          "q": "修改子组件配置不会自动刷新",
          "a": "<p>是的，考虑到移动端更多是展示而不是操作，暂时不支持自动刷新。</p>\n"
        },
        {
          "q": "为什么我自己封装时会报错",
          "a": "<p>要先了解 Vue 组件的生命周期，在 canvas 元素未 mounted 前 F2 无法正确渲染。</p>\n<pre class=\"hljs\"><code>\nmounted () {\n  <span class=\"hljs-keyword\">this</span>.$nextTick(( =&gt; {\n    <span class=\"hljs-comment\">// do what you want with F2</span>\n  })\n}\n\n</code></pre>\n"
        }
      ]
    }
  },
  "v-area": {
    "props": {
      "series-field": {
        "version": "v2.9.1",
        "type": "String",
        "en": "alias to color, specify color value or which field to color",
        "zh-CN": "用于绘制多组线条时的分组字段名。该属性相当于 F2 里的 `color`，出于理解和设置方便使用 `series-field`"
      },
      "colors": {
        "version": "v2.9.1",
        "type": "String,Array",
        "en": "colors, use default colors if not specified",
        "zh-CN": "线条颜色，可以为单个颜色或者颜色列表。不指定时使用默认颜色。"
      }
    }
  },
  "v-tooltip": {
    "description": "<div class=\"tip\">\n<p>该组件非必须，渲染折线图时会默认使用配置 <code>showCrosshairs: true</code></p>\n<p>完整属性文档写参照 <a href=\"https://antv.alipay.com/zh-cn/f2/3.x/api/tooltip.html\">F2 Tooltip</a></p>\n</div>\n",
    "props": {
      "disabled": {
        "version": "v2.9.1",
        "type": "boolean",
        "default": false,
        "en": "whether disable tooltip",
        "zh-CN": "[快捷属性，非 F2 原有属性]是否禁用 tooltip, 相当于调用`chart.tooltip(false)`"
      },
      "show-x-value": {
        "version": "v2.9.1",
        "type": "boolean",
        "default": false,
        "en": "whether set display template to `xValue:yValue`, default `xLabel:yValue`",
        "zh-CN": "[快捷属性，非 F2 原有属性]用于单折线的情况，设定是否将 x 轴值显示在 tooltip 里，默认是 `xLabel:yValue` 的形式(value:23)，启用将变成 `xValue:yValue` 的形式(2017-01-01:23)，建议在 `tickCount` 无法完全显示时启用。该设置会覆盖原有 `onShow` 设置。"
      },
      "show-value-in-legend": {
        "version": "v2.9.1",
        "type": "boolean",
        "default": false,
        "en": "whether hide default tooltip and show value in legend",
        "zh-CN": "[快捷属性，非 F2 原有属性]是否禁用默认 tooltip 而是显示在 legend 里。适用于有分组(series-field)情况。"
      }
    }
  },
  "v-legend": {
    "description": "<p>图例。<a href=\"https://antv.alipay.com/zh-cn/f2/3.x/api/legend.html\">F2 Legend</a>。</p>\n",
    "props": {
      "disabled": {
        "version": "v2.9.1",
        "type": "boolean",
        "default": false,
        "en": "whether disable tooltip",
        "zh-CN": "[快捷属性，非 F2 原有属性]是否禁用 legend, 相当于调用`chart.legend(false)`"
      }
    }
  },
  "v-bar": {
    "description": "<p>柱状图，使用垂直的柱子显示类别之间的数值比较。</p>\n",
    "props": {
      "colors": {
        "version": "v2.9.1",
        "type": "String,Array",
        "en": "colors, use default colors if not specified",
        "zh-CN": "线条颜色，可以为单个颜色或者颜色列表。不指定时使用默认颜色。"
      }
    }
  },
  "v-pie": {
    "props": null
  },
  "v-axis": {
    "description": "<p>坐标轴配置。<a href=\"https://antv.alipay.com/zh-cn/f2/3.x/api/axis.html\">详细文档</a>。</p>\n",
    "props": {
      "disabled": {
        "version": "v2.9.1",
        "type": "boolean",
        "zh-CN": "禁用当前坐标轴。"
      },
      "x": {
        "version": "v2.9.1",
        "type": "boolean",
        "zh-CN": "[组件属性]是否为 `x轴` 配置。"
      },
      "y": {
        "version": "v2.9.1",
        "type": "boolean",
        "zh-CN": "[组件属性]是否为 `y轴` 配置。"
      }
    }
  },
  "v-scale": {
    "description": "<p>度量 Scale，是数据空间到图形空间的转换桥梁，负责原始数据到 [0, 1] 区间数值的相互转换工作。针对不同的数据类型对应不同类型的度量。详细文档 <a href=\"https://antv.alipay.com/zh-cn/f2/3.x/api/scale.html\">F2 Scale</a>。</p>\n",
    "props": {
      "field": {
        "version": "v2.9.1",
        "type": "string",
        "zh-CN": "[组件属性]指定 `坐标轴` 字段。对于简单数据，VChart 可以判断使用哪个字段，但是如果顺序不确定或者多字段的数据，最好手动指定。"
      },
      "x": {
        "version": "v2.9.1",
        "type": "boolean",
        "zh-CN": "[组件属性]是否为 `x轴` 配置。"
      },
      "y": {
        "version": "v2.9.1",
        "type": "boolean",
        "zh-CN": "[组件属性]是否为 `y轴` 配置。"
      },
      "type": {
        "version": "v2.9.1",
        "type": "string",
        "zh-CN": "指定不同的度量类型，支持的 type 为 `identity`、`linear`、`cat`、`timeCat`。"
      },
      "formatter": {
        "version": "v2.9.1",
        "type": "function",
        "zh-CN": "回调函数，用于格式化坐标轴刻度点的文本显示，会影响数据在坐标轴 axis、图例 legend、提示信息 tooltip 上的显示。"
      },
      "range": {
        "version": "v2.9.1",
        "type": "array",
        "default": "[0, 1]",
        "zh-CN": "输出数据的范围，默认[0, 1]，格式为 [min, max]，min 和 max 均为 0 至 1 范围的数据。"
      },
      "alias": {
        "version": "v2.9.1",
        "type": "string",
        "zh-CN": "该数据字段的显示别名，一般用于将字段的英文名称转换成中文名(tooltip 中显示)。"
      },
      "tick-count": {
        "version": "v2.9.1",
        "type": "number",
        "default": 5,
        "zh-CN": "坐标轴上刻度点的个数，设为 0 时表示全部显示。"
      },
      "ticks": {
        "version": "v2.9.1",
        "type": "array",
        "zh-CN": "用于指定坐标轴上刻度点的文本信息，当用户设置了 ticks 就会按照 ticks 的个数和文本来显示。如 `[ 0, 50, 100, 150, 200, 300, 500 ]`"
      }
    }
  }
}
  const demos = [
  {
    "file": "v-chart/line_basic",
    "title": "基本折线图",
    "code": "<pre class=\"hljs\"><code><span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">template</span>&gt;</span>\n  <span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">div</span>&gt;</span>\n    <span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">v-chart</span> <span class=\"hljs-attr\">:data</span>=<span class=\"hljs-string\">\"data\"</span> <span class=\"hljs-attr\">prevent-default</span>&gt;</span>\n      <span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">v-scale</span> <span class=\"hljs-attr\">x</span> <span class=\"hljs-attr\">:tick-count</span>=<span class=\"hljs-string\">\"3\"</span> /&gt;</span>\n      <span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">v-tooltip</span> <span class=\"hljs-attr\">:show-item-marker</span>=<span class=\"hljs-string\">\"false\"</span> <span class=\"hljs-attr\">show-x-value</span> /&gt;</span>\n      <span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">v-line</span> /&gt;</span>\n    <span class=\"hljs-tag\">&lt;/<span class=\"hljs-name\">v-chart</span>&gt;</span>\n  <span class=\"hljs-tag\">&lt;/<span class=\"hljs-name\">div</span>&gt;</span>\n<span class=\"hljs-tag\">&lt;/<span class=\"hljs-name\">template</span>&gt;</span>\n\n<span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">script</span>&gt;</span><span class=\"javascript\">\n<span class=\"hljs-keyword\">import</span> { VChart, VTooltip, VLine, VScale } <span class=\"hljs-keyword\">from</span> <span class=\"hljs-string\">'vux'</span>\n\n<span class=\"hljs-keyword\">export</span> <span class=\"hljs-keyword\">default</span> {\n  <span class=\"hljs-attr\">components</span>: {\n    VChart,\n    VTooltip,\n    VLine,\n    VScale\n  },\n  data () {\n    <span class=\"hljs-keyword\">return</span> {\n      <span class=\"hljs-attr\">data</span>: [\n        { <span class=\"hljs-attr\">date</span>: <span class=\"hljs-string\">'2017-06-05'</span>, <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">116</span> },\n        { <span class=\"hljs-attr\">date</span>: <span class=\"hljs-string\">'2017-06-06'</span>, <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">129</span> },\n        { <span class=\"hljs-attr\">date</span>: <span class=\"hljs-string\">'2017-06-07'</span>, <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">135</span> },\n        { <span class=\"hljs-attr\">date</span>: <span class=\"hljs-string\">'2017-06-08'</span>, <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">86</span> },\n        { <span class=\"hljs-attr\">date</span>: <span class=\"hljs-string\">'2017-06-09'</span>, <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">73</span> },\n        { <span class=\"hljs-attr\">date</span>: <span class=\"hljs-string\">'2017-06-10'</span>, <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">85</span> },\n        { <span class=\"hljs-attr\">date</span>: <span class=\"hljs-string\">'2017-06-11'</span>, <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">73</span> },\n        { <span class=\"hljs-attr\">date</span>: <span class=\"hljs-string\">'2017-06-12'</span>, <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">68</span> },\n        { <span class=\"hljs-attr\">date</span>: <span class=\"hljs-string\">'2017-06-13'</span>, <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">92</span> },\n        { <span class=\"hljs-attr\">date</span>: <span class=\"hljs-string\">'2017-06-14'</span>, <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">130</span> },\n        { <span class=\"hljs-attr\">date</span>: <span class=\"hljs-string\">'2017-06-15'</span>, <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">245</span> },\n        { <span class=\"hljs-attr\">date</span>: <span class=\"hljs-string\">'2017-06-16'</span>, <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">139</span> },\n        { <span class=\"hljs-attr\">date</span>: <span class=\"hljs-string\">'2017-06-17'</span>, <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">115</span> },\n        { <span class=\"hljs-attr\">date</span>: <span class=\"hljs-string\">'2017-06-18'</span>, <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">111</span> },\n        { <span class=\"hljs-attr\">date</span>: <span class=\"hljs-string\">'2017-06-19'</span>, <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">309</span> },\n        { <span class=\"hljs-attr\">date</span>: <span class=\"hljs-string\">'2017-06-20'</span>, <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">206</span> },\n        { <span class=\"hljs-attr\">date</span>: <span class=\"hljs-string\">'2017-06-21'</span>, <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">137</span> },\n        { <span class=\"hljs-attr\">date</span>: <span class=\"hljs-string\">'2017-06-22'</span>, <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">128</span> },\n        { <span class=\"hljs-attr\">date</span>: <span class=\"hljs-string\">'2017-06-23'</span>, <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">85</span> },\n        { <span class=\"hljs-attr\">date</span>: <span class=\"hljs-string\">'2017-06-24'</span>, <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">94</span> },\n        { <span class=\"hljs-attr\">date</span>: <span class=\"hljs-string\">'2017-06-25'</span>, <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">71</span> },\n        { <span class=\"hljs-attr\">date</span>: <span class=\"hljs-string\">'2017-06-26'</span>, <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">106</span> },\n        { <span class=\"hljs-attr\">date</span>: <span class=\"hljs-string\">'2017-06-27'</span>, <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">84</span> },\n        { <span class=\"hljs-attr\">date</span>: <span class=\"hljs-string\">'2017-06-28'</span>, <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">93</span> },\n        { <span class=\"hljs-attr\">date</span>: <span class=\"hljs-string\">'2017-06-29'</span>, <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">85</span> },\n        { <span class=\"hljs-attr\">date</span>: <span class=\"hljs-string\">'2017-06-30'</span>, <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">73</span> },\n        { <span class=\"hljs-attr\">date</span>: <span class=\"hljs-string\">'2017-07-01'</span>, <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">83</span> },\n        { <span class=\"hljs-attr\">date</span>: <span class=\"hljs-string\">'2017-07-02'</span>, <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">125</span> },\n        { <span class=\"hljs-attr\">date</span>: <span class=\"hljs-string\">'2017-07-03'</span>, <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">107</span> },\n        { <span class=\"hljs-attr\">date</span>: <span class=\"hljs-string\">'2017-07-04'</span>, <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">82</span> },\n        { <span class=\"hljs-attr\">date</span>: <span class=\"hljs-string\">'2017-07-05'</span>, <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">44</span> },\n        { <span class=\"hljs-attr\">date</span>: <span class=\"hljs-string\">'2017-07-06'</span>, <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">72</span> },\n        { <span class=\"hljs-attr\">date</span>: <span class=\"hljs-string\">'2017-07-07'</span>, <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">106</span> },\n        { <span class=\"hljs-attr\">date</span>: <span class=\"hljs-string\">'2017-07-08'</span>, <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">107</span> },\n        { <span class=\"hljs-attr\">date</span>: <span class=\"hljs-string\">'2017-07-09'</span>, <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">66</span> },\n        { <span class=\"hljs-attr\">date</span>: <span class=\"hljs-string\">'2017-07-10'</span>, <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">91</span> },\n        { <span class=\"hljs-attr\">date</span>: <span class=\"hljs-string\">'2017-07-11'</span>, <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">92</span> },\n        { <span class=\"hljs-attr\">date</span>: <span class=\"hljs-string\">'2017-07-12'</span>, <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">113</span> },\n        { <span class=\"hljs-attr\">date</span>: <span class=\"hljs-string\">'2017-07-13'</span>, <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">107</span> },\n        { <span class=\"hljs-attr\">date</span>: <span class=\"hljs-string\">'2017-07-14'</span>, <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">131</span> },\n        { <span class=\"hljs-attr\">date</span>: <span class=\"hljs-string\">'2017-07-15'</span>, <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">111</span> },\n        { <span class=\"hljs-attr\">date</span>: <span class=\"hljs-string\">'2017-07-16'</span>, <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">64</span> },\n        { <span class=\"hljs-attr\">date</span>: <span class=\"hljs-string\">'2017-07-17'</span>, <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">69</span> },\n        { <span class=\"hljs-attr\">date</span>: <span class=\"hljs-string\">'2017-07-18'</span>, <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">88</span> },\n        { <span class=\"hljs-attr\">date</span>: <span class=\"hljs-string\">'2017-07-19'</span>, <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">77</span> },\n        { <span class=\"hljs-attr\">date</span>: <span class=\"hljs-string\">'2017-07-20'</span>, <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">83</span> },\n        { <span class=\"hljs-attr\">date</span>: <span class=\"hljs-string\">'2017-07-21'</span>, <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">111</span> },\n        { <span class=\"hljs-attr\">date</span>: <span class=\"hljs-string\">'2017-07-22'</span>, <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">57</span> },\n        { <span class=\"hljs-attr\">date</span>: <span class=\"hljs-string\">'2017-07-23'</span>, <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">55</span> },\n        { <span class=\"hljs-attr\">date</span>: <span class=\"hljs-string\">'2017-07-24'</span>, <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">60</span> }\n      ]\n    }\n  }\n}\n</span><span class=\"hljs-tag\">&lt;/<span class=\"hljs-name\">script</span>&gt;</span>\n\n\n</code></pre>",
    "oriHeight": "270px",
    "height": "270px",
    "noBackgroundColor": "true",
    "order": 1
  },
  {
    "file": "v-chart/line_smooth_with_dot",
    "title": "折线图:平滑曲线",
    "code": "<pre class=\"hljs\"><code><span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">template</span>&gt;</span>\n  <span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">div</span>&gt;</span>\n    <span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">v-chart</span> <span class=\"hljs-attr\">:data</span>=<span class=\"hljs-string\">\"data\"</span>&gt;</span>\n      <span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">v-scale</span> <span class=\"hljs-attr\">x</span> <span class=\"hljs-attr\">type</span>=<span class=\"hljs-string\">\"timeCat\"</span> <span class=\"hljs-attr\">mask</span>=<span class=\"hljs-string\">\"MM/DD\"</span> <span class=\"hljs-attr\">:tick-count</span>=<span class=\"hljs-string\">\"3\"</span> /&gt;</span>\n      <span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">v-scale</span> <span class=\"hljs-attr\">y</span> <span class=\"hljs-attr\">:min</span>=<span class=\"hljs-string\">\"0\"</span> <span class=\"hljs-attr\">alias</span>=<span class=\"hljs-string\">\"日均温度\"</span> <span class=\"hljs-attr\">:tick-count</span>=<span class=\"hljs-string\">\"5\"</span> /&gt;</span>\n      <span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">v-point</span>\n        <span class=\"hljs-attr\">:style</span>=<span class=\"hljs-string\">\"{\n          stroke: '#fff',\n          lineWidth: 1\n        }\"</span>\n        <span class=\"hljs-attr\">shape</span>=<span class=\"hljs-string\">\"smooth\"</span> /&gt;</span>\n      <span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">v-line</span> <span class=\"hljs-attr\">shape</span>=<span class=\"hljs-string\">\"smooth\"</span> /&gt;</span>\n    <span class=\"hljs-tag\">&lt;/<span class=\"hljs-name\">v-chart</span>&gt;</span>\n  <span class=\"hljs-tag\">&lt;/<span class=\"hljs-name\">div</span>&gt;</span>\n<span class=\"hljs-tag\">&lt;/<span class=\"hljs-name\">template</span>&gt;</span>\n\n<span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">script</span>&gt;</span><span class=\"javascript\">\n<span class=\"hljs-keyword\">import</span> { VChart, VLine, VPoint, VScale, VTooltip } <span class=\"hljs-keyword\">from</span> <span class=\"hljs-string\">'vux'</span>\n\n<span class=\"hljs-keyword\">export</span> <span class=\"hljs-keyword\">default</span> {\n  <span class=\"hljs-attr\">components</span>: {\n    VChart,\n    VPoint,\n    VLine,\n    VScale,\n    VTooltip\n  },\n  data () {\n    <span class=\"hljs-keyword\">return</span> {\n      <span class=\"hljs-attr\">data</span>: [\n        { <span class=\"hljs-attr\">time</span>: <span class=\"hljs-string\">'2016-08-08 00:00:00'</span>, <span class=\"hljs-attr\">tem</span>: <span class=\"hljs-number\">10</span> },\n        { <span class=\"hljs-attr\">time</span>: <span class=\"hljs-string\">'2016-08-08 00:10:00'</span>, <span class=\"hljs-attr\">tem</span>: <span class=\"hljs-number\">22</span> },\n        { <span class=\"hljs-attr\">time</span>: <span class=\"hljs-string\">'2016-08-08 00:30:00'</span>, <span class=\"hljs-attr\">tem</span>: <span class=\"hljs-number\">20</span> },\n        { <span class=\"hljs-attr\">time</span>: <span class=\"hljs-string\">'2016-08-09 00:35:00'</span>, <span class=\"hljs-attr\">tem</span>: <span class=\"hljs-number\">26</span> },\n        { <span class=\"hljs-attr\">time</span>: <span class=\"hljs-string\">'2016-08-09 01:00:00'</span>, <span class=\"hljs-attr\">tem</span>: <span class=\"hljs-number\">20</span> },\n        { <span class=\"hljs-attr\">time</span>: <span class=\"hljs-string\">'2016-08-09 01:20:00'</span>, <span class=\"hljs-attr\">tem</span>: <span class=\"hljs-number\">26</span> },\n        { <span class=\"hljs-attr\">time</span>: <span class=\"hljs-string\">'2016-08-10 01:40:00'</span>, <span class=\"hljs-attr\">tem</span>: <span class=\"hljs-number\">28</span> },\n        { <span class=\"hljs-attr\">time</span>: <span class=\"hljs-string\">'2016-08-10 02:00:00'</span>, <span class=\"hljs-attr\">tem</span>: <span class=\"hljs-number\">20</span> },\n        { <span class=\"hljs-attr\">time</span>: <span class=\"hljs-string\">'2016-08-10 02:20:00'</span>, <span class=\"hljs-attr\">tem</span>: <span class=\"hljs-number\">18</span> }\n      ]\n    }\n  }\n}\n</span><span class=\"hljs-tag\">&lt;/<span class=\"hljs-name\">script</span>&gt;</span>\n\n<span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">style</span> <span class=\"hljs-attr\">lang</span>=<span class=\"hljs-string\">'css'</span>&gt;</span><span class=\"undefined\">\n</span><span class=\"hljs-tag\">&lt;/<span class=\"hljs-name\">style</span>&gt;</span>\n\n\n</code></pre>",
    "oriHeight": "270px",
    "height": "270px",
    "noBackgroundColor": "true",
    "order": 1
  },
  {
    "file": "v-chart/line_realtime",
    "title": "动态数据：实时折线",
    "code": "<pre class=\"hljs\"><code><span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">template</span>&gt;</span>\n  <span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">div</span>&gt;</span>\n    <span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">v-chart</span> <span class=\"hljs-attr\">:data</span>=<span class=\"hljs-string\">\"data\"</span> <span class=\"hljs-attr\">ref</span>=<span class=\"hljs-string\">\"demo\"</span>&gt;</span>\n      <span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">v-scale</span> <span class=\"hljs-attr\">x</span> <span class=\"hljs-attr\">type</span>=<span class=\"hljs-string\">\"timeCat\"</span> <span class=\"hljs-attr\">:tick-count</span>=<span class=\"hljs-string\">\"3\"</span> <span class=\"hljs-attr\">mask</span>=<span class=\"hljs-string\">\"hh:mm:ss\"</span> /&gt;</span>\n      <span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">v-scale</span> <span class=\"hljs-attr\">y</span> <span class=\"hljs-attr\">:min</span>=<span class=\"hljs-string\">\"8\"</span> <span class=\"hljs-attr\">:tick-count</span>=<span class=\"hljs-string\">\"5\"</span> /&gt;</span>\n      <span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">v-tooltip</span> <span class=\"hljs-attr\">:show-item-marker</span>=<span class=\"hljs-string\">\"false\"</span> <span class=\"hljs-attr\">show-x-value</span> /&gt;</span>\n      <span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">v-guide</span> <span class=\"hljs-attr\">type</span>=<span class=\"hljs-string\">\"html\"</span> <span class=\"hljs-attr\">:options</span>=<span class=\"hljs-string\">\"guide1\"</span> /&gt;</span>\n      <span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">v-guide</span> <span class=\"hljs-attr\">type</span>=<span class=\"hljs-string\">\"html\"</span> <span class=\"hljs-attr\">:options</span>=<span class=\"hljs-string\">\"guide2\"</span> /&gt;</span>\n      <span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">v-line</span> /&gt;</span>\n    <span class=\"hljs-tag\">&lt;/<span class=\"hljs-name\">v-chart</span>&gt;</span>\n  <span class=\"hljs-tag\">&lt;/<span class=\"hljs-name\">div</span>&gt;</span>\n<span class=\"hljs-tag\">&lt;/<span class=\"hljs-name\">template</span>&gt;</span>\n\n<span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">script</span>&gt;</span><span class=\"javascript\">\n<span class=\"hljs-keyword\">import</span> { VChart, VTooltip, VLine, VScale, VGuide } <span class=\"hljs-keyword\">from</span> <span class=\"hljs-string\">'vux'</span>\n\n<span class=\"hljs-keyword\">const</span> data = []\n\n<span class=\"hljs-comment\">// 添加数据，模拟数据，可以指定当前时间的偏移的秒</span>\n<span class=\"hljs-function\"><span class=\"hljs-keyword\">function</span> <span class=\"hljs-title\">getRecord</span> (<span class=\"hljs-params\">offset</span>) </span>{\n  offset = offset || <span class=\"hljs-number\">0</span>\n  <span class=\"hljs-keyword\">return</span> {\n    <span class=\"hljs-attr\">time</span>: <span class=\"hljs-keyword\">new</span> <span class=\"hljs-built_in\">Date</span>().getTime() + offset * <span class=\"hljs-number\">1000</span>,\n    <span class=\"hljs-attr\">value</span>: <span class=\"hljs-built_in\">Math</span>.random() + <span class=\"hljs-number\">10</span>\n  }\n}\n\ndata.push(getRecord(<span class=\"hljs-number\">-2</span>))\ndata.push(getRecord(<span class=\"hljs-number\">-1</span>))\ndata.push(getRecord())\n\n<span class=\"hljs-keyword\">export</span> <span class=\"hljs-keyword\">default</span> {\n  <span class=\"hljs-attr\">components</span>: {\n    VChart,\n    VTooltip,\n    VLine,\n    VScale,\n    VGuide\n  },\n  mounted () {\n    <span class=\"hljs-keyword\">this</span>.timer = setInterval(<span class=\"hljs-function\"><span class=\"hljs-params\">()</span> =&gt;</span> {\n      data.push(getRecord())\n    }, <span class=\"hljs-number\">2000</span>)\n  },\n  beforeDestroy () {\n    clearInterval(<span class=\"hljs-keyword\">this</span>.timer)\n  },\n  data () {\n    <span class=\"hljs-keyword\">return</span> {\n      <span class=\"hljs-attr\">guide1</span>: {\n        position (xScale, yScales) {\n          <span class=\"hljs-keyword\">const</span> xValues = xScale.values\n          <span class=\"hljs-keyword\">const</span> yValues = yScales[<span class=\"hljs-number\">0</span>].values\n          <span class=\"hljs-keyword\">const</span> xMax = xValues[xValues.length - <span class=\"hljs-number\">1</span>]\n          <span class=\"hljs-keyword\">const</span> yMax = yValues[yValues.length - <span class=\"hljs-number\">1</span>]\n          <span class=\"hljs-keyword\">return</span> [ xMax, yMax ]\n        },\n        <span class=\"hljs-attr\">html</span>: <span class=\"hljs-string\">'&lt;div style=\"border-radius: 100%;border: none;width: 12px;height: 12px;background-color: rgb(24, 144, 255);transition: top 0.35s cubic-bezier(0.23, 1, 0.32, 1);\"&gt;&lt;/div&gt;'</span>\n      },\n      <span class=\"hljs-attr\">guide2</span>: {\n        position (xScale, yScales) {\n          <span class=\"hljs-keyword\">const</span> xValues = xScale.values\n          <span class=\"hljs-keyword\">const</span> yValues = yScales[<span class=\"hljs-number\">0</span>].values\n          <span class=\"hljs-keyword\">const</span> xMax = xValues[xValues.length - <span class=\"hljs-number\">1</span>]\n          <span class=\"hljs-keyword\">const</span> yMax = yValues[yValues.length - <span class=\"hljs-number\">1</span>]\n          <span class=\"hljs-keyword\">return</span> [ xMax, yMax ]\n        },\n        <span class=\"hljs-attr\">html</span>: <span class=\"hljs-string\">'&lt;div style=\"border-radius: 100%;border: none;width: 20px;height: 20px;background-color: rgba(24, 144, 255, 0.5);transition: top 0.35s cubic-bezier(0.23, 1, 0.32, 1);\"&gt;&lt;/div&gt;'</span>\n      },\n      data\n    }\n  }\n}\n</span><span class=\"hljs-tag\">&lt;/<span class=\"hljs-name\">script</span>&gt;</span>\n\n\n</code></pre>",
    "oriHeight": "270px",
    "height": "270px",
    "noBackgroundColor": "true",
    "order": 1
  },
  {
    "file": "v-chart/line_gradient",
    "title": "折线图：渐变",
    "code": "<pre class=\"hljs\"><code><span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">template</span>&gt;</span>\n  <span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">div</span>&gt;</span>\n    <span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">v-chart</span> <span class=\"hljs-attr\">:data</span>=<span class=\"hljs-string\">\"data\"</span>&gt;</span>\n      <span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">v-scale</span> <span class=\"hljs-attr\">x</span> <span class=\"hljs-attr\">:tick-count</span>=<span class=\"hljs-string\">\"5\"</span> <span class=\"hljs-attr\">:max</span>=<span class=\"hljs-string\">\"2020\"</span> /&gt;</span>\n      <span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">v-line</span> <span class=\"hljs-attr\">shape</span>=<span class=\"hljs-string\">\"smooth\"</span> <span class=\"hljs-attr\">:colors</span>=<span class=\"hljs-string\">\"gradient\"</span>/&gt;</span>\n      <span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">v-guide</span> <span class=\"hljs-attr\">type</span>=<span class=\"hljs-string\">\"tag\"</span> <span class=\"hljs-attr\">:options</span>=<span class=\"hljs-string\">\"tag\"</span> /&gt;</span>\n      <span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">v-area</span> <span class=\"hljs-attr\">shape</span>=<span class=\"hljs-string\">\"smooth\"</span> <span class=\"hljs-attr\">:colors</span>=<span class=\"hljs-string\">\"gradient\"</span>/&gt;</span>\n    <span class=\"hljs-tag\">&lt;/<span class=\"hljs-name\">v-chart</span>&gt;</span>\n  <span class=\"hljs-tag\">&lt;/<span class=\"hljs-name\">div</span>&gt;</span>\n<span class=\"hljs-tag\">&lt;/<span class=\"hljs-name\">template</span>&gt;</span>\n\n<span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">script</span>&gt;</span><span class=\"javascript\">\n<span class=\"hljs-keyword\">import</span> { VChart, VGuide, VLine, VArea, VScale } <span class=\"hljs-keyword\">from</span> <span class=\"hljs-string\">'vux'</span>\n\n<span class=\"hljs-keyword\">export</span> <span class=\"hljs-keyword\">default</span> {\n  <span class=\"hljs-attr\">components</span>: {\n    VChart,\n    VGuide,\n    VArea,\n    VLine,\n    VScale\n  },\n  data () {\n    <span class=\"hljs-keyword\">return</span> {\n      <span class=\"hljs-attr\">gradient</span>: [\n        [<span class=\"hljs-number\">0</span>, <span class=\"hljs-string\">'#F2C587'</span>],\n        [<span class=\"hljs-number\">0.5</span>, <span class=\"hljs-string\">'#ED7973'</span>],\n        [<span class=\"hljs-number\">1</span>, <span class=\"hljs-string\">'#8659AF'</span>]\n      ],\n      <span class=\"hljs-attr\">tag</span>: {\n        <span class=\"hljs-attr\">position</span>: [ <span class=\"hljs-number\">2017</span>, <span class=\"hljs-number\">30.12</span> ],\n        <span class=\"hljs-attr\">content</span>: <span class=\"hljs-string\">'30.12'</span>,\n        <span class=\"hljs-attr\">direct</span>: <span class=\"hljs-string\">'tl'</span>,\n        <span class=\"hljs-attr\">offsetY</span>: <span class=\"hljs-number\">-5</span>,\n        <span class=\"hljs-attr\">background</span>: {\n          <span class=\"hljs-attr\">fill</span>: <span class=\"hljs-string\">'#8659AF'</span>\n        },\n        <span class=\"hljs-attr\">pointStyle</span>: {\n          <span class=\"hljs-attr\">fill</span>: <span class=\"hljs-string\">'#8659AF'</span>\n        }\n      },\n      <span class=\"hljs-attr\">data</span>: [\n        { <span class=\"hljs-attr\">year</span>: <span class=\"hljs-number\">2000</span>, <span class=\"hljs-attr\">age</span>: <span class=\"hljs-number\">27.2</span> },\n        { <span class=\"hljs-attr\">year</span>: <span class=\"hljs-number\">2001</span>, <span class=\"hljs-attr\">age</span>: <span class=\"hljs-number\">27.5</span> },\n        { <span class=\"hljs-attr\">year</span>: <span class=\"hljs-number\">2002</span>, <span class=\"hljs-attr\">age</span>: <span class=\"hljs-number\">27.8</span> },\n        { <span class=\"hljs-attr\">year</span>: <span class=\"hljs-number\">2003</span>, <span class=\"hljs-attr\">age</span>: <span class=\"hljs-number\">28</span> },\n        { <span class=\"hljs-attr\">year</span>: <span class=\"hljs-number\">2004</span>, <span class=\"hljs-attr\">age</span>: <span class=\"hljs-number\">28.2</span> },\n        { <span class=\"hljs-attr\">year</span>: <span class=\"hljs-number\">2005</span>, <span class=\"hljs-attr\">age</span>: <span class=\"hljs-number\">28.4</span> },\n        { <span class=\"hljs-attr\">year</span>: <span class=\"hljs-number\">2006</span>, <span class=\"hljs-attr\">age</span>: <span class=\"hljs-number\">28.8</span> },\n        { <span class=\"hljs-attr\">year</span>: <span class=\"hljs-number\">2007</span>, <span class=\"hljs-attr\">age</span>: <span class=\"hljs-number\">28.8</span> },\n        { <span class=\"hljs-attr\">year</span>: <span class=\"hljs-number\">2008</span>, <span class=\"hljs-attr\">age</span>: <span class=\"hljs-number\">28.8</span> },\n        { <span class=\"hljs-attr\">year</span>: <span class=\"hljs-number\">2009</span>, <span class=\"hljs-attr\">age</span>: <span class=\"hljs-number\">28.8</span> },\n        { <span class=\"hljs-attr\">year</span>: <span class=\"hljs-number\">2010</span>, <span class=\"hljs-attr\">age</span>: <span class=\"hljs-number\">28.9</span> },\n        { <span class=\"hljs-attr\">year</span>: <span class=\"hljs-number\">2011</span>, <span class=\"hljs-attr\">age</span>: <span class=\"hljs-number\">29</span> },\n        { <span class=\"hljs-attr\">year</span>: <span class=\"hljs-number\">2012</span>, <span class=\"hljs-attr\">age</span>: <span class=\"hljs-number\">29.3</span> },\n        { <span class=\"hljs-attr\">year</span>: <span class=\"hljs-number\">2013</span>, <span class=\"hljs-attr\">age</span>: <span class=\"hljs-number\">29.4</span> },\n        { <span class=\"hljs-attr\">year</span>: <span class=\"hljs-number\">2014</span>, <span class=\"hljs-attr\">age</span>: <span class=\"hljs-number\">29.5</span> },\n        { <span class=\"hljs-attr\">year</span>: <span class=\"hljs-number\">2015</span>, <span class=\"hljs-attr\">age</span>: <span class=\"hljs-number\">29.7</span> },\n        { <span class=\"hljs-attr\">year</span>: <span class=\"hljs-number\">2016</span>, <span class=\"hljs-attr\">age</span>: <span class=\"hljs-number\">30</span> },\n        { <span class=\"hljs-attr\">year</span>: <span class=\"hljs-number\">2017</span>, <span class=\"hljs-attr\">age</span>: <span class=\"hljs-number\">30.12</span> }\n      ]\n    }\n  }\n}\n</span><span class=\"hljs-tag\">&lt;/<span class=\"hljs-name\">script</span>&gt;</span>\n\n\n</code></pre>",
    "oriHeight": "270px",
    "height": "270px",
    "noBackgroundColor": "true",
    "order": 1
  },
  {
    "file": "v-chart/line_color",
    "title": "折线图:对比",
    "code": "<pre class=\"hljs\"><code><span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">template</span>&gt;</span>\n  <span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">div</span>&gt;</span>\n    <span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">v-chart</span> <span class=\"hljs-attr\">:data</span>=<span class=\"hljs-string\">\"data\"</span>&gt;</span>\n      <span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">v-line</span> <span class=\"hljs-attr\">series-field</span>=<span class=\"hljs-string\">\"type\"</span> /&gt;</span>\n    <span class=\"hljs-tag\">&lt;/<span class=\"hljs-name\">v-chart</span>&gt;</span>\n  <span class=\"hljs-tag\">&lt;/<span class=\"hljs-name\">div</span>&gt;</span>\n<span class=\"hljs-tag\">&lt;/<span class=\"hljs-name\">template</span>&gt;</span>\n\n<span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">script</span>&gt;</span><span class=\"javascript\">\n<span class=\"hljs-keyword\">import</span> { VChart, VLine, VAxis, VTooltip } <span class=\"hljs-keyword\">from</span> <span class=\"hljs-string\">'vux'</span>\n\n<span class=\"hljs-comment\">/*\n* [\n*   {\"date\":\"2010-01-10\",\"type\":\"能源\",\"value\":99.9},\n*   {\"date\":\"2010-01-10\",\"type\":\"金属\",\"value\":96.6}\n* ]\n*/</span>\n<span class=\"hljs-keyword\">import</span> data <span class=\"hljs-keyword\">from</span> <span class=\"hljs-string\">'./line_color.json'</span>\n\n<span class=\"hljs-keyword\">export</span> <span class=\"hljs-keyword\">default</span> {\n  <span class=\"hljs-attr\">components</span>: {\n    VChart,\n    VLine,\n    VAxis,\n    VTooltip\n  },\n  data () {\n    <span class=\"hljs-keyword\">return</span> {\n      data\n    }\n  }\n}\n</span><span class=\"hljs-tag\">&lt;/<span class=\"hljs-name\">script</span>&gt;</span>\n\n</code></pre>",
    "oriHeight": "270px",
    "height": "270px",
    "noBackgroundColor": "true",
    "order": 1
  },
  {
    "file": "v-chart/line_with_dot",
    "title": "折线图：显示点",
    "code": "<pre class=\"hljs\"><code><span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">template</span>&gt;</span>\n  <span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">div</span>&gt;</span>\n    <span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">v-chart</span> <span class=\"hljs-attr\">:data</span>=<span class=\"hljs-string\">\"data\"</span>&gt;</span>\n      <span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">v-scale</span> <span class=\"hljs-attr\">y</span> <span class=\"hljs-attr\">:min</span>=<span class=\"hljs-string\">\"0\"</span> /&gt;</span> <span class=\"hljs-comment\">&lt;!-- 默认 y 轴数值从数据的最小值到最大值，此处重置为从 0 开始 --&gt;</span>\n      <span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">v-point</span> <span class=\"hljs-attr\">:styles</span>=<span class=\"hljs-string\">\"{\n        stroke: '#fff',\n        lineWidth: 1\n      }\"</span>/&gt;</span>\n      <span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">v-tooltip</span> <span class=\"hljs-attr\">:show-item-marker</span>=<span class=\"hljs-string\">\"false\"</span> <span class=\"hljs-attr\">:on-show</span>=<span class=\"hljs-string\">\"onShow\"</span> /&gt;</span> <span class=\"hljs-comment\">&lt;!-- onShow 为 F2 属性而非事件--&gt;</span>\n      <span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">v-line</span> /&gt;</span>\n    <span class=\"hljs-tag\">&lt;/<span class=\"hljs-name\">v-chart</span>&gt;</span>\n  <span class=\"hljs-tag\">&lt;/<span class=\"hljs-name\">div</span>&gt;</span>\n<span class=\"hljs-tag\">&lt;/<span class=\"hljs-name\">template</span>&gt;</span>\n\n<span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">script</span>&gt;</span><span class=\"javascript\">\n<span class=\"hljs-keyword\">import</span> { VChart, VPoint, VTooltip, VLine, VScale } <span class=\"hljs-keyword\">from</span> <span class=\"hljs-string\">'vux'</span>\n\n<span class=\"hljs-keyword\">export</span> <span class=\"hljs-keyword\">default</span> {\n  <span class=\"hljs-attr\">components</span>: {\n    VChart,\n    VPoint,\n    VTooltip,\n    VLine,\n    VScale\n  },\n  data () {\n    <span class=\"hljs-keyword\">return</span> {\n      onShow (ev) {\n        <span class=\"hljs-keyword\">const</span> { items } = ev\n        items[<span class=\"hljs-number\">0</span>].name = <span class=\"hljs-literal\">null</span>\n        items[<span class=\"hljs-number\">0</span>].value = <span class=\"hljs-string\">'$ '</span> + items[<span class=\"hljs-number\">0</span>].value\n      },\n      <span class=\"hljs-attr\">data</span>: [\n        { <span class=\"hljs-attr\">day</span>: <span class=\"hljs-string\">'周一'</span>, <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">300</span> },\n        { <span class=\"hljs-attr\">day</span>: <span class=\"hljs-string\">'周二'</span>, <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">400</span> },\n        { <span class=\"hljs-attr\">day</span>: <span class=\"hljs-string\">'周三'</span>, <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">350</span> },\n        { <span class=\"hljs-attr\">day</span>: <span class=\"hljs-string\">'周四'</span>, <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">500</span> },\n        { <span class=\"hljs-attr\">day</span>: <span class=\"hljs-string\">'周五'</span>, <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">490</span> },\n        { <span class=\"hljs-attr\">day</span>: <span class=\"hljs-string\">'周六'</span>, <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">600</span> },\n        { <span class=\"hljs-attr\">day</span>: <span class=\"hljs-string\">'周日'</span>, <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">900</span> }\n      ]\n    }\n  }\n}\n</span><span class=\"hljs-tag\">&lt;/<span class=\"hljs-name\">script</span>&gt;</span>\n\n<span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">style</span> <span class=\"hljs-attr\">lang</span>=<span class=\"hljs-string\">'css'</span>&gt;</span><span class=\"undefined\">\n</span><span class=\"hljs-tag\">&lt;/<span class=\"hljs-name\">style</span>&gt;</span>\n\n</code></pre>",
    "oriHeight": "270px",
    "height": "270px",
    "noBackgroundColor": "true",
    "order": 1
  },
  {
    "file": "v-chart/area_stack",
    "title": "层叠面积图",
    "code": "<pre class=\"hljs\"><code><span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">template</span>&gt;</span>\n  <span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">div</span>&gt;</span>\n    <span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">v-chart</span> <span class=\"hljs-attr\">:data</span>=<span class=\"hljs-string\">\"data\"</span>&gt;</span>\n      <span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">v-scale</span> <span class=\"hljs-attr\">x</span> <span class=\"hljs-attr\">field</span>=<span class=\"hljs-string\">\"date\"</span> <span class=\"hljs-attr\">type</span>=<span class=\"hljs-string\">\"timeCat\"</span> <span class=\"hljs-attr\">mask</span>=<span class=\"hljs-string\">\"MM-DD\"</span> /&gt;</span>\n      <span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">v-scale</span> <span class=\"hljs-attr\">y</span> <span class=\"hljs-attr\">field</span>=<span class=\"hljs-string\">\"value\"</span> <span class=\"hljs-attr\">:tick-count</span>=<span class=\"hljs-string\">\"4\"</span> <span class=\"hljs-attr\">:max</span>=<span class=\"hljs-string\">\"300\"</span> /&gt;</span>\n      <span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">v-tooltip</span> <span class=\"hljs-attr\">show-crosshairs</span> <span class=\"hljs-attr\">show-value-in-legend</span> /&gt;</span>\n\n      <span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">v-area</span> <span class=\"hljs-attr\">series-field</span>=<span class=\"hljs-string\">\"city\"</span> <span class=\"hljs-attr\">shape</span>=<span class=\"hljs-string\">\"smooth\"</span> <span class=\"hljs-attr\">adjust</span>=<span class=\"hljs-string\">\"stack\"</span> /&gt;</span>\n      <span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">v-line</span> <span class=\"hljs-attr\">series-field</span>=<span class=\"hljs-string\">\"city\"</span> <span class=\"hljs-attr\">shape</span>=<span class=\"hljs-string\">\"smooth\"</span> <span class=\"hljs-attr\">adjust</span>=<span class=\"hljs-string\">\"stack\"</span> /&gt;</span>\n    <span class=\"hljs-tag\">&lt;/<span class=\"hljs-name\">v-chart</span>&gt;</span>\n  <span class=\"hljs-tag\">&lt;/<span class=\"hljs-name\">div</span>&gt;</span>\n<span class=\"hljs-tag\">&lt;/<span class=\"hljs-name\">template</span>&gt;</span>\n\n<span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">script</span>&gt;</span><span class=\"javascript\">\n<span class=\"hljs-keyword\">import</span> { VChart, VLine, VArea, VTooltip, VLegend, VScale } <span class=\"hljs-keyword\">from</span> <span class=\"hljs-string\">'vux'</span>\n\n<span class=\"hljs-keyword\">export</span> <span class=\"hljs-keyword\">default</span> {\n  <span class=\"hljs-attr\">components</span>: {\n    VChart,\n    VLine,\n    VArea,\n    VTooltip,\n    VLegend,\n    VScale\n  },\n  data () {\n    <span class=\"hljs-keyword\">return</span> {\n      <span class=\"hljs-attr\">data</span>: [\n        { <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">63.4</span>, <span class=\"hljs-attr\">city</span>: <span class=\"hljs-string\">'New York'</span>, <span class=\"hljs-attr\">date</span>: <span class=\"hljs-string\">'2011-10-01'</span> },\n        { <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">62.7</span>, <span class=\"hljs-attr\">city</span>: <span class=\"hljs-string\">'Alaska'</span>, <span class=\"hljs-attr\">date</span>: <span class=\"hljs-string\">'2011-10-01'</span> },\n        { <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">72.2</span>, <span class=\"hljs-attr\">city</span>: <span class=\"hljs-string\">'Austin'</span>, <span class=\"hljs-attr\">date</span>: <span class=\"hljs-string\">'2011-10-01'</span> },\n        { <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">58</span>, <span class=\"hljs-attr\">city</span>: <span class=\"hljs-string\">'New York'</span>, <span class=\"hljs-attr\">date</span>: <span class=\"hljs-string\">'2011-10-02'</span> },\n        { <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">59.9</span>, <span class=\"hljs-attr\">city</span>: <span class=\"hljs-string\">'Alaska'</span>, <span class=\"hljs-attr\">date</span>: <span class=\"hljs-string\">'2011-10-02'</span> },\n        { <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">67.7</span>, <span class=\"hljs-attr\">city</span>: <span class=\"hljs-string\">'Austin'</span>, <span class=\"hljs-attr\">date</span>: <span class=\"hljs-string\">'2011-10-02'</span> },\n        { <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">53.3</span>, <span class=\"hljs-attr\">city</span>: <span class=\"hljs-string\">'New York'</span>, <span class=\"hljs-attr\">date</span>: <span class=\"hljs-string\">'2011-10-03'</span> },\n        { <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">59.1</span>, <span class=\"hljs-attr\">city</span>: <span class=\"hljs-string\">'Alaska'</span>, <span class=\"hljs-attr\">date</span>: <span class=\"hljs-string\">'2011-10-03'</span> },\n        { <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">69.4</span>, <span class=\"hljs-attr\">city</span>: <span class=\"hljs-string\">'Austin'</span>, <span class=\"hljs-attr\">date</span>: <span class=\"hljs-string\">'2011-10-03'</span> },\n        { <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">55.7</span>, <span class=\"hljs-attr\">city</span>: <span class=\"hljs-string\">'New York'</span>, <span class=\"hljs-attr\">date</span>: <span class=\"hljs-string\">'2011-10-04'</span> },\n        { <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">58.8</span>, <span class=\"hljs-attr\">city</span>: <span class=\"hljs-string\">'Alaska'</span>, <span class=\"hljs-attr\">date</span>: <span class=\"hljs-string\">'2011-10-04'</span> },\n        { <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">68</span>, <span class=\"hljs-attr\">city</span>: <span class=\"hljs-string\">'Austin'</span>, <span class=\"hljs-attr\">date</span>: <span class=\"hljs-string\">'2011-10-04'</span> },\n        { <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">64.2</span>, <span class=\"hljs-attr\">city</span>: <span class=\"hljs-string\">'New York'</span>, <span class=\"hljs-attr\">date</span>: <span class=\"hljs-string\">'2011-10-05'</span> },\n        { <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">58.7</span>, <span class=\"hljs-attr\">city</span>: <span class=\"hljs-string\">'Alaska'</span>, <span class=\"hljs-attr\">date</span>: <span class=\"hljs-string\">'2011-10-05'</span> },\n        { <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">72.4</span>, <span class=\"hljs-attr\">city</span>: <span class=\"hljs-string\">'Austin'</span>, <span class=\"hljs-attr\">date</span>: <span class=\"hljs-string\">'2011-10-05'</span> },\n        { <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">58.8</span>, <span class=\"hljs-attr\">city</span>: <span class=\"hljs-string\">'New York'</span>, <span class=\"hljs-attr\">date</span>: <span class=\"hljs-string\">'2011-10-06'</span> },\n        { <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">57</span>, <span class=\"hljs-attr\">city</span>: <span class=\"hljs-string\">'Alaska'</span>, <span class=\"hljs-attr\">date</span>: <span class=\"hljs-string\">'2011-10-06'</span> },\n        { <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">77</span>, <span class=\"hljs-attr\">city</span>: <span class=\"hljs-string\">'Austin'</span>, <span class=\"hljs-attr\">date</span>: <span class=\"hljs-string\">'2011-10-06'</span> },\n        { <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">57.9</span>, <span class=\"hljs-attr\">city</span>: <span class=\"hljs-string\">'New York'</span>, <span class=\"hljs-attr\">date</span>: <span class=\"hljs-string\">'2011-10-07'</span> },\n        { <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">56.7</span>, <span class=\"hljs-attr\">city</span>: <span class=\"hljs-string\">'Alaska'</span>, <span class=\"hljs-attr\">date</span>: <span class=\"hljs-string\">'2011-10-07'</span> },\n        { <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">82.3</span>, <span class=\"hljs-attr\">city</span>: <span class=\"hljs-string\">'Austin'</span>, <span class=\"hljs-attr\">date</span>: <span class=\"hljs-string\">'2011-10-07'</span> },\n        { <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">61.8</span>, <span class=\"hljs-attr\">city</span>: <span class=\"hljs-string\">'New York'</span>, <span class=\"hljs-attr\">date</span>: <span class=\"hljs-string\">'2011-10-08'</span> },\n        { <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">56.8</span>, <span class=\"hljs-attr\">city</span>: <span class=\"hljs-string\">'Alaska'</span>, <span class=\"hljs-attr\">date</span>: <span class=\"hljs-string\">'2011-10-08'</span> },\n        { <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">78.9</span>, <span class=\"hljs-attr\">city</span>: <span class=\"hljs-string\">'Austin'</span>, <span class=\"hljs-attr\">date</span>: <span class=\"hljs-string\">'2011-10-08'</span> },\n        { <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">69.3</span>, <span class=\"hljs-attr\">city</span>: <span class=\"hljs-string\">'New York'</span>, <span class=\"hljs-attr\">date</span>: <span class=\"hljs-string\">'2011-10-09'</span> },\n        { <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">56.7</span>, <span class=\"hljs-attr\">city</span>: <span class=\"hljs-string\">'Alaska'</span>, <span class=\"hljs-attr\">date</span>: <span class=\"hljs-string\">'2011-10-09'</span> },\n        { <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">68.8</span>, <span class=\"hljs-attr\">city</span>: <span class=\"hljs-string\">'Austin'</span>, <span class=\"hljs-attr\">date</span>: <span class=\"hljs-string\">'2011-10-09'</span> },\n        { <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">71.2</span>, <span class=\"hljs-attr\">city</span>: <span class=\"hljs-string\">'New York'</span>, <span class=\"hljs-attr\">date</span>: <span class=\"hljs-string\">'2011-10-10'</span> },\n        { <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">60.1</span>, <span class=\"hljs-attr\">city</span>: <span class=\"hljs-string\">'Alaska'</span>, <span class=\"hljs-attr\">date</span>: <span class=\"hljs-string\">'2011-10-10'</span> },\n        { <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">68.7</span>, <span class=\"hljs-attr\">city</span>: <span class=\"hljs-string\">'Austin'</span>, <span class=\"hljs-attr\">date</span>: <span class=\"hljs-string\">'2011-10-10'</span> },\n        { <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">68.7</span>, <span class=\"hljs-attr\">city</span>: <span class=\"hljs-string\">'New York'</span>, <span class=\"hljs-attr\">date</span>: <span class=\"hljs-string\">'2011-10-11'</span> },\n        { <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">61.1</span>, <span class=\"hljs-attr\">city</span>: <span class=\"hljs-string\">'Alaska'</span>, <span class=\"hljs-attr\">date</span>: <span class=\"hljs-string\">'2011-10-11'</span> },\n        { <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">70.3</span>, <span class=\"hljs-attr\">city</span>: <span class=\"hljs-string\">'Austin'</span>, <span class=\"hljs-attr\">date</span>: <span class=\"hljs-string\">'2011-10-11'</span> },\n        { <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">61.8</span>, <span class=\"hljs-attr\">city</span>: <span class=\"hljs-string\">'New York'</span>, <span class=\"hljs-attr\">date</span>: <span class=\"hljs-string\">'2011-10-12'</span> },\n        { <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">61.5</span>, <span class=\"hljs-attr\">city</span>: <span class=\"hljs-string\">'Alaska'</span>, <span class=\"hljs-attr\">date</span>: <span class=\"hljs-string\">'2011-10-12'</span> },\n        { <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">75.3</span>, <span class=\"hljs-attr\">city</span>: <span class=\"hljs-string\">'Austin'</span>, <span class=\"hljs-attr\">date</span>: <span class=\"hljs-string\">'2011-10-12'</span> },\n        { <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">63</span>, <span class=\"hljs-attr\">city</span>: <span class=\"hljs-string\">'New York'</span>, <span class=\"hljs-attr\">date</span>: <span class=\"hljs-string\">'2011-10-13'</span> },\n        { <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">64.3</span>, <span class=\"hljs-attr\">city</span>: <span class=\"hljs-string\">'Alaska'</span>, <span class=\"hljs-attr\">date</span>: <span class=\"hljs-string\">'2011-10-13'</span> },\n        { <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">76.6</span>, <span class=\"hljs-attr\">city</span>: <span class=\"hljs-string\">'Austin'</span>, <span class=\"hljs-attr\">date</span>: <span class=\"hljs-string\">'2011-10-13'</span> },\n        { <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">66.9</span>, <span class=\"hljs-attr\">city</span>: <span class=\"hljs-string\">'New York'</span>, <span class=\"hljs-attr\">date</span>: <span class=\"hljs-string\">'2011-10-14'</span> },\n        { <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">67.1</span>, <span class=\"hljs-attr\">city</span>: <span class=\"hljs-string\">'Alaska'</span>, <span class=\"hljs-attr\">date</span>: <span class=\"hljs-string\">'2011-10-14'</span> },\n        { <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">66.6</span>, <span class=\"hljs-attr\">city</span>: <span class=\"hljs-string\">'Austin'</span>, <span class=\"hljs-attr\">date</span>: <span class=\"hljs-string\">'2011-10-14'</span> },\n        { <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">61.7</span>, <span class=\"hljs-attr\">city</span>: <span class=\"hljs-string\">'New York'</span>, <span class=\"hljs-attr\">date</span>: <span class=\"hljs-string\">'2011-10-15'</span> },\n        { <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">64.6</span>, <span class=\"hljs-attr\">city</span>: <span class=\"hljs-string\">'Alaska'</span>, <span class=\"hljs-attr\">date</span>: <span class=\"hljs-string\">'2011-10-15'</span> },\n        { <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">68</span>, <span class=\"hljs-attr\">city</span>: <span class=\"hljs-string\">'Austin'</span>, <span class=\"hljs-attr\">date</span>: <span class=\"hljs-string\">'2011-10-15'</span> },\n        { <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">61.8</span>, <span class=\"hljs-attr\">city</span>: <span class=\"hljs-string\">'New York'</span>, <span class=\"hljs-attr\">date</span>: <span class=\"hljs-string\">'2011-10-16'</span> },\n        { <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">61.6</span>, <span class=\"hljs-attr\">city</span>: <span class=\"hljs-string\">'Alaska'</span>, <span class=\"hljs-attr\">date</span>: <span class=\"hljs-string\">'2011-10-16'</span> },\n        { <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">70.6</span>, <span class=\"hljs-attr\">city</span>: <span class=\"hljs-string\">'Austin'</span>, <span class=\"hljs-attr\">date</span>: <span class=\"hljs-string\">'2011-10-16'</span> },\n        { <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">62.8</span>, <span class=\"hljs-attr\">city</span>: <span class=\"hljs-string\">'New York'</span>, <span class=\"hljs-attr\">date</span>: <span class=\"hljs-string\">'2011-10-17'</span> },\n        { <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">61.1</span>, <span class=\"hljs-attr\">city</span>: <span class=\"hljs-string\">'Alaska'</span>, <span class=\"hljs-attr\">date</span>: <span class=\"hljs-string\">'2011-10-17'</span> },\n        { <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">71.1</span>, <span class=\"hljs-attr\">city</span>: <span class=\"hljs-string\">'Austin'</span>, <span class=\"hljs-attr\">date</span>: <span class=\"hljs-string\">'2011-10-17'</span> },\n        { <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">60.8</span>, <span class=\"hljs-attr\">city</span>: <span class=\"hljs-string\">'New York'</span>, <span class=\"hljs-attr\">date</span>: <span class=\"hljs-string\">'2011-10-18'</span> },\n        { <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">59.2</span>, <span class=\"hljs-attr\">city</span>: <span class=\"hljs-string\">'Alaska'</span>, <span class=\"hljs-attr\">date</span>: <span class=\"hljs-string\">'2011-10-18'</span> },\n        { <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">70</span>, <span class=\"hljs-attr\">city</span>: <span class=\"hljs-string\">'Austin'</span>, <span class=\"hljs-attr\">date</span>: <span class=\"hljs-string\">'2011-10-18'</span> },\n        { <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">62.1</span>, <span class=\"hljs-attr\">city</span>: <span class=\"hljs-string\">'New York'</span>, <span class=\"hljs-attr\">date</span>: <span class=\"hljs-string\">'2011-10-19'</span> },\n        { <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">58.9</span>, <span class=\"hljs-attr\">city</span>: <span class=\"hljs-string\">'Alaska'</span>, <span class=\"hljs-attr\">date</span>: <span class=\"hljs-string\">'2011-10-19'</span> },\n        { <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">61.6</span>, <span class=\"hljs-attr\">city</span>: <span class=\"hljs-string\">'Austin'</span>, <span class=\"hljs-attr\">date</span>: <span class=\"hljs-string\">'2011-10-19'</span> },\n        { <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">65.1</span>, <span class=\"hljs-attr\">city</span>: <span class=\"hljs-string\">'New York'</span>, <span class=\"hljs-attr\">date</span>: <span class=\"hljs-string\">'2011-10-20'</span> },\n        { <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">57.2</span>, <span class=\"hljs-attr\">city</span>: <span class=\"hljs-string\">'Alaska'</span>, <span class=\"hljs-attr\">date</span>: <span class=\"hljs-string\">'2011-10-20'</span> },\n        { <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">57.4</span>, <span class=\"hljs-attr\">city</span>: <span class=\"hljs-string\">'Austin'</span>, <span class=\"hljs-attr\">date</span>: <span class=\"hljs-string\">'2011-10-20'</span> },\n        { <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">55.6</span>, <span class=\"hljs-attr\">city</span>: <span class=\"hljs-string\">'New York'</span>, <span class=\"hljs-attr\">date</span>: <span class=\"hljs-string\">'2011-10-21'</span> },\n        { <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">56.4</span>, <span class=\"hljs-attr\">city</span>: <span class=\"hljs-string\">'Alaska'</span>, <span class=\"hljs-attr\">date</span>: <span class=\"hljs-string\">'2011-10-21'</span> },\n        { <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">64.3</span>, <span class=\"hljs-attr\">city</span>: <span class=\"hljs-string\">'Austin'</span>, <span class=\"hljs-attr\">date</span>: <span class=\"hljs-string\">'2011-10-21'</span> },\n        { <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">54.4</span>, <span class=\"hljs-attr\">city</span>: <span class=\"hljs-string\">'New York'</span>, <span class=\"hljs-attr\">date</span>: <span class=\"hljs-string\">'2011-10-22'</span> },\n        { <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">60.7</span>, <span class=\"hljs-attr\">city</span>: <span class=\"hljs-string\">'Alaska'</span>, <span class=\"hljs-attr\">date</span>: <span class=\"hljs-string\">'2011-10-22'</span> },\n        { <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">72.4</span>, <span class=\"hljs-attr\">city</span>: <span class=\"hljs-string\">'Austin'</span>, <span class=\"hljs-attr\">date</span>: <span class=\"hljs-string\">'2011-10-22'</span> },\n        { <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">54.4</span>, <span class=\"hljs-attr\">city</span>: <span class=\"hljs-string\">'New York'</span>, <span class=\"hljs-attr\">date</span>: <span class=\"hljs-string\">'2011-10-23'</span> },\n        { <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">65.1</span>, <span class=\"hljs-attr\">city</span>: <span class=\"hljs-string\">'Alaska'</span>, <span class=\"hljs-attr\">date</span>: <span class=\"hljs-string\">'2011-10-23'</span> },\n        { <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">72.4</span>, <span class=\"hljs-attr\">city</span>: <span class=\"hljs-string\">'Austin'</span>, <span class=\"hljs-attr\">date</span>: <span class=\"hljs-string\">'2011-10-23'</span> },\n        { <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">54.8</span>, <span class=\"hljs-attr\">city</span>: <span class=\"hljs-string\">'New York'</span>, <span class=\"hljs-attr\">date</span>: <span class=\"hljs-string\">'2011-10-24'</span> },\n        { <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">60.9</span>, <span class=\"hljs-attr\">city</span>: <span class=\"hljs-string\">'Alaska'</span>, <span class=\"hljs-attr\">date</span>: <span class=\"hljs-string\">'2011-10-24'</span> },\n        { <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">72.5</span>, <span class=\"hljs-attr\">city</span>: <span class=\"hljs-string\">'Austin'</span>, <span class=\"hljs-attr\">date</span>: <span class=\"hljs-string\">'2011-10-24'</span> },\n        { <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">57.9</span>, <span class=\"hljs-attr\">city</span>: <span class=\"hljs-string\">'New York'</span>, <span class=\"hljs-attr\">date</span>: <span class=\"hljs-string\">'2011-10-25'</span> },\n        { <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">56.1</span>, <span class=\"hljs-attr\">city</span>: <span class=\"hljs-string\">'Alaska'</span>, <span class=\"hljs-attr\">date</span>: <span class=\"hljs-string\">'2011-10-25'</span> },\n        { <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">72.7</span>, <span class=\"hljs-attr\">city</span>: <span class=\"hljs-string\">'Austin'</span>, <span class=\"hljs-attr\">date</span>: <span class=\"hljs-string\">'2011-10-25'</span> },\n        { <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">54.6</span>, <span class=\"hljs-attr\">city</span>: <span class=\"hljs-string\">'New York'</span>, <span class=\"hljs-attr\">date</span>: <span class=\"hljs-string\">'2011-10-26'</span> },\n        { <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">54.6</span>, <span class=\"hljs-attr\">city</span>: <span class=\"hljs-string\">'Alaska'</span>, <span class=\"hljs-attr\">date</span>: <span class=\"hljs-string\">'2011-10-26'</span> },\n        { <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">73.4</span>, <span class=\"hljs-attr\">city</span>: <span class=\"hljs-string\">'Austin'</span>, <span class=\"hljs-attr\">date</span>: <span class=\"hljs-string\">'2011-10-26'</span> },\n        { <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">54.4</span>, <span class=\"hljs-attr\">city</span>: <span class=\"hljs-string\">'New York'</span>, <span class=\"hljs-attr\">date</span>: <span class=\"hljs-string\">'2011-10-27'</span> },\n        { <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">56.1</span>, <span class=\"hljs-attr\">city</span>: <span class=\"hljs-string\">'Alaska'</span>, <span class=\"hljs-attr\">date</span>: <span class=\"hljs-string\">'2011-10-27'</span> },\n        { <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">70.7</span>, <span class=\"hljs-attr\">city</span>: <span class=\"hljs-string\">'Austin'</span>, <span class=\"hljs-attr\">date</span>: <span class=\"hljs-string\">'2011-10-27'</span> },\n        { <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">42.5</span>, <span class=\"hljs-attr\">city</span>: <span class=\"hljs-string\">'New York'</span>, <span class=\"hljs-attr\">date</span>: <span class=\"hljs-string\">'2011-10-28'</span> },\n        { <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">58.1</span>, <span class=\"hljs-attr\">city</span>: <span class=\"hljs-string\">'Alaska'</span>, <span class=\"hljs-attr\">date</span>: <span class=\"hljs-string\">'2011-10-28'</span> },\n        { <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">56.8</span>, <span class=\"hljs-attr\">city</span>: <span class=\"hljs-string\">'Austin'</span>, <span class=\"hljs-attr\">date</span>: <span class=\"hljs-string\">'2011-10-28'</span> },\n        { <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">40.9</span>, <span class=\"hljs-attr\">city</span>: <span class=\"hljs-string\">'New York'</span>, <span class=\"hljs-attr\">date</span>: <span class=\"hljs-string\">'2011-10-29'</span> },\n        { <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">57.5</span>, <span class=\"hljs-attr\">city</span>: <span class=\"hljs-string\">'Alaska'</span>, <span class=\"hljs-attr\">date</span>: <span class=\"hljs-string\">'2011-10-29'</span> },\n        { <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">51</span>, <span class=\"hljs-attr\">city</span>: <span class=\"hljs-string\">'Austin'</span>, <span class=\"hljs-attr\">date</span>: <span class=\"hljs-string\">'2011-10-29'</span> },\n        { <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">38.6</span>, <span class=\"hljs-attr\">city</span>: <span class=\"hljs-string\">'New York'</span>, <span class=\"hljs-attr\">date</span>: <span class=\"hljs-string\">'2011-10-30'</span> },\n        { <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">57.7</span>, <span class=\"hljs-attr\">city</span>: <span class=\"hljs-string\">'Alaska'</span>, <span class=\"hljs-attr\">date</span>: <span class=\"hljs-string\">'2011-10-30'</span> },\n        { <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">54.9</span>, <span class=\"hljs-attr\">city</span>: <span class=\"hljs-string\">'Austin'</span>, <span class=\"hljs-attr\">date</span>: <span class=\"hljs-string\">'2011-10-30'</span> },\n        { <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">44.2</span>, <span class=\"hljs-attr\">city</span>: <span class=\"hljs-string\">'New York'</span>, <span class=\"hljs-attr\">date</span>: <span class=\"hljs-string\">'2011-10-31'</span> },\n        { <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">55.1</span>, <span class=\"hljs-attr\">city</span>: <span class=\"hljs-string\">'Alaska'</span>, <span class=\"hljs-attr\">date</span>: <span class=\"hljs-string\">'2011-10-31'</span> },\n        { <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">58.8</span>, <span class=\"hljs-attr\">city</span>: <span class=\"hljs-string\">'Austin'</span>, <span class=\"hljs-attr\">date</span>: <span class=\"hljs-string\">'2011-10-31'</span> },\n        { <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">49.6</span>, <span class=\"hljs-attr\">city</span>: <span class=\"hljs-string\">'New York'</span>, <span class=\"hljs-attr\">date</span>: <span class=\"hljs-string\">'2011-11-01'</span> },\n        { <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">57.9</span>, <span class=\"hljs-attr\">city</span>: <span class=\"hljs-string\">'Alaska'</span>, <span class=\"hljs-attr\">date</span>: <span class=\"hljs-string\">'2011-11-01'</span> },\n        { <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">62.6</span>, <span class=\"hljs-attr\">city</span>: <span class=\"hljs-string\">'Austin'</span>, <span class=\"hljs-attr\">date</span>: <span class=\"hljs-string\">'2011-11-01'</span> },\n        { <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">47.2</span>, <span class=\"hljs-attr\">city</span>: <span class=\"hljs-string\">'New York'</span>, <span class=\"hljs-attr\">date</span>: <span class=\"hljs-string\">'2011-11-02'</span> },\n        { <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">64.6</span>, <span class=\"hljs-attr\">city</span>: <span class=\"hljs-string\">'Alaska'</span>, <span class=\"hljs-attr\">date</span>: <span class=\"hljs-string\">'2011-11-02'</span> },\n        { <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">71</span>, <span class=\"hljs-attr\">city</span>: <span class=\"hljs-string\">'Austin'</span>, <span class=\"hljs-attr\">date</span>: <span class=\"hljs-string\">'2011-11-02'</span> }\n      ]\n    }\n  }\n}\n</span><span class=\"hljs-tag\">&lt;/<span class=\"hljs-name\">script</span>&gt;</span>\n\n\n</code></pre>",
    "oriHeight": "270px",
    "height": "270px",
    "noBackgroundColor": "true",
    "order": 999
  },
  {
    "file": "v-chart/bar_stack",
    "title": "层叠柱状图",
    "code": "<pre class=\"hljs\"><code><span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">template</span>&gt;</span>\n  <span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">div</span>&gt;</span>\n    <span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">v-chart</span> <span class=\"hljs-attr\">ref</span>=<span class=\"hljs-string\">\"demo\"</span> <span class=\"hljs-attr\">:data</span>=<span class=\"hljs-string\">\"data\"</span>&gt;</span>\n      <span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">v-scale</span> <span class=\"hljs-attr\">x</span> <span class=\"hljs-attr\">field</span>=<span class=\"hljs-string\">\"月份\"</span> /&gt;</span>\n      <span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">v-scale</span> <span class=\"hljs-attr\">y</span> <span class=\"hljs-attr\">field</span>=<span class=\"hljs-string\">\"月均降雨量\"</span> /&gt;</span>\n      <span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">v-bar</span> <span class=\"hljs-attr\">series-field</span>=<span class=\"hljs-string\">\"name\"</span> <span class=\"hljs-attr\">adjust</span>=<span class=\"hljs-string\">\"stack\"</span> /&gt;</span>\n      <span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">v-tooltip</span> <span class=\"hljs-attr\">show-value-in-legend</span> /&gt;</span>\n    <span class=\"hljs-tag\">&lt;/<span class=\"hljs-name\">v-chart</span>&gt;</span>\n\n    <span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">x-button</span> <span class=\"hljs-attr\">type</span>=<span class=\"hljs-string\">\"primary\"</span> <span class=\"hljs-attr\">plain</span> @<span class=\"hljs-attr\">click.native</span>=<span class=\"hljs-string\">\"$refs.demo.rerender()\"</span>&gt;</span>rerender<span class=\"hljs-tag\">&lt;/<span class=\"hljs-name\">x-button</span>&gt;</span>\n  <span class=\"hljs-tag\">&lt;/<span class=\"hljs-name\">div</span>&gt;</span>\n<span class=\"hljs-tag\">&lt;/<span class=\"hljs-name\">template</span>&gt;</span>\n\n<span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">script</span>&gt;</span><span class=\"javascript\">\n<span class=\"hljs-keyword\">import</span> { VChart, VLine, VArea, VTooltip, VLegend, VBar, XButton, VScale } <span class=\"hljs-keyword\">from</span> <span class=\"hljs-string\">'vux'</span>\n\n<span class=\"hljs-keyword\">export</span> <span class=\"hljs-keyword\">default</span> {\n  <span class=\"hljs-attr\">components</span>: {\n    VChart,\n    VLine,\n    VArea,\n    VTooltip,\n    VLegend,\n    VBar,\n    XButton,\n    VScale\n  },\n  data () {\n    <span class=\"hljs-keyword\">return</span> {\n      <span class=\"hljs-attr\">data</span>: [\n        { <span class=\"hljs-attr\">name</span>: <span class=\"hljs-string\">'London'</span>, 月份: <span class=\"hljs-string\">'Jan.'</span>, 月均降雨量: <span class=\"hljs-number\">18.9</span> },\n        { <span class=\"hljs-attr\">name</span>: <span class=\"hljs-string\">'London'</span>, 月份: <span class=\"hljs-string\">'Feb.'</span>, 月均降雨量: <span class=\"hljs-number\">28.8</span> },\n        { <span class=\"hljs-attr\">name</span>: <span class=\"hljs-string\">'London'</span>, 月份: <span class=\"hljs-string\">'Mar.'</span>, 月均降雨量: <span class=\"hljs-number\">39.3</span> },\n        { <span class=\"hljs-attr\">name</span>: <span class=\"hljs-string\">'London'</span>, 月份: <span class=\"hljs-string\">'Apr.'</span>, 月均降雨量: <span class=\"hljs-number\">81.4</span> },\n        { <span class=\"hljs-attr\">name</span>: <span class=\"hljs-string\">'London'</span>, 月份: <span class=\"hljs-string\">'May.'</span>, 月均降雨量: <span class=\"hljs-number\">47</span> },\n        { <span class=\"hljs-attr\">name</span>: <span class=\"hljs-string\">'London'</span>, 月份: <span class=\"hljs-string\">'Jun.'</span>, 月均降雨量: <span class=\"hljs-number\">20.3</span> },\n        { <span class=\"hljs-attr\">name</span>: <span class=\"hljs-string\">'London'</span>, 月份: <span class=\"hljs-string\">'Jul.'</span>, 月均降雨量: <span class=\"hljs-number\">24</span> },\n        { <span class=\"hljs-attr\">name</span>: <span class=\"hljs-string\">'London'</span>, 月份: <span class=\"hljs-string\">'Aug.'</span>, 月均降雨量: <span class=\"hljs-number\">35.6</span> },\n        { <span class=\"hljs-attr\">name</span>: <span class=\"hljs-string\">'Berlin'</span>, 月份: <span class=\"hljs-string\">'Jan.'</span>, 月均降雨量: <span class=\"hljs-number\">12.4</span> },\n        { <span class=\"hljs-attr\">name</span>: <span class=\"hljs-string\">'Berlin'</span>, 月份: <span class=\"hljs-string\">'Feb.'</span>, 月均降雨量: <span class=\"hljs-number\">23.2</span> },\n        { <span class=\"hljs-attr\">name</span>: <span class=\"hljs-string\">'Berlin'</span>, 月份: <span class=\"hljs-string\">'Mar.'</span>, 月均降雨量: <span class=\"hljs-number\">34.5</span> },\n        { <span class=\"hljs-attr\">name</span>: <span class=\"hljs-string\">'Berlin'</span>, 月份: <span class=\"hljs-string\">'Apr.'</span>, 月均降雨量: <span class=\"hljs-number\">99.7</span> },\n        { <span class=\"hljs-attr\">name</span>: <span class=\"hljs-string\">'Berlin'</span>, 月份: <span class=\"hljs-string\">'May.'</span>, 月均降雨量: <span class=\"hljs-number\">52.6</span> },\n        { <span class=\"hljs-attr\">name</span>: <span class=\"hljs-string\">'Berlin'</span>, 月份: <span class=\"hljs-string\">'Jun.'</span>, 月均降雨量: <span class=\"hljs-number\">35.5</span> },\n        { <span class=\"hljs-attr\">name</span>: <span class=\"hljs-string\">'Berlin'</span>, 月份: <span class=\"hljs-string\">'Jul.'</span>, 月均降雨量: <span class=\"hljs-number\">37.4</span> },\n        { <span class=\"hljs-attr\">name</span>: <span class=\"hljs-string\">'Berlin'</span>, 月份: <span class=\"hljs-string\">'Aug.'</span>, 月均降雨量: <span class=\"hljs-number\">42.4</span> }\n      ]\n    }\n  }\n}\n</span><span class=\"hljs-tag\">&lt;/<span class=\"hljs-name\">script</span>&gt;</span>\n\n\n</code></pre>",
    "oriHeight": "270px",
    "height": "270px",
    "noBackgroundColor": "true",
    "order": 999
  },
  {
    "file": "v-chart/bar_series",
    "title": "分组柱状图",
    "code": "<pre class=\"hljs\"><code><span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">template</span>&gt;</span>\n  <span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">div</span>&gt;</span>\n    <span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">v-chart</span>\n      <span class=\"hljs-attr\">ref</span>=<span class=\"hljs-string\">\"demo\"</span>\n      <span class=\"hljs-attr\">:data</span>=<span class=\"hljs-string\">\"data\"</span>&gt;</span>\n      <span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">v-scale</span> <span class=\"hljs-attr\">x</span> <span class=\"hljs-attr\">field</span>=<span class=\"hljs-string\">\"月份\"</span> /&gt;</span>\n      <span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">v-scale</span> <span class=\"hljs-attr\">y</span> <span class=\"hljs-attr\">field</span>=<span class=\"hljs-string\">\"月均降雨量\"</span> /&gt;</span>\n      <span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">v-bar</span> <span class=\"hljs-attr\">series-field</span>=<span class=\"hljs-string\">\"name\"</span> <span class=\"hljs-attr\">:adjust</span>=<span class=\"hljs-string\">\"{\n        type: 'dodge',\n        marginRatio: 0.05 // 设置分组间柱子的间距\n      }\"</span> /&gt;</span>\n      <span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">v-tooltip</span> <span class=\"hljs-attr\">show-value-in-legend</span> /&gt;</span>\n    <span class=\"hljs-tag\">&lt;/<span class=\"hljs-name\">v-chart</span>&gt;</span>\n\n    <span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">x-button</span> <span class=\"hljs-attr\">type</span>=<span class=\"hljs-string\">\"primary\"</span> <span class=\"hljs-attr\">plain</span> @<span class=\"hljs-attr\">click.native</span>=<span class=\"hljs-string\">\"$refs.demo.rerender()\"</span>&gt;</span>rerender<span class=\"hljs-tag\">&lt;/<span class=\"hljs-name\">x-button</span>&gt;</span>\n  <span class=\"hljs-tag\">&lt;/<span class=\"hljs-name\">div</span>&gt;</span>\n<span class=\"hljs-tag\">&lt;/<span class=\"hljs-name\">template</span>&gt;</span>\n\n<span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">script</span>&gt;</span><span class=\"javascript\">\n<span class=\"hljs-keyword\">import</span> { VChart, VLine, VArea, VTooltip, VLegend, VBar, XButton, VScale } <span class=\"hljs-keyword\">from</span> <span class=\"hljs-string\">'vux'</span>\n\n<span class=\"hljs-keyword\">export</span> <span class=\"hljs-keyword\">default</span> {\n  <span class=\"hljs-attr\">components</span>: {\n    VChart,\n    VLine,\n    VArea,\n    VTooltip,\n    VLegend,\n    VBar,\n    XButton,\n    VScale\n  },\n  data () {\n    <span class=\"hljs-keyword\">return</span> {\n      <span class=\"hljs-attr\">data</span>: [\n        { <span class=\"hljs-attr\">name</span>: <span class=\"hljs-string\">'London'</span>, 月份: <span class=\"hljs-string\">'Jan.'</span>, 月均降雨量: <span class=\"hljs-number\">18.9</span> },\n        { <span class=\"hljs-attr\">name</span>: <span class=\"hljs-string\">'London'</span>, 月份: <span class=\"hljs-string\">'Feb.'</span>, 月均降雨量: <span class=\"hljs-number\">28.8</span> },\n        { <span class=\"hljs-attr\">name</span>: <span class=\"hljs-string\">'London'</span>, 月份: <span class=\"hljs-string\">'Mar.'</span>, 月均降雨量: <span class=\"hljs-number\">39.3</span> },\n        { <span class=\"hljs-attr\">name</span>: <span class=\"hljs-string\">'London'</span>, 月份: <span class=\"hljs-string\">'Apr.'</span>, 月均降雨量: <span class=\"hljs-number\">81.4</span> },\n        { <span class=\"hljs-attr\">name</span>: <span class=\"hljs-string\">'London'</span>, 月份: <span class=\"hljs-string\">'May.'</span>, 月均降雨量: <span class=\"hljs-number\">47</span> },\n        { <span class=\"hljs-attr\">name</span>: <span class=\"hljs-string\">'London'</span>, 月份: <span class=\"hljs-string\">'Jun.'</span>, 月均降雨量: <span class=\"hljs-number\">20.3</span> },\n        { <span class=\"hljs-attr\">name</span>: <span class=\"hljs-string\">'London'</span>, 月份: <span class=\"hljs-string\">'Jul.'</span>, 月均降雨量: <span class=\"hljs-number\">24</span> },\n        { <span class=\"hljs-attr\">name</span>: <span class=\"hljs-string\">'London'</span>, 月份: <span class=\"hljs-string\">'Aug.'</span>, 月均降雨量: <span class=\"hljs-number\">35.6</span> },\n        { <span class=\"hljs-attr\">name</span>: <span class=\"hljs-string\">'Berlin'</span>, 月份: <span class=\"hljs-string\">'Jan.'</span>, 月均降雨量: <span class=\"hljs-number\">12.4</span> },\n        { <span class=\"hljs-attr\">name</span>: <span class=\"hljs-string\">'Berlin'</span>, 月份: <span class=\"hljs-string\">'Feb.'</span>, 月均降雨量: <span class=\"hljs-number\">23.2</span> },\n        { <span class=\"hljs-attr\">name</span>: <span class=\"hljs-string\">'Berlin'</span>, 月份: <span class=\"hljs-string\">'Mar.'</span>, 月均降雨量: <span class=\"hljs-number\">34.5</span> },\n        { <span class=\"hljs-attr\">name</span>: <span class=\"hljs-string\">'Berlin'</span>, 月份: <span class=\"hljs-string\">'Apr.'</span>, 月均降雨量: <span class=\"hljs-number\">99.7</span> },\n        { <span class=\"hljs-attr\">name</span>: <span class=\"hljs-string\">'Berlin'</span>, 月份: <span class=\"hljs-string\">'May.'</span>, 月均降雨量: <span class=\"hljs-number\">52.6</span> },\n        { <span class=\"hljs-attr\">name</span>: <span class=\"hljs-string\">'Berlin'</span>, 月份: <span class=\"hljs-string\">'Jun.'</span>, 月均降雨量: <span class=\"hljs-number\">35.5</span> },\n        { <span class=\"hljs-attr\">name</span>: <span class=\"hljs-string\">'Berlin'</span>, 月份: <span class=\"hljs-string\">'Jul.'</span>, 月均降雨量: <span class=\"hljs-number\">37.4</span> },\n        { <span class=\"hljs-attr\">name</span>: <span class=\"hljs-string\">'Berlin'</span>, 月份: <span class=\"hljs-string\">'Aug.'</span>, 月均降雨量: <span class=\"hljs-number\">42.4</span> }\n      ]\n    }\n  }\n}\n</span><span class=\"hljs-tag\">&lt;/<span class=\"hljs-name\">script</span>&gt;</span>\n\n\n</code></pre>",
    "oriHeight": "270px",
    "height": "270px",
    "noBackgroundColor": "true",
    "order": 999
  },
  {
    "file": "v-chart/bar_percent",
    "title": "百分比柱状图",
    "code": "<pre class=\"hljs\"><code><span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">template</span>&gt;</span>\n  <span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">div</span>&gt;</span>\n    <span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">v-chart</span> <span class=\"hljs-attr\">ref</span>=<span class=\"hljs-string\">\"demo\"</span> <span class=\"hljs-attr\">:data</span>=<span class=\"hljs-string\">\"data\"</span>&gt;</span>\n      <span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">v-scale</span> <span class=\"hljs-attr\">x</span> <span class=\"hljs-attr\">field</span>=<span class=\"hljs-string\">\"year\"</span> /&gt;</span>\n      <span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">v-scale</span> <span class=\"hljs-attr\">y</span> <span class=\"hljs-attr\">field</span>=<span class=\"hljs-string\">\"percent\"</span> <span class=\"hljs-attr\">:min</span>=<span class=\"hljs-string\">\"0\"</span> <span class=\"hljs-attr\">:max</span>=<span class=\"hljs-string\">\"0.5\"</span> <span class=\"hljs-attr\">:formatter</span>=<span class=\"hljs-string\">\"formatter\"</span> /&gt;</span>\n      <span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">v-bar</span> <span class=\"hljs-attr\">series-field</span>=<span class=\"hljs-string\">\"country\"</span> <span class=\"hljs-attr\">adjust</span>=<span class=\"hljs-string\">\"stack\"</span> /&gt;</span>\n      <span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">v-tooltip</span> <span class=\"hljs-attr\">show-value-in-legend</span> /&gt;</span>\n    <span class=\"hljs-tag\">&lt;/<span class=\"hljs-name\">v-chart</span>&gt;</span>\n\n    <span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">x-button</span> <span class=\"hljs-attr\">type</span>=<span class=\"hljs-string\">\"primary\"</span> <span class=\"hljs-attr\">plain</span> @<span class=\"hljs-attr\">click.native</span>=<span class=\"hljs-string\">\"$refs.demo.rerender()\"</span>&gt;</span>rerender<span class=\"hljs-tag\">&lt;/<span class=\"hljs-name\">x-button</span>&gt;</span>\n  <span class=\"hljs-tag\">&lt;/<span class=\"hljs-name\">div</span>&gt;</span>\n<span class=\"hljs-tag\">&lt;/<span class=\"hljs-name\">template</span>&gt;</span>\n\n<span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">script</span>&gt;</span><span class=\"javascript\">\n<span class=\"hljs-keyword\">import</span> { VChart, VLine, VArea, VTooltip, VLegend, VBar, XButton, VScale } <span class=\"hljs-keyword\">from</span> <span class=\"hljs-string\">'vux'</span>\n\n<span class=\"hljs-keyword\">export</span> <span class=\"hljs-keyword\">default</span> {\n  <span class=\"hljs-attr\">components</span>: {\n    VChart,\n    VLine,\n    VArea,\n    VTooltip,\n    VLegend,\n    VBar,\n    XButton,\n    VScale\n  },\n  data () {\n    <span class=\"hljs-keyword\">return</span> {\n      <span class=\"hljs-attr\">formatter</span>: <span class=\"hljs-function\"><span class=\"hljs-keyword\">function</span> (<span class=\"hljs-params\">val</span>) </span>{\n        <span class=\"hljs-keyword\">return</span> (val * <span class=\"hljs-number\">100</span>).toFixed(<span class=\"hljs-number\">0</span>) + <span class=\"hljs-string\">'%'</span>\n      },\n      <span class=\"hljs-attr\">data</span>: [\n        { <span class=\"hljs-attr\">country</span>: <span class=\"hljs-string\">'Europe'</span>, <span class=\"hljs-attr\">year</span>: <span class=\"hljs-string\">'1750'</span>, <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">163</span>, <span class=\"hljs-attr\">percent</span>: <span class=\"hljs-number\">0.24511278195488723</span> },\n        { <span class=\"hljs-attr\">country</span>: <span class=\"hljs-string\">'Asia'</span>, <span class=\"hljs-attr\">year</span>: <span class=\"hljs-string\">'1750'</span>, <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">502</span>, <span class=\"hljs-attr\">percent</span>: <span class=\"hljs-number\">0.7548872180451128</span> },\n        { <span class=\"hljs-attr\">country</span>: <span class=\"hljs-string\">'Europe'</span>, <span class=\"hljs-attr\">year</span>: <span class=\"hljs-string\">'1800'</span>, <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">203</span>, <span class=\"hljs-attr\">percent</span>: <span class=\"hljs-number\">0.24224343675417662</span> },\n        { <span class=\"hljs-attr\">country</span>: <span class=\"hljs-string\">'Asia'</span>, <span class=\"hljs-attr\">year</span>: <span class=\"hljs-string\">'1800'</span>, <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">635</span>, <span class=\"hljs-attr\">percent</span>: <span class=\"hljs-number\">0.7577565632458234</span> },\n        { <span class=\"hljs-attr\">country</span>: <span class=\"hljs-string\">'Europe'</span>, <span class=\"hljs-attr\">year</span>: <span class=\"hljs-string\">'1850'</span>, <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">276</span>, <span class=\"hljs-attr\">percent</span>: <span class=\"hljs-number\">0.2543778801843318</span> },\n        { <span class=\"hljs-attr\">country</span>: <span class=\"hljs-string\">'Asia'</span>, <span class=\"hljs-attr\">year</span>: <span class=\"hljs-string\">'1850'</span>, <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">809</span>, <span class=\"hljs-attr\">percent</span>: <span class=\"hljs-number\">0.7456221198156682</span> },\n        { <span class=\"hljs-attr\">country</span>: <span class=\"hljs-string\">'Europe'</span>, <span class=\"hljs-attr\">year</span>: <span class=\"hljs-string\">'1900'</span>, <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">408</span>, <span class=\"hljs-attr\">percent</span>: <span class=\"hljs-number\">0.3011070110701107</span> },\n        { <span class=\"hljs-attr\">country</span>: <span class=\"hljs-string\">'Asia'</span>, <span class=\"hljs-attr\">year</span>: <span class=\"hljs-string\">'1900'</span>, <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">947</span>, <span class=\"hljs-attr\">percent</span>: <span class=\"hljs-number\">0.6988929889298893</span> },\n        { <span class=\"hljs-attr\">country</span>: <span class=\"hljs-string\">'Europe'</span>, <span class=\"hljs-attr\">year</span>: <span class=\"hljs-string\">'1950'</span>, <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">547</span>, <span class=\"hljs-attr\">percent</span>: <span class=\"hljs-number\">0.2806567470497691</span> },\n        { <span class=\"hljs-attr\">country</span>: <span class=\"hljs-string\">'Asia'</span>, <span class=\"hljs-attr\">year</span>: <span class=\"hljs-string\">'1950'</span>, <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">1402</span>, <span class=\"hljs-attr\">percent</span>: <span class=\"hljs-number\">0.7193432529502309</span> },\n        { <span class=\"hljs-attr\">country</span>: <span class=\"hljs-string\">'Europe'</span>, <span class=\"hljs-attr\">year</span>: <span class=\"hljs-string\">'1999'</span>, <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">729</span>, <span class=\"hljs-attr\">percent</span>: <span class=\"hljs-number\">0.16708686683474674</span> },\n        { <span class=\"hljs-attr\">country</span>: <span class=\"hljs-string\">'Asia'</span>, <span class=\"hljs-attr\">year</span>: <span class=\"hljs-string\">'1999'</span>, <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">3634</span>, <span class=\"hljs-attr\">percent</span>: <span class=\"hljs-number\">0.8329131331652533</span> },\n        { <span class=\"hljs-attr\">country</span>: <span class=\"hljs-string\">'Europe'</span>, <span class=\"hljs-attr\">year</span>: <span class=\"hljs-string\">'2050'</span>, <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">628</span>, <span class=\"hljs-attr\">percent</span>: <span class=\"hljs-number\">0.10651289009497965</span> },\n        { <span class=\"hljs-attr\">country</span>: <span class=\"hljs-string\">'Asia'</span>, <span class=\"hljs-attr\">year</span>: <span class=\"hljs-string\">'2050'</span>, <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">5268</span>, <span class=\"hljs-attr\">percent</span>: <span class=\"hljs-number\">0.8934871099050203</span> },\n        { <span class=\"hljs-attr\">country</span>: <span class=\"hljs-string\">'Europe'</span>, <span class=\"hljs-attr\">year</span>: <span class=\"hljs-string\">'2100'</span>, <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">828</span>, <span class=\"hljs-attr\">percent</span>: <span class=\"hljs-number\">0.10227272727272728</span> },\n        { <span class=\"hljs-attr\">country</span>: <span class=\"hljs-string\">'Asia'</span>, <span class=\"hljs-attr\">year</span>: <span class=\"hljs-string\">'2100'</span>, <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">7268</span>, <span class=\"hljs-attr\">percent</span>: <span class=\"hljs-number\">0.8977272727272727</span> }\n      ]\n    }\n  }\n}\n</span><span class=\"hljs-tag\">&lt;/<span class=\"hljs-name\">script</span>&gt;</span>\n\n\n</code></pre>",
    "oriHeight": "270px",
    "height": "270px",
    "noBackgroundColor": "true",
    "order": 999
  },
  {
    "file": "v-chart/bar_basic",
    "title": "基础柱状图",
    "code": "<pre class=\"hljs\"><code><span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">template</span>&gt;</span>\n  <span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">div</span>&gt;</span>\n    <span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">v-chart</span>\n      <span class=\"hljs-attr\">ref</span>=<span class=\"hljs-string\">\"demo\"</span>\n      <span class=\"hljs-attr\">:data</span>=<span class=\"hljs-string\">\"data\"</span>&gt;</span>\n      <span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">v-bar</span> /&gt;</span>\n      <span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">v-tooltip</span> <span class=\"hljs-attr\">:show-item-marker</span>=<span class=\"hljs-string\">\"false\"</span> /&gt;</span>\n    <span class=\"hljs-tag\">&lt;/<span class=\"hljs-name\">v-chart</span>&gt;</span>\n\n    <span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">x-button</span> <span class=\"hljs-attr\">type</span>=<span class=\"hljs-string\">\"primary\"</span> <span class=\"hljs-attr\">plain</span> @<span class=\"hljs-attr\">click.native</span>=<span class=\"hljs-string\">\"$refs.demo.rerender()\"</span>&gt;</span>rerender<span class=\"hljs-tag\">&lt;/<span class=\"hljs-name\">x-button</span>&gt;</span>\n  <span class=\"hljs-tag\">&lt;/<span class=\"hljs-name\">div</span>&gt;</span>\n<span class=\"hljs-tag\">&lt;/<span class=\"hljs-name\">template</span>&gt;</span>\n\n<span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">script</span>&gt;</span><span class=\"javascript\">\n<span class=\"hljs-keyword\">import</span> { VChart, VLine, VArea, VTooltip, VLegend, VBar, XButton } <span class=\"hljs-keyword\">from</span> <span class=\"hljs-string\">'vux'</span>\n\n<span class=\"hljs-keyword\">export</span> <span class=\"hljs-keyword\">default</span> {\n  <span class=\"hljs-attr\">components</span>: {\n    VChart,\n    VLine,\n    VArea,\n    VTooltip,\n    VLegend,\n    VBar,\n    XButton\n  },\n  data () {\n    <span class=\"hljs-keyword\">return</span> {\n      <span class=\"hljs-attr\">data</span>: [\n        { <span class=\"hljs-attr\">year</span>: <span class=\"hljs-string\">'1951 年'</span>, <span class=\"hljs-attr\">sales</span>: <span class=\"hljs-number\">38</span> },\n        { <span class=\"hljs-attr\">year</span>: <span class=\"hljs-string\">'1952 年'</span>, <span class=\"hljs-attr\">sales</span>: <span class=\"hljs-number\">52</span> },\n        { <span class=\"hljs-attr\">year</span>: <span class=\"hljs-string\">'1956 年'</span>, <span class=\"hljs-attr\">sales</span>: <span class=\"hljs-number\">61</span> },\n        { <span class=\"hljs-attr\">year</span>: <span class=\"hljs-string\">'1957 年'</span>, <span class=\"hljs-attr\">sales</span>: <span class=\"hljs-number\">145</span> },\n        { <span class=\"hljs-attr\">year</span>: <span class=\"hljs-string\">'1958 年'</span>, <span class=\"hljs-attr\">sales</span>: <span class=\"hljs-number\">48</span> },\n        { <span class=\"hljs-attr\">year</span>: <span class=\"hljs-string\">'1959 年'</span>, <span class=\"hljs-attr\">sales</span>: <span class=\"hljs-number\">38</span> },\n        { <span class=\"hljs-attr\">year</span>: <span class=\"hljs-string\">'1960 年'</span>, <span class=\"hljs-attr\">sales</span>: <span class=\"hljs-number\">38</span> },\n        { <span class=\"hljs-attr\">year</span>: <span class=\"hljs-string\">'1962 年'</span>, <span class=\"hljs-attr\">sales</span>: <span class=\"hljs-number\">38</span> }\n      ]\n    }\n  }\n}\n</span><span class=\"hljs-tag\">&lt;/<span class=\"hljs-name\">script</span>&gt;</span>\n\n\n</code></pre>",
    "oriHeight": "270px",
    "height": "270px",
    "noBackgroundColor": "true",
    "order": 999
  },
  {
    "file": "v-chart/area_negative",
    "title": "带负值面积图",
    "code": "<pre class=\"hljs\"><code><span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">template</span>&gt;</span>\n  <span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">div</span>&gt;</span>\n    <span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">v-chart</span>\n      <span class=\"hljs-attr\">:data</span>=<span class=\"hljs-string\">\"data\"</span>&gt;</span>\n      <span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">v-scale</span> <span class=\"hljs-attr\">x</span> <span class=\"hljs-attr\">:tick-count</span>=<span class=\"hljs-string\">\"0\"</span> /&gt;</span>\n      <span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">v-scale</span> <span class=\"hljs-attr\">y</span> <span class=\"hljs-attr\">:nice</span>=<span class=\"hljs-string\">\"false\"</span> <span class=\"hljs-attr\">:min</span>=<span class=\"hljs-string\">\"-100\"</span> <span class=\"hljs-attr\">:max</span>=<span class=\"hljs-string\">\"100\"</span> /&gt;</span>\n      <span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">v-tooltip</span> /&gt;</span>\n      <span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">v-area</span> /&gt;</span>\n      <span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">v-line</span> /&gt;</span>\n    <span class=\"hljs-tag\">&lt;/<span class=\"hljs-name\">v-chart</span>&gt;</span>\n  <span class=\"hljs-tag\">&lt;/<span class=\"hljs-name\">div</span>&gt;</span>\n<span class=\"hljs-tag\">&lt;/<span class=\"hljs-name\">template</span>&gt;</span>\n\n<span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">script</span>&gt;</span><span class=\"javascript\">\n<span class=\"hljs-keyword\">import</span> { VChart, VLine, VArea, VTooltip, VScale } <span class=\"hljs-keyword\">from</span> <span class=\"hljs-string\">'vux'</span>\n\n<span class=\"hljs-keyword\">export</span> <span class=\"hljs-keyword\">default</span> {\n  <span class=\"hljs-attr\">components</span>: {\n    VChart,\n    VLine,\n    VArea,\n    VTooltip,\n    VScale\n  },\n  data () {\n    <span class=\"hljs-keyword\">return</span> {\n      <span class=\"hljs-attr\">tooltip</span>: {\n        <span class=\"hljs-attr\">showItemMarker</span>: <span class=\"hljs-literal\">false</span>,\n        onShow (ev) {\n          <span class=\"hljs-keyword\">const</span> { items } = ev\n          items[<span class=\"hljs-number\">0</span>].name = items[<span class=\"hljs-number\">0</span>].title\n        }\n      },\n      <span class=\"hljs-attr\">data</span>: [\n        { <span class=\"hljs-attr\">month</span>: <span class=\"hljs-string\">'Jan.'</span>, <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">6.06</span> },\n        { <span class=\"hljs-attr\">month</span>: <span class=\"hljs-string\">'Feb.'</span>, <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">82.2</span> },\n        { <span class=\"hljs-attr\">month</span>: <span class=\"hljs-string\">'Mar.'</span>, <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">-22.11</span> },\n        { <span class=\"hljs-attr\">month</span>: <span class=\"hljs-string\">'Apr.'</span>, <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">21.53</span> },\n        { <span class=\"hljs-attr\">month</span>: <span class=\"hljs-string\">'May.'</span>, <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">-21.74</span> },\n        { <span class=\"hljs-attr\">month</span>: <span class=\"hljs-string\">'Jun.'</span>, <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">73.61</span> },\n        { <span class=\"hljs-attr\">month</span>: <span class=\"hljs-string\">'Jul.'</span>, <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">53.75</span> },\n        { <span class=\"hljs-attr\">month</span>: <span class=\"hljs-string\">'Aug.'</span>, <span class=\"hljs-attr\">value</span>: <span class=\"hljs-number\">60.32</span> }\n      ]\n    }\n  }\n}\n</span><span class=\"hljs-tag\">&lt;/<span class=\"hljs-name\">script</span>&gt;</span>\n\n\n</code></pre>",
    "oriHeight": "270px",
    "height": "270px",
    "noBackgroundColor": "true",
    "order": 999
  },
  {
    "file": "v-chart/pie_annular",
    "title": "环图: 资产配置",
    "code": "<pre class=\"hljs\"><code><span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">template</span>&gt;</span>\n  <span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">div</span>&gt;</span>\n    <span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">v-chart</span>\n      <span class=\"hljs-attr\">:data</span>=<span class=\"hljs-string\">\"data\"</span>\n      <span class=\"hljs-attr\">:padding</span>=<span class=\"hljs-string\">\"[20, 'auto']\"</span>&gt;</span>\n      <span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">v-tooltip</span> <span class=\"hljs-attr\">disabled</span> /&gt;</span>\n      <span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">v-scale</span> <span class=\"hljs-attr\">y</span> <span class=\"hljs-attr\">:options</span>=<span class=\"hljs-string\">\"yOptions\"</span> /&gt;</span>\n      <span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">v-pie</span> <span class=\"hljs-attr\">:radius</span>=<span class=\"hljs-string\">\"0.85\"</span> <span class=\"hljs-attr\">:inner-radius</span>=<span class=\"hljs-string\">\"0.7\"</span> <span class=\"hljs-attr\">series-field</span>=<span class=\"hljs-string\">\"name\"</span> <span class=\"hljs-attr\">:colors</span>=<span class=\"hljs-string\">\"['#FE5D4D','#3BA4FF','#737DDE']\"</span> /&gt;</span>\n      <span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">v-legend</span> <span class=\"hljs-attr\">:options</span>=<span class=\"hljs-string\">\"legendOptions\"</span> /&gt;</span>\n      <span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">v-guide</span> <span class=\"hljs-attr\">type</span>=<span class=\"hljs-string\">\"html\"</span> <span class=\"hljs-attr\">:options</span>=<span class=\"hljs-string\">\"htmlOptions\"</span> /&gt;</span>\n    <span class=\"hljs-tag\">&lt;/<span class=\"hljs-name\">v-chart</span>&gt;</span>\n  <span class=\"hljs-tag\">&lt;/<span class=\"hljs-name\">div</span>&gt;</span>\n<span class=\"hljs-tag\">&lt;/<span class=\"hljs-name\">template</span>&gt;</span>\n\n<span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">script</span>&gt;</span><span class=\"javascript\">\n<span class=\"hljs-keyword\">import</span> { VChart, VLine, VArea, VTooltip, VLegend, VBar, VPie, VGuide, VScale } <span class=\"hljs-keyword\">from</span> <span class=\"hljs-string\">'vux'</span>\n\n<span class=\"hljs-keyword\">const</span> data = [\n  { <span class=\"hljs-attr\">name</span>: <span class=\"hljs-string\">'股票类'</span>, <span class=\"hljs-attr\">percent</span>: <span class=\"hljs-number\">83.59</span>, <span class=\"hljs-attr\">a</span>: <span class=\"hljs-string\">'1'</span> },\n  { <span class=\"hljs-attr\">name</span>: <span class=\"hljs-string\">'债券类'</span>, <span class=\"hljs-attr\">percent</span>: <span class=\"hljs-number\">2.17</span>, <span class=\"hljs-attr\">a</span>: <span class=\"hljs-string\">'1'</span> },\n  { <span class=\"hljs-attr\">name</span>: <span class=\"hljs-string\">'现金类'</span>, <span class=\"hljs-attr\">percent</span>: <span class=\"hljs-number\">14.24</span>, <span class=\"hljs-attr\">a</span>: <span class=\"hljs-string\">'1'</span> }\n]\n\n<span class=\"hljs-keyword\">const</span> map = {}\ndata.map(<span class=\"hljs-function\"><span class=\"hljs-params\">obj</span> =&gt;</span> {\n  map[obj.name] = obj.percent + <span class=\"hljs-string\">'%'</span>\n})\n\n<span class=\"hljs-keyword\">export</span> <span class=\"hljs-keyword\">default</span> {\n  <span class=\"hljs-attr\">components</span>: {\n    VChart,\n    VLine,\n    VArea,\n    VTooltip,\n    VLegend,\n    VBar,\n    VPie,\n    VGuide,\n    VScale\n  },\n  data () {\n    <span class=\"hljs-keyword\">return</span> {\n      map,\n      <span class=\"hljs-attr\">htmlOptions</span>: {\n        <span class=\"hljs-attr\">position</span>: [ <span class=\"hljs-string\">'50%'</span>, <span class=\"hljs-string\">'45%'</span> ],\n        <span class=\"hljs-attr\">html</span>: <span class=\"hljs-string\">`\n          &lt;div style=\"width: 250px;height: 40px;text-align: center;\"&gt;\n            &lt;div style=\"font-size: 16px\"&gt;总资产&lt;/div&gt;\n            &lt;div style=\"font-size: 24px\"&gt;133.08 亿&lt;/div&gt;\n          &lt;/div&gt;`</span>\n      },\n      <span class=\"hljs-attr\">legendOptions</span>: {\n        <span class=\"hljs-attr\">position</span>: <span class=\"hljs-string\">'right'</span>,\n        itemFormatter (val) {\n          <span class=\"hljs-keyword\">return</span> val + <span class=\"hljs-string\">'  '</span> + map[val]\n        }\n      },\n      <span class=\"hljs-attr\">yOptions</span>: {\n        formatter (val) {\n          <span class=\"hljs-keyword\">return</span> val * <span class=\"hljs-number\">100</span> + <span class=\"hljs-string\">'%'</span>\n        }\n      },\n      data\n    }\n  }\n}\n</span><span class=\"hljs-tag\">&lt;/<span class=\"hljs-name\">script</span>&gt;</span>\n\n\n</code></pre>",
    "oriHeight": "270px",
    "height": "270px",
    "noBackgroundColor": "true",
    "order": 999
  },
  {
    "file": "v-chart/area_gradient",
    "title": "渐变填充面积图",
    "code": "<pre class=\"hljs\"><code><span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">template</span>&gt;</span>\n  <span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">div</span>&gt;</span>\n    <span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">v-chart</span>\n      <span class=\"hljs-attr\">:data</span>=<span class=\"hljs-string\">\"data\"</span>&gt;</span>\n      <span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">v-scale</span> <span class=\"hljs-attr\">x</span> <span class=\"hljs-attr\">type</span>=<span class=\"hljs-string\">\"timeCat\"</span> <span class=\"hljs-attr\">:tick-count</span>=<span class=\"hljs-string\">\"3\"</span> /&gt;</span>\n      <span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">v-scale</span> <span class=\"hljs-attr\">y</span> <span class=\"hljs-attr\">:min</span>=<span class=\"hljs-string\">\"0\"</span>/&gt;</span>\n      <span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">v-area</span> <span class=\"hljs-attr\">:colors</span>=<span class=\"hljs-string\">\"gradient\"</span> <span class=\"hljs-attr\">shape</span>=<span class=\"hljs-string\">\"smooth\"</span> /&gt;</span>\n      <span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">v-line</span> <span class=\"hljs-attr\">:colors</span>=<span class=\"hljs-string\">\"gradient\"</span> <span class=\"hljs-attr\">shape</span>=<span class=\"hljs-string\">\"smooth\"</span> /&gt;</span>\n    <span class=\"hljs-tag\">&lt;/<span class=\"hljs-name\">v-chart</span>&gt;</span>\n  <span class=\"hljs-tag\">&lt;/<span class=\"hljs-name\">div</span>&gt;</span>\n<span class=\"hljs-tag\">&lt;/<span class=\"hljs-name\">template</span>&gt;</span>\n\n<span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">script</span>&gt;</span><span class=\"javascript\">\n<span class=\"hljs-keyword\">import</span> { VChart, VLine, VArea, VTooltip, VScale, VAxis } <span class=\"hljs-keyword\">from</span> <span class=\"hljs-string\">'vux'</span>\n\n<span class=\"hljs-keyword\">export</span> <span class=\"hljs-keyword\">default</span> {\n  <span class=\"hljs-attr\">components</span>: {\n    VChart,\n    VLine,\n    VArea,\n    VTooltip,\n    VScale,\n    VAxis\n  },\n  data () {\n    <span class=\"hljs-keyword\">return</span> {\n      <span class=\"hljs-attr\">gradient</span>: [\n        [<span class=\"hljs-number\">0</span>, <span class=\"hljs-string\">'#FE6384'</span>],\n        [<span class=\"hljs-number\">1</span>, <span class=\"hljs-string\">'#f7f7f7'</span>]\n      ],\n      <span class=\"hljs-attr\">data</span>: [\n        { <span class=\"hljs-attr\">time</span>: <span class=\"hljs-string\">'2016-08-08 00:00:00'</span>, <span class=\"hljs-attr\">tem</span>: <span class=\"hljs-number\">10</span> },\n        { <span class=\"hljs-attr\">time</span>: <span class=\"hljs-string\">'2016-08-08 00:10:00'</span>, <span class=\"hljs-attr\">tem</span>: <span class=\"hljs-number\">22</span> },\n        { <span class=\"hljs-attr\">time</span>: <span class=\"hljs-string\">'2016-08-08 00:30:00'</span>, <span class=\"hljs-attr\">tem</span>: <span class=\"hljs-number\">16</span> },\n        { <span class=\"hljs-attr\">time</span>: <span class=\"hljs-string\">'2016-08-09 00:35:00'</span>, <span class=\"hljs-attr\">tem</span>: <span class=\"hljs-number\">26</span> },\n        { <span class=\"hljs-attr\">time</span>: <span class=\"hljs-string\">'2016-08-09 01:00:00'</span>, <span class=\"hljs-attr\">tem</span>: <span class=\"hljs-number\">12</span> },\n        { <span class=\"hljs-attr\">time</span>: <span class=\"hljs-string\">'2016-08-09 01:20:00'</span>, <span class=\"hljs-attr\">tem</span>: <span class=\"hljs-number\">26</span> },\n        { <span class=\"hljs-attr\">time</span>: <span class=\"hljs-string\">'2016-08-10 01:40:00'</span>, <span class=\"hljs-attr\">tem</span>: <span class=\"hljs-number\">18</span> },\n        { <span class=\"hljs-attr\">time</span>: <span class=\"hljs-string\">'2016-08-10 02:00:00'</span>, <span class=\"hljs-attr\">tem</span>: <span class=\"hljs-number\">26</span> },\n        { <span class=\"hljs-attr\">time</span>: <span class=\"hljs-string\">'2016-08-10 02:20:00'</span>, <span class=\"hljs-attr\">tem</span>: <span class=\"hljs-number\">12</span> }\n      ]\n    }\n  }\n}\n</span><span class=\"hljs-tag\">&lt;/<span class=\"hljs-name\">script</span>&gt;</span>\n\n\n</code></pre>",
    "oriHeight": "270px",
    "height": "270px",
    "noBackgroundColor": "true",
    "order": 999
  },
  {
    "file": "v-chart/pie_basic",
    "title": "饼图",
    "code": "<pre class=\"hljs\"><code><span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">template</span>&gt;</span>\n  <span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">div</span>&gt;</span>\n     <span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">v-chart</span> <span class=\"hljs-attr\">:data</span>=<span class=\"hljs-string\">\"data\"</span>&gt;</span>\n     <span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">v-scale</span> <span class=\"hljs-attr\">y</span> <span class=\"hljs-attr\">:options</span>=<span class=\"hljs-string\">\"yOptions\"</span> /&gt;</span>\n     <span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">v-tooltip</span> <span class=\"hljs-attr\">disabled</span> /&gt;</span>\n     <span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">v-pie</span> <span class=\"hljs-attr\">:radius</span>=<span class=\"hljs-string\">\"0.85\"</span> <span class=\"hljs-attr\">series-field</span>=<span class=\"hljs-string\">\"name\"</span> /&gt;</span>\n     <span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">v-legend</span> <span class=\"hljs-attr\">:options</span>=<span class=\"hljs-string\">\"legendOptions\"</span> /&gt;</span>\n    <span class=\"hljs-tag\">&lt;/<span class=\"hljs-name\">v-chart</span>&gt;</span>\n  <span class=\"hljs-tag\">&lt;/<span class=\"hljs-name\">div</span>&gt;</span>\n<span class=\"hljs-tag\">&lt;/<span class=\"hljs-name\">template</span>&gt;</span>\n\n<span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">script</span>&gt;</span><span class=\"javascript\">\n<span class=\"hljs-keyword\">import</span> { VChart, VLine, VArea, VTooltip, VLegend, VBar, VPie, VScale } <span class=\"hljs-keyword\">from</span> <span class=\"hljs-string\">'vux'</span>\n\n<span class=\"hljs-keyword\">const</span> map = {\n  <span class=\"hljs-string\">'芳华'</span>: <span class=\"hljs-string\">'40%'</span>,\n  <span class=\"hljs-string\">'妖猫传'</span>: <span class=\"hljs-string\">'20%'</span>,\n  <span class=\"hljs-string\">'机器之血'</span>: <span class=\"hljs-string\">'18%'</span>,\n  <span class=\"hljs-string\">'心理罪'</span>: <span class=\"hljs-string\">'15%'</span>,\n  <span class=\"hljs-string\">'寻梦环游记'</span>: <span class=\"hljs-string\">'5%'</span>,\n  <span class=\"hljs-string\">'其他'</span>: <span class=\"hljs-string\">'2%'</span>\n}\n\n<span class=\"hljs-keyword\">export</span> <span class=\"hljs-keyword\">default</span> {\n  <span class=\"hljs-attr\">components</span>: {\n    VChart,\n    VLine,\n    VArea,\n    VTooltip,\n    VLegend,\n    VBar,\n    VPie,\n    VScale\n  },\n  data () {\n    <span class=\"hljs-keyword\">return</span> {\n      <span class=\"hljs-attr\">legendOptions</span>: {\n        <span class=\"hljs-attr\">position</span>: <span class=\"hljs-string\">'right'</span>,\n        itemFormatter (val) {\n          <span class=\"hljs-keyword\">return</span> val + <span class=\"hljs-string\">'  '</span> + map[val]\n        }\n      },\n      <span class=\"hljs-attr\">yOptions</span>: {\n        formatter (val) {\n          <span class=\"hljs-keyword\">return</span> val * <span class=\"hljs-number\">100</span> + <span class=\"hljs-string\">'%'</span>\n        }\n      },\n      map,\n      <span class=\"hljs-attr\">data</span>: [\n        { <span class=\"hljs-attr\">name</span>: <span class=\"hljs-string\">'芳华'</span>, <span class=\"hljs-attr\">percent</span>: <span class=\"hljs-number\">0.4</span>, <span class=\"hljs-attr\">a</span>: <span class=\"hljs-string\">'1'</span> },\n        { <span class=\"hljs-attr\">name</span>: <span class=\"hljs-string\">'妖猫传'</span>, <span class=\"hljs-attr\">percent</span>: <span class=\"hljs-number\">0.2</span>, <span class=\"hljs-attr\">a</span>: <span class=\"hljs-string\">'1'</span> },\n        { <span class=\"hljs-attr\">name</span>: <span class=\"hljs-string\">'机器之血'</span>, <span class=\"hljs-attr\">percent</span>: <span class=\"hljs-number\">0.18</span>, <span class=\"hljs-attr\">a</span>: <span class=\"hljs-string\">'1'</span> },\n        { <span class=\"hljs-attr\">name</span>: <span class=\"hljs-string\">'心理罪'</span>, <span class=\"hljs-attr\">percent</span>: <span class=\"hljs-number\">0.15</span>, <span class=\"hljs-attr\">a</span>: <span class=\"hljs-string\">'1'</span> },\n        { <span class=\"hljs-attr\">name</span>: <span class=\"hljs-string\">'寻梦环游记'</span>, <span class=\"hljs-attr\">percent</span>: <span class=\"hljs-number\">0.05</span>, <span class=\"hljs-attr\">a</span>: <span class=\"hljs-string\">'1'</span> },\n        { <span class=\"hljs-attr\">name</span>: <span class=\"hljs-string\">'其他'</span>, <span class=\"hljs-attr\">percent</span>: <span class=\"hljs-number\">0.02</span>, <span class=\"hljs-attr\">a</span>: <span class=\"hljs-string\">'1'</span> }\n      ]\n    }\n  }\n}\n</span><span class=\"hljs-tag\">&lt;/<span class=\"hljs-name\">script</span>&gt;</span>\n\n\n</code></pre>",
    "oriHeight": "270px",
    "height": "270px",
    "noBackgroundColor": "true",
    "order": 999
  },
  {
    "file": "v-chart/area_empty",
    "title": "区域图（存在空值）",
    "code": "<pre class=\"hljs\"><code><span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">template</span>&gt;</span>\n  <span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">div</span>&gt;</span>\n    <span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">v-chart</span> <span class=\"hljs-attr\">:data</span>=<span class=\"hljs-string\">\"data\"</span>&gt;</span>\n      <span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">v-tooltip</span> <span class=\"hljs-attr\">show-crosshairs</span> /&gt;</span>\n      <span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">v-area</span> <span class=\"hljs-attr\">series-field</span>=<span class=\"hljs-string\">\"type\"</span> <span class=\"hljs-attr\">shape</span>=<span class=\"hljs-string\">\"smooth\"</span>/&gt;</span>\n      <span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">v-legend</span> <span class=\"hljs-attr\">disabled</span> /&gt;</span>\n      <span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">v-line</span> <span class=\"hljs-attr\">series-field</span>=<span class=\"hljs-string\">\"type\"</span> <span class=\"hljs-attr\">shape</span>=<span class=\"hljs-string\">\"smooth\"</span>/&gt;</span>\n    <span class=\"hljs-tag\">&lt;/<span class=\"hljs-name\">v-chart</span>&gt;</span>\n  <span class=\"hljs-tag\">&lt;/<span class=\"hljs-name\">div</span>&gt;</span>\n<span class=\"hljs-tag\">&lt;/<span class=\"hljs-name\">template</span>&gt;</span>\n\n<span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">script</span>&gt;</span><span class=\"javascript\">\n<span class=\"hljs-keyword\">import</span> { VChart, VLine, VArea, VTooltip, VLegend } <span class=\"hljs-keyword\">from</span> <span class=\"hljs-string\">'vux'</span>\n\n<span class=\"hljs-comment\">/**\n*[\n* {\"year\":\"1986\",\"type\":\"ACME\",\"value\":162},\n* {\"year\":\"1986\",\"type\":\"Compitor\",\"value\":42}\n*]\n*/</span>\n<span class=\"hljs-keyword\">import</span> data <span class=\"hljs-keyword\">from</span> <span class=\"hljs-string\">'./area_empty.json'</span>\n\n<span class=\"hljs-keyword\">export</span> <span class=\"hljs-keyword\">default</span> {\n  <span class=\"hljs-attr\">components</span>: {\n    VChart,\n    VLine,\n    VArea,\n    VTooltip,\n    VLegend\n  },\n  data () {\n    <span class=\"hljs-keyword\">return</span> {\n      data\n    }\n  }\n}\n</span><span class=\"hljs-tag\">&lt;/<span class=\"hljs-name\">script</span>&gt;</span>\n\n</code></pre>",
    "oriHeight": "270px",
    "height": "270px",
    "noBackgroundColor": "true",
    "order": 999
  },
  {
    "file": "v-chart/point",
    "title": "散点图",
    "code": "<pre class=\"hljs\"><code><span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">template</span>&gt;</span>\n  <span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">v-chart</span> <span class=\"hljs-attr\">:data</span>=<span class=\"hljs-string\">\"data\"</span>&gt;</span>\n    <span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">v-scale</span> <span class=\"hljs-attr\">x</span> <span class=\"hljs-attr\">field</span>=<span class=\"hljs-string\">\"height\"</span> /&gt;</span>\n    <span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">v-scale</span> <span class=\"hljs-attr\">y</span> <span class=\"hljs-attr\">field</span>=<span class=\"hljs-string\">\"weight\"</span> /&gt;</span>\n    <span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">v-tooltip</span> <span class=\"hljs-attr\">disabled</span> /&gt;</span>\n    <span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">v-point</span>\n      <span class=\"hljs-attr\">series-field</span>=<span class=\"hljs-string\">\"gender\"</span>\n      <span class=\"hljs-attr\">:styles</span>=<span class=\"hljs-string\">\"{\n        fillOpacity: 0.65\n      }\"</span>&gt;</span><span class=\"hljs-tag\">&lt;/<span class=\"hljs-name\">v-point</span>&gt;</span>\n  <span class=\"hljs-tag\">&lt;/<span class=\"hljs-name\">v-chart</span>&gt;</span>\n<span class=\"hljs-tag\">&lt;/<span class=\"hljs-name\">template</span>&gt;</span>\n\n<span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">script</span>&gt;</span><span class=\"javascript\">\n<span class=\"hljs-keyword\">import</span> { VChart, VPoint, VAxis, VTooltip, VScale } <span class=\"hljs-keyword\">from</span> <span class=\"hljs-string\">'vux'</span>\n\n<span class=\"hljs-comment\">/**\n* [\n*   {\"gender\":\"female\",\"height\":161.2,\"weight\":51.6},\n*   {\"gender\":\"female\",\"height\":167.5,\"weight\":59}\n* ]\n*/</span>\n<span class=\"hljs-keyword\">import</span> data <span class=\"hljs-keyword\">from</span> <span class=\"hljs-string\">'./point.json'</span>\n\n<span class=\"hljs-keyword\">export</span> <span class=\"hljs-keyword\">default</span> {\n  <span class=\"hljs-attr\">components</span>: {\n    VChart,\n    VPoint,\n    VAxis,\n    VTooltip,\n    VScale\n  },\n  data () {\n    <span class=\"hljs-keyword\">return</span> {\n      data\n    }\n  }\n}\n</span><span class=\"hljs-tag\">&lt;/<span class=\"hljs-name\">script</span>&gt;</span>\n\n</code></pre>",
    "oriHeight": "270px",
    "height": "270px",
    "noBackgroundColor": "true",
    "order": 999
  },
  {
    "file": "v-chart/area_compare",
    "title": "对比面积图：美国、苏联核储备对比",
    "code": "<pre class=\"hljs\"><code><span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">template</span>&gt;</span>\n  <span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">div</span>&gt;</span>\n    <span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">v-chart</span> <span class=\"hljs-attr\">:data</span>=<span class=\"hljs-string\">\"data\"</span>&gt;</span>\n      <span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">v-scale</span> <span class=\"hljs-attr\">x</span> <span class=\"hljs-attr\">field</span>=<span class=\"hljs-string\">\"year\"</span> /&gt;</span>\n      <span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">v-scale</span> <span class=\"hljs-attr\">y</span> <span class=\"hljs-attr\">field</span>=<span class=\"hljs-string\">\"value\"</span> <span class=\"hljs-attr\">:min</span>=<span class=\"hljs-string\">\"0\"</span> <span class=\"hljs-attr\">:tick-count</span>=<span class=\"hljs-string\">\"5\"</span> /&gt;</span>\n      <span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">v-area</span> <span class=\"hljs-attr\">shape</span>=<span class=\"hljs-string\">\"smooth\"</span> <span class=\"hljs-attr\">series-field</span>=<span class=\"hljs-string\">\"country\"</span> /&gt;</span>\n      <span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">v-line</span> <span class=\"hljs-attr\">shape</span>=<span class=\"hljs-string\">\"smooth\"</span> <span class=\"hljs-attr\">series-field</span>=<span class=\"hljs-string\">\"country\"</span> /&gt;</span>\n      <span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">v-tooltip</span> <span class=\"hljs-attr\">show-value-in-legend</span> /&gt;</span>\n      <span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">v-axis</span> <span class=\"hljs-attr\">y</span> <span class=\"hljs-attr\">:label</span>=<span class=\"hljs-string\">\"labelFormat\"</span>/&gt;</span>\n    <span class=\"hljs-tag\">&lt;/<span class=\"hljs-name\">v-chart</span>&gt;</span>\n  <span class=\"hljs-tag\">&lt;/<span class=\"hljs-name\">div</span>&gt;</span>\n<span class=\"hljs-tag\">&lt;/<span class=\"hljs-name\">template</span>&gt;</span>\n\n<span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">script</span>&gt;</span><span class=\"javascript\">\n<span class=\"hljs-keyword\">import</span> { VChart, VLine, VArea, VTooltip, VScale, VAxis } <span class=\"hljs-keyword\">from</span> <span class=\"hljs-string\">'vux'</span>\n\n<span class=\"hljs-comment\">/**\n* [\n*  {\"country\":\"USSR/Russia\",\"value\":4500,\"year\":2016},\n*  {\"country\":\"USSR/Russia\",\"value\":4500,\"year\":2017}\n* ]\n*/</span>\n<span class=\"hljs-keyword\">import</span> data <span class=\"hljs-keyword\">from</span> <span class=\"hljs-string\">'./area_compare.json'</span>\n\n<span class=\"hljs-keyword\">export</span> <span class=\"hljs-keyword\">default</span> {\n  <span class=\"hljs-attr\">components</span>: {\n    VChart,\n    VLine,\n    VArea,\n    VTooltip,\n    VScale,\n    VAxis\n  },\n  data () {\n    <span class=\"hljs-keyword\">return</span> {\n      <span class=\"hljs-attr\">labelFormat</span>: <span class=\"hljs-function\"><span class=\"hljs-keyword\">function</span> (<span class=\"hljs-params\">text</span>) </span>{\n        <span class=\"hljs-keyword\">return</span> {\n          <span class=\"hljs-attr\">text</span>: text / <span class=\"hljs-number\">1000</span> + <span class=\"hljs-string\">'k'</span>\n        }\n      },\n      data\n    }\n  }\n}\n</span><span class=\"hljs-tag\">&lt;/<span class=\"hljs-name\">script</span>&gt;</span>\n\n</code></pre>",
    "oriHeight": "270px",
    "height": "270px",
    "noBackgroundColor": "true",
    "order": 999
  },
  {
    "file": "v-chart/area_basic",
    "title": "基础面积图",
    "code": "<pre class=\"hljs\"><code><span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">template</span>&gt;</span>\n  <span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">div</span>&gt;</span>\n    <span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">v-chart</span> <span class=\"hljs-attr\">:data</span>=<span class=\"hljs-string\">\"data\"</span>&gt;</span>\n      <span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">v-scale</span> <span class=\"hljs-attr\">x</span> <span class=\"hljs-attr\">:tick-count</span>=<span class=\"hljs-string\">\"0\"</span> /&gt;</span>\n      <span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">v-scale</span> <span class=\"hljs-attr\">y</span> <span class=\"hljs-attr\">:min</span>=<span class=\"hljs-string\">\"0\"</span> /&gt;</span>\n      <span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">v-tooltip</span> <span class=\"hljs-attr\">show-crosshairs</span> <span class=\"hljs-attr\">show-x-value</span>/&gt;</span>\n      <span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">v-area</span> /&gt;</span>\n      <span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">v-line</span> /&gt;</span>\n    <span class=\"hljs-tag\">&lt;/<span class=\"hljs-name\">v-chart</span>&gt;</span>\n  <span class=\"hljs-tag\">&lt;/<span class=\"hljs-name\">div</span>&gt;</span>\n<span class=\"hljs-tag\">&lt;/<span class=\"hljs-name\">template</span>&gt;</span>\n\n<span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">script</span>&gt;</span><span class=\"javascript\">\n<span class=\"hljs-keyword\">import</span> { VChart, VLine, VArea, VTooltip, VScale, VAxis } <span class=\"hljs-keyword\">from</span> <span class=\"hljs-string\">'vux'</span>\n\n<span class=\"hljs-keyword\">export</span> <span class=\"hljs-keyword\">default</span> {\n  <span class=\"hljs-attr\">components</span>: {\n    VChart,\n    VLine,\n    VArea,\n    VTooltip,\n    VScale,\n    VAxis\n  },\n  data () {\n    <span class=\"hljs-keyword\">return</span> {\n      <span class=\"hljs-attr\">data</span>: [\n        { <span class=\"hljs-attr\">time</span>: <span class=\"hljs-string\">'Jan.'</span>, <span class=\"hljs-attr\">tem</span>: <span class=\"hljs-number\">1000</span> },\n        { <span class=\"hljs-attr\">time</span>: <span class=\"hljs-string\">'Feb.'</span>, <span class=\"hljs-attr\">tem</span>: <span class=\"hljs-number\">2200</span> },\n        { <span class=\"hljs-attr\">time</span>: <span class=\"hljs-string\">'Mar.'</span>, <span class=\"hljs-attr\">tem</span>: <span class=\"hljs-number\">2000</span> },\n        { <span class=\"hljs-attr\">time</span>: <span class=\"hljs-string\">'Apr.'</span>, <span class=\"hljs-attr\">tem</span>: <span class=\"hljs-number\">2600</span> },\n        { <span class=\"hljs-attr\">time</span>: <span class=\"hljs-string\">'May.'</span>, <span class=\"hljs-attr\">tem</span>: <span class=\"hljs-number\">2000</span> },\n        { <span class=\"hljs-attr\">time</span>: <span class=\"hljs-string\">'Jun.'</span>, <span class=\"hljs-attr\">tem</span>: <span class=\"hljs-number\">2600</span> },\n        { <span class=\"hljs-attr\">time</span>: <span class=\"hljs-string\">'Jul.'</span>, <span class=\"hljs-attr\">tem</span>: <span class=\"hljs-number\">2800</span> },\n        { <span class=\"hljs-attr\">time</span>: <span class=\"hljs-string\">'Aug.'</span>, <span class=\"hljs-attr\">tem</span>: <span class=\"hljs-number\">2000</span> }\n      ]\n    }\n  }\n}\n</span><span class=\"hljs-tag\">&lt;/<span class=\"hljs-name\">script</span>&gt;</span>\n\n</code></pre>",
    "oriHeight": "270px",
    "height": "270px",
    "noBackgroundColor": "true",
    "order": 999
  },
  {
    "file": "v-chart/prevent_render",
    "title": "自定义渲染逻辑",
    "code": "<pre class=\"hljs\"><code><span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">template</span>&gt;</span>\n  <span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">div</span>&gt;</span>\n    <span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">v-chart</span>\n      <span class=\"hljs-attr\">prevent-render</span>\n      @<span class=\"hljs-attr\">on-render</span>=<span class=\"hljs-string\">\"renderChart\"</span>&gt;</span><span class=\"hljs-tag\">&lt;/<span class=\"hljs-name\">v-chart</span>&gt;</span>\n  <span class=\"hljs-tag\">&lt;/<span class=\"hljs-name\">div</span>&gt;</span>\n<span class=\"hljs-tag\">&lt;/<span class=\"hljs-name\">template</span>&gt;</span>\n\n<span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">script</span>&gt;</span><span class=\"javascript\">\n<span class=\"hljs-keyword\">import</span> { VChart } <span class=\"hljs-keyword\">from</span> <span class=\"hljs-string\">'vux'</span>\n\n<span class=\"hljs-keyword\">export</span> <span class=\"hljs-keyword\">default</span> {\n  <span class=\"hljs-attr\">components</span>: {\n    VChart\n  },\n  <span class=\"hljs-attr\">methods</span>: {\n    renderChart ({ chart }) {\n      <span class=\"hljs-keyword\">const</span> data = [ { <span class=\"hljs-attr\">x</span>: <span class=\"hljs-string\">'1'</span>, <span class=\"hljs-attr\">y</span>: <span class=\"hljs-number\">85</span> } ]\n      chart.source(data, {\n        <span class=\"hljs-attr\">y</span>: {\n          <span class=\"hljs-attr\">max</span>: <span class=\"hljs-number\">100</span>,\n          <span class=\"hljs-attr\">min</span>: <span class=\"hljs-number\">0</span>\n        }\n      })\n      chart.axis(<span class=\"hljs-literal\">false</span>)\n      chart.tooltip(<span class=\"hljs-literal\">false</span>)\n      chart.coord(<span class=\"hljs-string\">'polar'</span>, {\n        <span class=\"hljs-attr\">transposed</span>: <span class=\"hljs-literal\">true</span>,\n        <span class=\"hljs-attr\">innerRadius</span>: <span class=\"hljs-number\">0.8</span>,\n        <span class=\"hljs-attr\">radius</span>: <span class=\"hljs-number\">0.85</span>\n      })\n      chart.guide().arc({\n        <span class=\"hljs-attr\">start</span>: [ <span class=\"hljs-number\">0</span>, <span class=\"hljs-number\">0</span> ],\n        <span class=\"hljs-attr\">end</span>: [ <span class=\"hljs-number\">1</span>, <span class=\"hljs-number\">99.98</span> ],\n        <span class=\"hljs-attr\">top</span>: <span class=\"hljs-literal\">false</span>,\n        <span class=\"hljs-attr\">style</span>: {\n          <span class=\"hljs-attr\">lineWidth</span>: <span class=\"hljs-number\">20</span>,\n          <span class=\"hljs-attr\">stroke</span>: <span class=\"hljs-string\">'#ccc'</span>\n        }\n      })\n      chart.guide().text({\n        <span class=\"hljs-attr\">position</span>: [ <span class=\"hljs-string\">'50%'</span>, <span class=\"hljs-string\">'50%'</span> ],\n        <span class=\"hljs-attr\">content</span>: <span class=\"hljs-string\">'85%'</span>,\n        <span class=\"hljs-attr\">style</span>: {\n          <span class=\"hljs-attr\">fontSize</span>: <span class=\"hljs-number\">24</span>,\n          <span class=\"hljs-attr\">fill</span>: <span class=\"hljs-string\">'#1890FF'</span>\n        }\n      })\n      chart.interval()\n        .position(<span class=\"hljs-string\">'x*y'</span>)\n        .size(<span class=\"hljs-number\">20</span>)\n        .animate({\n          <span class=\"hljs-attr\">appear</span>: {\n            <span class=\"hljs-attr\">duration</span>: <span class=\"hljs-number\">1200</span>,\n            <span class=\"hljs-attr\">easing</span>: <span class=\"hljs-string\">'cubicIn'</span>\n          }\n        })\n      chart.render()\n    }\n  }\n}\n</span><span class=\"hljs-tag\">&lt;/<span class=\"hljs-name\">script</span>&gt;</span>\n\n\n</code></pre>",
    "oriHeight": "270px",
    "height": "270px",
    "noBackgroundColor": "true",
    "order": 999
  }
]

  let componentList = []
  if (Array.isArray(metas.items)) {
    try {
      metas.items.forEach((item, index) => {
        const meta = {
          name: item,
          meta: metas[item]
        }
        if (meta.meta.props === null) {
          delete meta.meta.props
        }
        if (index === metas.items.length - 1) {
          if (meta.meta) {
            meta.meta.variables = metas.variables
          }
        }
        componentList.push(meta)
      })
    } catch (e) {
      console.log(e)
    }
  } else {
    componentList.push({
      meta: metas
    })
  }
  const gitMetas = require('./v-chart_git_metas.json')
  const demoCode = decodeURIComponent(``)

  const domainMap = {
    'development': 'http://localhost:8080/',
    'production': 'https://vux.li/demos/v2/'
  }

  export default {
    head: {
      title: 'VChart component tutorial | VUX - Vue.js Mobile UI Component Framework',
      meta: [{
        name: 'description',
        content: 'Vue component v-chart for the VUX framework.'
      }, {
        name: 'keywords',
        content: 'v-chart, vue-v-chart, vux-v-chart, vue mobile components'
      }, {
        property: 'og:title',
        content: 'VChart component tutorial | VUX - Vue.js Mobile UI Component Framework'
      }, {
        property: 'og:description',
        content: 'Vue component v-chart for the VUX framework.'
      }],
      // https://support.google.com/webmasters/answer/189077?hl=en
      link: [{"rel":"alternate","hreflang":"zh-CN","href":"/zh-CN/components/v-chart.html"}],
      script: [
        {
          innerHTML:'{"@context":"http://schema.org/","@type":"SoftwareApplication","name":"Vue Component v-chart","screenshot":"","description":"Vue.js component for VUX","url":"/en/components/v-chart.html","applicationCategory":"Component","author":{"@type":"Organization","name":"VUX","url":"https://vux.li"},"downloadUrl":"https://vux.li","softwareVersion":"2.9.2","aggregateRating":{"@type":"AggregateRating","ratingValue":5,"reviewCount":5},"operatingSystem":"iOS >= 7, Android >= 4.1","offers":{"@type":"Offer","price":0,"priceCurrency":"USD","availability":"http://schema.org/InStock"}}',
          type: 'application/ld+json'
        }
      ],
      __dangerouslyDisableSanitizers: ['script']
    },
    filters: {
      parseCode (str) {
        return str.replace(/`(.*?)`/g, '<code>$1</code>')
      }
    },
    async mounted () {
      const rs = await Axios.get('https://api.github.com/search/issues?q=repo:airyland/vux%20label:component/' + this.componentName)
      this.issues = rs.data.items
      this.hasReady = true
    },
    watch: {
      async sourceCodeDialogVisibility (val) {
        if (val) {
          await this.$nextTick()
          const mask = document.querySelector('.v-modal')
          mask && mask.addEventListener('click', () => {
            this.sourceCodeDialogVisibility = false
          })
        }
      }
    },
    methods: {
      onCopyError () {
        this.$message({
          type: 'error',
          message: 'copy fail!'
        })
      },
      onCopy () {
        this.$message({
          type: 'success',
          message: 'copy done!'
        })
      },
      showSourceCode () {
        this.sourceCodeDialogVisibility = true
      },
      getTypeHTML (type) {
        type = type || 'String'
        if (/,/.test(type)) {
          const list = type.split(',').map(function (one) {
            return one.replace(/^s+|s+$/g, '')
          }).map(function (one) {
            const type = one ?  one.toLowerCase() : 'string'
            return '<span class="type">' + type + '</span>'
          })
          return list.join('<br>')
        } else {
          type = type ?  type.toLowerCase() : 'string'
          return '<span class="type">' + type + '</span>'
        }
      }
    },
    computed: {
      lang () {
        if (this.$route.path.indexOf('/en/') !== -1) {
          return 'en'
        }
        if (this.$route.path.indexOf('/zh-CN/') !== -1) {
          return 'zh-CN'
        }
        return 'en'
      }
    },
    data () {
      return {
        demos,
        isBeta: true,
        hasReady: false,
        issues: [],
        componentName: 'v-chart',
        demoCode,
        sourceCodeDialogVisibility: false,
        showQr: false,
        metas: metas,
        gitMetas,
        componentList,
        localImportCode: `import { VChart, VLine, VArea, VBar, VPie, VPoint, VScale, VAxis, VGuide, VTooltip, VLegend, VGuide } from 'vux'

export default {
  components: {
    VChart,
    VLine,
    VArea,
    VBar,
    VPie,
    VPoint,
    VScale,
    VAxis,
    VGuide,
    VTooltip,
    VLegend,
    VGuide
  }
}`,
        globalImportCode: `// you can also register globally

import Vue from 'vue'
import { VChart, VLine, VArea, VBar, VPie, VPoint, VScale, VAxis, VGuide, VTooltip, VLegend, VGuide } from 'vux'

Vue.component('v-chart', VChart)
Vue.component('v-line', VLine)
Vue.component('v-area', VArea)
Vue.component('v-bar', VBar)
Vue.component('v-pie', VPie)
Vue.component('v-point', VPoint)
Vue.component('v-scale', VScale)
Vue.component('v-axis', VAxis)
Vue.component('v-guide', VGuide)
Vue.component('v-tooltip', VTooltip)
Vue.component('v-legend', VLegend)
Vue.component('v-guide', VGuide)
`,
        needImport: true,
        toc: [{"title":"Intro","anchor":"intro"},{"title":"Install","anchor":"install"},{"title":"Examples","anchor":"examples","list":[{"title":"基本折线图","anchor":"examples:基本折线图"},{"title":"折线图:平滑曲线","anchor":"examples:折线图:平滑曲线"},{"title":"动态数据：实时折线","anchor":"examples:动态数据：实时折线"},{"title":"折线图：渐变","anchor":"examples:折线图：渐变"},{"title":"折线图:对比","anchor":"examples:折线图:对比"}]},{"title":"API","anchor":"api","list":[{"title":"<v-chart>","anchor":"components:v-chart"},{"title":"<v-line>","anchor":"components:v-line"},{"title":"<v-area>","anchor":"components:v-area"},{"title":"<v-bar>","anchor":"components:v-bar"},{"title":"<v-pie>","anchor":"components:v-pie"},{"title":"<v-point>","anchor":"components:v-point"},{"title":"<v-scale>","anchor":"components:v-scale"},{"title":"<v-axis>","anchor":"components:v-axis"},{"title":"<v-guide>","anchor":"components:v-guide"},{"title":"<v-tooltip>","anchor":"components:v-tooltip"},{"title":"<v-legend>","anchor":"components:v-legend"},{"title":"<v-guide>","anchor":"components:v-guide"}]},{"title":"Tips","anchor":"tips"},{"title":"Contributors","anchor":"contributors"},{"title":"Changelog","anchor":"changelog"}],
        domain: domainMap[process.env.NODE_ENV]
      }
    }
  }
  </script>

  <style>
  .component-box {
    position: relative;
  }
  .component-demo {
    position: absolute;
    right: 5px;
    top: 15px;
  }
  .prop-color {
    display: inline-block;
    width: 10px;
    height: 10px;
    border: 1px solid #aaa;
  }
  .changelog-version {
    width: 110px;
    display: inline-block;
  }
  .component-extra-links {
    position: relative;
    font-size: 12px;
  }
  .component-extra-links a {
    padding-right: 10px;
    color: #999;
  }
  </style>
    