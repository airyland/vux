
  <template>
    <div class="component-box" :class="demos.length ? 'components-with-toc' : ''">

      <div :class="demos.length ? 'component-header-v2' : 'component-header-v1'">
        <a class="anchor" id="intro">XAddress</a>
        <div class="title-box">

          <el-badge value="Beta" v-if="isBeta">
            <h1 class="vux-component-name">XAddress</h1>
          </el-badge>
          <h1 v-else class="vux-component-name">XAddress</h1>

          <p class="component-extra-links">
            <a href="https://vux.li/demos/v2/#/component/x-address" target="_blank">demo url</a>
            <a v-if="!demos.length" href="https://github.com/airyland/vux/blob/v2/src/demos/XAddress.vue" target="_blank" @click.prevent="showSourceCode">demo source code</a>
            <a href="https://github.com/airyland/vux/blob/v2/src/components/x-address/metas.yml" target="_blank">edit document</a>
            <a href="https://github.com/airyland/vux/blob/v2/src/components/x-address/" target="_blank">component source code</a>
            <el-popover trigger="hover" v-if="hasReady">
              <div style="width:100%;text-align:center;">
                <img class="qr" width="100" src="https://qr.vux.li/api.php?text=https%3A%2F%2Fvux.li%2Fdemos%2Fv2%2F%23%2Fcomponent%2Fx-address"/>
              </div>
              <a href="javascript:" slot="reference">
              view demos on mobile
              </a>
            </el-popover>
          </p>

          <div class="component-description">
            <template v-if="false">
            
            </template>
          </div>

        </div>

        <div v-if="!demos.length" class="component-demo" style="width:377px;height:600px;display:inline-block;border:1px solid #ececec;border-radius:5px;overflow:hidden;z-index:2500;">
          <iframe src="https://vux.li/demos/v2?locale=en&transition=none/#/component/x-address" width="375" height="600" border="0" frameborder="0"></iframe>
        </div>
        <div class="toc">
          <ul v-for="t in toc">
            <li>
              <a :href="'#' + (t.anchor || t.title)">{{ t.title }}</a>
              <ul v-if="t.list" v-for="_t in t.list">
                <li><a :href="'#' + _t.anchor">{{ _t.title.slice(0, 12) }}</a></li>
              </ul>
            </li>
          </ul>
        </div>
      
        <template v-if="needImport">
          <a class="anchor" id="install">Install</a>
          <h2>Install</h2>
          <el-tabs>
            <el-tab-pane label="Local Registration">
              <div class="import-code-box">
              <el-tooltip content="click to copy" placement="top">
                <span
                  v-clipboard:copy="localImportCode"
                  v-clipboard:success="onCopy"
                  v-clipboard:error="onCopyError">
                  <el-icon class="el-icon-document"></el-icon>
                </span>
              </el-tooltip>
              <pre class="hljs"><code><span class="hljs-keyword">import</span> { XAddress } <span class="hljs-keyword">from</span> <span class="hljs-string">'vux'</span>

<span class="hljs-keyword">export</span> <span class="hljs-keyword">default</span> {
  <span class="hljs-attr">components</span>: {
    XAddress
  }
}</code></pre>
            </div>
            </el-tab-pane>
            <el-tab-pane label="Global Registration">
              <div class="import-code-box">
                <el-tooltip content="click to copy" placement="top">
                  <span
                    v-clipboard:copy="globalImportCode"
                    v-clipboard:success="onCopy"
                    v-clipboard:error="onCopyError">
                    <el-icon class="el-icon-document"></el-icon>
                  </span>
                </el-tooltip>
                <pre class="hljs"><code><span class="hljs-comment">// you can also register globally</span>

<span class="hljs-keyword">import</span> Vue <span class="hljs-keyword">from</span> <span class="hljs-string">'vue'</span>
<span class="hljs-keyword">import</span> { XAddress } <span class="hljs-keyword">from</span> <span class="hljs-string">'vux'</span>

Vue.component(<span class="hljs-string">'x-address'</span>, XAddress)
</code></pre>
              </div> 
            </el-tab-pane>
          </el-tabs>   
        </template>

        <template v-else>
          <div class="tip">
            <p>You don't need to import this component.</p>
          </div>
        </template>

        <div class="tip" style="width:600px;" v-if="metas.tip">
          
        </div>
      
        <h2 v-if="metas.example">example</h2>
        <div v-if="metas.example" style="width:600px;">
          
        </div>
      </div>

      <div v-if="metas.extra && metas.extra['en']">
        <pre class="hljs"><code>  <span class="hljs-tag">&lt;<span class="hljs-name">group</span>&gt;</span>
    <span class="hljs-tag">&lt;<span class="hljs-name">x-address</span> <span class="hljs-attr">title</span>=<span class="hljs-string">"title"</span> <span class="hljs-attr">v-model</span>=<span class="hljs-string">"value"</span>&gt;</span><span class="hljs-tag">&lt;/<span class="hljs-name">x-address</span>&gt;</span>
  <span class="hljs-tag">&lt;/<span class="hljs-name">group</span>&gt;</span>
</code></pre>
<pre class="hljs"><code><span class="hljs-keyword">import</span> { XAddress } <span class="hljs-keyword">from</span> <span class="hljs-string">'vux'</span>

<span class="hljs-comment">// you can import built-in data</span>
<span class="hljs-keyword">import</span> { XAddress, ChinaAddressV3Data } <span class="hljs-keyword">from</span> <span class="hljs-string">'vux'</span>

<span class="hljs-comment">// if you need older data</span>
<span class="hljs-keyword">import</span> { XAddress, ChinaAddressV1Data } <span class="hljs-keyword">from</span> <span class="hljs-string">'vux'</span>
</code></pre>
<div class="tip">
<p>you can view source data at <a href="https://github.com/airyland/vux/tree/v2/src/datas">src/datas</a>.</p>
</div>
<div class="tip">
<p><code>x-address</code> should be used in <code>Group</code></p>
</div>

      </div>
      <div v-if="metas.extra && !metas.extra['en']">
        
      </div>
      
      <a v-if="demos.length" class="anchor" id="examples">Examples</a>
      <br/>
      <template v-if="demos.length" v-for="demo in demos">
        <a class="anchor" :id="'examples:' + demo.title">{{ demo.title }}</a>
        <br/>
        <div class="demo-header">
          <span class="demo-title">{{ demo.title }}</span>
        </div>
        <div class="demos" :style="{height: demo.height}">
          <div class="demo-iframe-box">
            <lazy-component>
              <iframe
                :src="domain + '?no-background-color=' + demo.noBackgroundColor +'&locale=en&transition=none&hide-nav=true&hide-tab-bar=true#/components/' + demo.file"
                width="375"
                height="600"
                border="0"
                frameborder="0"
                style="margin: 0 auto;"></iframe>
            </lazy-component>
          </div>
          <div class="demo-code-box" :style="{overflow: demo.height === demo.oriHeight ? 'hidden' : 'scroll'}">
            <div v-html="demo.code" contenteditable></div>
            <div v-if="demo.height === demo.oriHeight" class="demo-code-masker" @click="demo.height='auto'">
              <div>
                  <img class="demo-qr" width="100" :src="'https://qr.vux.li/api.php?text=' + encodeURIComponent(domain + '?locale=en#/components/' + demo.file)"/>
                  <br/>
                  <span>
                    <el-icon class="el-icon-arrow-left"/>
                    <el-icon class="el-icon-arrow-right"/>
                    Show code
                  <br/>
                  <!--<span class="demo-path">src/demos/{{ demo.file }}.vue</span>-->
                </span>
              </div>
            </div>
            <span v-if="demo.height === 'auto'" class="hide-code" @click="demo.height=demo.oriHeight">
              <el-icon class="el-icon-close"></el-icon>
            </span>
          </div>
        </div>
      </template>

      <template v-for="component in componentList">
        <div>
          <a v-if="componentList.length > 1" class="anchor" :id="'components:' + component.name">{{ component.name }}</a>
          <a v-else class="anchor" id="api">API</a>
          <br/>
          <h2
            v-show="componentList.length > 1"
            class="vux-component-name-sub-item">{{ component.name }}</h2>
            
          <template v-if="component.meta.items && component.meta.description">
            <div v-html="component.meta.description"></div>
          </template>

          <template v-if="component.meta.props">
            <h2>Props</h2>
            <table>
              <thead>
                <tr>
                  <td>name</td>
                  <td style="width:48px;">type</td>
                  <td>default</td>
                  <td>description</td>
                  <td>required version</td>
                </tr>
              </thead>
              <tbody>
                <tr v-for="(prop, i) in component.meta.props">
                  <td class="prop-name">
                    <el-tooltip content="click to copy" placement="left" :hide-after="0" :open-delay="50">
                      <span
                      v-clipboard:copy="i"
                      v-clipboard:success="onCopy">{{ i }}</span>
                    </el-tooltip>
                  </td>
                  <td v-html="getTypeHTML(prop.type)"></td>
                  <td>{{ prop.default}}</td>
                  <td v-html="prop['en'].replace(/`(.*?)`/g, '<code>$1</code>')"></td>
                  <td>{{ prop.version || '--'}}</td>
                </tr>
              </tbody>
            </table>
          </template>

          <template v-if="component.meta.events">
            <h2>Events</h2>
            <table>
              <thead>
                <tr>
                  <td>name</td>
                  <td>params</td>
                  <td>description</td>
                  <td>required version</td>
                </tr>
              </thead>
              <tbody>
                <tr v-for="(event, i) in component.meta.events">
                  <td class="prop-name">
                    <el-tooltip content="click to copy" placement="left" :hide-after="0" :open-delay="50">
                      <span
                      v-clipboard:copy="'@' + i"
                      v-clipboard:success="onCopy">@{{ i }}</span>
                    </el-tooltip>
                  </td>
                  <td v-html="event.params ? event.params.replace(/`(.*?)`/g, '<code>$1</code>') : '--'"></td>
                  <td v-html="event['en'] ? event['en'].replace(/`(.*?)`/g, '<code>$1</code>') : '--'"></td>
                  <td>{{ event['version'] || '--' }}</td>
                </tr>
              </tbody>
            </table>
          </template>
      

          <template v-if="component.meta.slots">
            <h2>Slots</h2>
            <table>
              <thead>
                <tr>
                  <td>name</td>
                  <td>description</td>
                  <td>required version</td>
                </tr>
              </thead>
              <tbody>
                <tr v-for="(slot, i) in component.meta.slots" :class="{'slot-disabled': slot['status'] === 'deprecated'}">
                  <td class="prop-name">
                    <el-tooltip content="click to copy" placement="left" :hide-after="0" :open-delay="50">
                      <span
                      v-clipboard:copy="i"
                      v-clipboard:success="onCopy">{{ i === 'default' ? 'default' : i }}</span>
                    </el-tooltip>
                  </td>
                  <td v-html="slot['en'] ? slot['en'].replace(/`(.*?)`/g, '<code>$1</code>') : ''"></td>
                  <td>{{ slot['version'] || '--' }}</td>
                </tr>
              </tbody>
            </table>
          </template>
          
          <template v-if="component.meta.methods">
            <h2>Functions</h2>
            <table>
              <thead>
                <tr>
                  <td>name</td>
                  <td>params</td>
                  <td>description</td>
                  <td>required version</td>
                </tr>
              </thead>
              <tbody>
                <tr v-for="(method, i) in component.meta.methods">
                  <td class="prop-name">
                    <el-tooltip content="click to copy" placement="left" :hide-after="0" :open-delay="50">
                      <span
                      v-clipboard:copy="i"
                      v-clipboard:success="onCopy">{{ i }}</span>
                    </el-tooltip>
                  </td>
                  <td v-html="method['params'] ? method['params'].replace(/`(.*?)`/g, '<code>$1</code>') : ''"></td>
                  <td v-html="method['en'].replace(/`(.*?)`/g, '<code>$1</code>')"></td>
                  <td>{{ method['version'] }}</td>
                </tr>
              </tbody>
            </table>
          </template>

          <template v-if="component.meta.variables">
            <a class="anchor" id="variables">Variables</a>
            <br/>
            <h2>Variables</h2>
            <table>
              <thead>
                <tr>
                  <td>name</td>
                  <td>default</td>
                  <td>description</td>
                  <td>inherited name</td>
                </tr>
              </thead>
              <tbody>
                <tr v-for="(variable, i) in component.meta.variables">
                  <td class="prop-name">
                    <el-tooltip content="click to copy" placement="left" :hide-after="0" :open-delay="50">
                      <span
                      v-clipboard:copy="'@' + variable.name"
                      v-clipboard:success="onCopy">@{{ variable.name }}</span>
                    </el-tooltip>
                  </td>
                  <td>
                    <em
                      :ref="'propColor' + i"
                      v-if="!$refs['propColor' + i] || ($refs['propColor' + i][0] && $refs['propColor' + i][0].style.backgroundColor)"
                      class="prop-color"
                      :style="{ backgroundColor: variable.value }">
                    </em>
                    {{ variable.value }}
                  </td>
                  <td>{{ variable['desc']['en'] || '--' }}</td>
                  <td>{{ variable.inherited_name }}</td>
                </tr>
              </tbody>
            </table>
          </template>
      
          <template v-if="component.meta.tips && component.meta.tips['en']">
            <a class="anchor" id="tips">Tips</a>
            <br>
            <h2>Tips</h2>
            <div>
              <ul>
                <li v-for="tip in component.meta.tips['en']">
                <el-tag size="mini" type="success" class="component-tip-tag">Q</el-tag> <span class="component-tip-question">{{ tip.q }}</span>
                <div v-html="tip.a" class="tip-answer-box"></div>
                </li>
              </ul>
            </div>
          </template>
        </div>
      </template>

      <!--<h2>社区相关讨论</h2>
      [即将上线]
      -->
    
      <br>
      <div v-if="issues.length">
        <a class="anchor" id="Issues">Issues</a>
        <br/>
        <h2>Related issues</h2>
        <ul>
          <li v-for="issue in issues"><a target="_blank" :href="issue.html_url">#{{ issue.number}} <span style="color:#666;">{{ issue.title }}</span></a></li>
        </ul>
      </div>
      <br>
    
      <div v-if="gitMetas">
        <a class="anchor" id="contributors">Contributors</a>
        <h2>Contributors</h2>
        <p>Total commits quantity: {{ gitMetas.commitCount }}，Total contributors quantity: {{gitMetas.commitUniqueCount}}
        </p>
        <a v-for="person in gitMetas.commitMembers" class="contributor-item" :href="'https://github.com/' + person.authorName" target="_blank" :title="'contribute' + person.count">{{person.authorName}}</a>
      </div>
      <br>

      <div v-if="metas.changes">
        <a class="anchor" id="changelog">Changelog</a>
        <br/>
        <h2>Releases</h2>
        <ul v-if="metas.changes">
          <template v-for="(changelog, version) in metas.changes">
            <li v-for="log in changelog['en']">
              <router-link :to="'/en/changelog/' + version + '.html'" class="changelog-version">{{version}}</router-link> {{log}}
            </li>
          </template>
        </ul>
      </div>

      <h2 v-if="metas.references">Referrences</h2>
      <ul v-if="metas.references">
        <li v-for="link in metas.references['en']">
          <a :href="link.link" target="_blank">{{link.title}}</a>
        </li>
      </ul>

      <el-dialog
        class="sourcec-code-dialog"
        top="0"
        width="80%"
        :visible.sync="sourceCodeDialogVisibility">
        <div class="code-box" contenteditable v-html="demoCode"></div>
      </el-dialog>

    </div>
  </template>


  <script>
  import Axios from 'axios'

  // const metas = require('json-loader!yaml-loader!../../../src/components/x-address/metas.yml')
  const metas = {
  "category": {
    "en": "Form",
    "zh-CN": "表单"
  },
  "icon": "&#xe61b;",
  "import_code": "&nbsp;",
  "extra": {
    "en": "\n```html\n  <group>\n    <x-address title=\"title\" v-model=\"value\"></x-address>\n  </group>\n```\n\n``` js\nimport { XAddress } from 'vux'\n\n// you can import built-in data\nimport { XAddress, ChinaAddressV3Data } from 'vux'\n\n// if you need older data\nimport { XAddress, ChinaAddressV1Data } from 'vux'\n```\n\n::: tip\nyou can view source data at [src/datas](https://github.com/airyland/vux/tree/v2/src/datas).\n:::\n\n::: tip\n`x-address` should be used in `Group`\n:::\n",
    "zh-CN": "```html\n  <group>\n    <x-address title=\"title\" v-model=\"value\"></x-address>\n  </group>\n```\n``` js\nimport { XAddress } from 'vux'\n\n// 如果你需要引入数据，如果你的版本低于 v2.2.0，请使用 ChinaAddressData\nimport { XAddress, ChinaAddressV4Data } from 'vux'\n\n// 如果需要引入旧版数据\nimport { XAddress, ChinaAddressV2Data } from 'vux'\n```\n::: tip\n如果你需要单独引入地址数据，可以在源码[src/datas](https://github.com/airyland/vux/tree/v2/src/datas)找到。\n:::\n::: tip\n设计上 `x-address` 只能在 `Group` 中使用。但是你依然可以不在 `Group` 中使用，使用 `display:none` 隐藏然后用 :show.sync 来控制组件显示状态。\n:::\n\n\n``` html\n<x-address style=\"display:none;\" title=\"title\" v-model=\"value\" :list=\"addressData\" placeholder=\"请选择地址\" :show.sync=\"showAddress\"></x-address>\n```\n\n<p>\nv4 和 v3 的区别是在 v4 里重庆多了县列表。\n<br>\n从 `2.1.1-rc.12` 开始，`直辖区`做了简化，原来是 北京市-北京市市辖区-东城区，现在是 北京市-市辖区-东城区。组件内部做了兼容，你以`raw-value`方式传入两种写法表现和旧版本一致，不会出错。\n<br>\n<br>\n从 `2.1.1-rc.15` 开始，数据必须指定版本，原来的 `ChinaAddressData` 废弃并停留在 `v2` 版本不再更新。\n<br>\n不同版本数据差异可以从[这里](https://github.com/airyland/china-area-data)找到。\n</p>\n"
  },
  "tags": {
    "en": [
      "form",
      "address"
    ],
    "zh-CN": [
      "地址",
      "省市"
    ]
  },
  "extends": [
    "popup-picker"
  ],
  "props": {
    "raw-value": {
      "type": "Boolean",
      "default": false,
      "en": "if the initial value is `string value` instead of `id value`",
      "zh-CN": "指定初始化时绑定的数据是否为文本(即省市名，而不是id)类型，即对于非id值组件内部会转换为id。如果是异步设置value，只能使用id赋值。"
    },
    "title": {
      "type": "String",
      "default": "",
      "en": "label text",
      "zh-CN": "表单标题"
    },
    "value": {
      "type": "Array",
      "default": "",
      "en": "form value, use `v-model` for binding",
      "zh-CN": "表单值, 使用`v-model`绑定"
    },
    "list": {
      "type": "Array",
      "default": "",
      "en": "address data",
      "zh-CN": "地址列表, 可以引入内置地址数据或者用自己的数据，但是需要按照一致的数据结构。"
    },
    "inline-desc": {
      "type": "String",
      "default": "",
      "en": "description text below label",
      "zh-CN": "标题下的描述"
    },
    "placeholder": {
      "type": "String",
      "default": "",
      "en": "placeholder",
      "zh-CN": "没有值时的提示文字"
    },
    "hide-district": {
      "type": "Boolean",
      "default": false,
      "en": "if hide district column",
      "zh-CN": "是否隐藏区，即只显示省份和城市"
    },
    "value-text-align": {
      "type": "String",
      "default": "right",
      "en": "align setting of `value`",
      "zh-CN": "value 对齐方式(text-align), `v2.1.0-rc.49`开始支持"
    },
    "popup-style": {
      "version": "v2.5.2",
      "type": "Object",
      "en": "popup style",
      "zh-CN": "弹窗样式，可以用于强制指定 z-index"
    },
    "show": {
      "version": "v2.5.8",
      "type": "Boolean",
      "en": "popup show (supports the .sync modifier next)",
      "zh-CN": "显示 (支持.sync修饰 next)"
    },
    "disabled": {
      "version": "v2.9.0",
      "type": "Boolean",
      "en": "whether disabled selecting",
      "zh-CN": "是否禁用选择"
    }
  },
  "slots": {
    "title": {
      "version": "v2.3.8",
      "en": "title slot",
      "zh-CN": "title 插槽，可以使用它来添加 icon 等自定义样式，受控于 group 需要从 scope 里继承 class 和 样式"
    }
  },
  "events": {
    "on-hide": {
      "en": "emits when being closed",
      "zh-CN": "关闭后触发，当非确定时，参数为false，反之为true"
    },
    "on-show": {
      "en": "emits when being open",
      "zh-CN": "显示时触发"
    },
    "on-shadow-change": {
      "version": "v2.5.6",
      "params": "`(Array ids, Array names)`",
      "en": "emits when picker value is changed",
      "zh-CN": "picker 值变化时触发，即滑动 picker 时触发"
    }
  },
  "changes": {
    "v2.9.0": {
      "en": [
        "[feature] add prop:disabled #2641"
      ],
      "zh-CN": [
        "[feature] 添加属性 disabled 支持禁用 #2641"
      ]
    },
    "v2.8.0": {
      "en": [
        "[change] remove empty root div #2371"
      ],
      "zh-CN": [
        "[change] 去除空的根节点 #2371"
      ]
    },
    "v2.7.0": {
      "en": [
        "[fix] fix vue@2.5.0 scope issue #2076",
        "[feature] add prop:popup-title(use component:popup-header) #1866"
      ],
      "zh-CN": [
        "[fix] 兼容 vue@2.5.0 scope 更名为 slot-scope 的问题 #2076",
        "[feature] 增加属性 popup-title(使用 popup-header 组件) #1866"
      ]
    },
    "v2.6.2": {
      "en": [
        "[fix] update address data #2000"
      ],
      "zh-CN": [
        "[fix] 更新地址数据 #2000"
      ]
    },
    "v2.5.9": {
      "en": [
        "[feature] prop:show supports the .sync modifier"
      ],
      "zh-CN": [
        "[feature] prop:show 支持.sync修饰"
      ]
    },
    "v2.5.8": {
      "en": [
        "[feature] Add prop:show to control visibility"
      ],
      "zh-CN": [
        "[feature] 新增 prop:show 控制是否显示"
      ]
    },
    "v2.5.6": {
      "en": [
        "[feature] Support event:on-shadow-change #1778"
      ],
      "zh-CN": [
        "[feature] 支持在滑动 picker 时触发事件 on-shadow-change #1778"
      ]
    },
    "v2.5.2": {
      "en": [
        "[feature] Add prop:popup-style #1656"
      ],
      "zh-CN": [
        "[feature] 支持弹窗样式设置 prop:popup-style #1656"
      ]
    },
    "v2.3.8": {
      "en": [
        "[feature] Add slot:title #1389"
      ],
      "zh-CN": [
        "[feature] 添加 slot:title，方便自定义样式 #1389"
      ]
    },
    "v2.2.2": {
      "en": [
        "[feature] Support setting value by labels(beta)"
      ],
      "zh-CN": [
        "[feature] 支持使用地址文字直接赋值(测试)"
      ]
    },
    "v2.2.1-rc.6": {
      "en": [
        "[feature] Support prop:display-format"
      ],
      "zh-CN": [
        "[feature] 支持属性  display-format"
      ]
    },
    "v2.2.1-rc.3": {
      "en": [
        "[feature] Support prop:confirm-text and prop:cancel-text. #1233"
      ],
      "zh-CN": [
        "[feature] 支持设置 取消 和 确定 文字. #1233"
      ]
    },
    "v2.2.0": {
      "en": [
        "[enhance] Upgrade datas #1101"
      ],
      "zh-CN": [
        "[enhance] 更新地区数据 #1101"
      ]
    },
    "v2.1.1-rc.12": {
      "en": [
        "[enhance] Simpify Address data #1101"
      ],
      "zh-CN": [
        "[enhance] 简化市辖区数据"
      ]
    },
    "v2.1.1-rc.7": {
      "en": [
        "[enhance] Support PC mouse drag  #1039 @michael829"
      ],
      "zh-CN": [
        "[enhance] 支持 PC 上鼠标选择 #1039 @michael829"
      ]
    },
    "v2.1.0-rc.49": {
      "en": [
        "[feature] support `value-text-align` #921 @linhaobin",
        "[fix] fix `label` styles not conform to `group` settings"
      ],
      "zh-CN": [
        "[feature] 支持`value-text-align` #921 @linhaobin",
        "[fix] 修复`label`样式不受控于`group`属性的bug"
      ]
    }
  }
}
  const demos = []

  let componentList = []
  if (Array.isArray(metas.items)) {
    try {
      metas.items.forEach((item, index) => {
        const meta = {
          name: item,
          meta: metas[item]
        }
        if (meta.meta.props === null) {
          delete meta.meta.props
        }
        if (index === metas.items.length - 1) {
          if (meta.meta) {
            meta.meta.variables = metas.variables
          }
        }
        componentList.push(meta)
      })
    } catch (e) {
      console.log(e)
    }
  } else {
    componentList.push({
      meta: metas
    })
  }
  const gitMetas = require('./x-address_git_metas.json')
  const demoCode = decodeURIComponent(`%3Cpre%20class%3D%22hljs%22%3E%3Ccode%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Etemplate%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ediv%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Egroup%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ex-address%3C%2Fspan%3E%20%40%3Cspan%20class%3D%22hljs-attr%22%3Eon-hide%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22logHide%22%3C%2Fspan%3E%20%40%3Cspan%20class%3D%22hljs-attr%22%3Eon-show%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22logShow%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Atitle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22title%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Ev-model%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22value%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Alist%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22addressData%22%3C%2Fspan%3E%20%40%3Cspan%20class%3D%22hljs-attr%22%3Eon-shadow-change%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22onShadowChange%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Eplaceholder%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22%E8%AF%B7%E9%80%89%E6%8B%A9%E5%9C%B0%E5%9D%80%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Einline-desc%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22%E5%8F%AF%E4%BB%A5%E8%AE%BE%E7%BD%AEplaceholder%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Ashow.sync%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22showAddress%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ex-address%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ecell%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Etitle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22%E4%B8%8A%E9%9D%A2value%E5%80%BC%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Avalue%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22value%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ecell%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Egroup%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ediv%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Etemplate%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%0A%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ei18n%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0Aselect%20address%3A%0A%20%20zh-CN%3A%20%E9%80%89%E6%8B%A9%E5%9C%B0%E5%9D%80%0A%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ei18n%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%0A%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Escript%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22javascript%22%3E%0A%3Cspan%20class%3D%22hljs-keyword%22%3Eimport%3C%2Fspan%3E%20%7B%20Group%2C%20XAddress%2C%20ChinaAddressV4Data%2C%20XButton%2C%20Cell%2C%20Value2nameFilter%20%3Cspan%20class%3D%22hljs-keyword%22%3Eas%3C%2Fspan%3E%20value2name%20%7D%20%3Cspan%20class%3D%22hljs-keyword%22%3Efrom%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-string%22%3E'vux'%3C%2Fspan%3E%0A%0A%3Cspan%20class%3D%22hljs-keyword%22%3Eexport%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-keyword%22%3Edefault%3C%2Fspan%3E%20%7B%0A%20%20%3Cspan%20class%3D%22hljs-attr%22%3Ecomponents%3C%2Fspan%3E%3A%20%7B%0A%20%20%20%20Group%2C%0A%20%20%20%20XAddress%2C%0A%20%20%20%20XButton%2C%0A%20%20%20%20Cell%0A%20%20%7D%2C%0A%20%20data%20()%20%7B%0A%20%20%20%20%3Cspan%20class%3D%22hljs-keyword%22%3Ereturn%3C%2Fspan%3E%20%7B%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3Etitle%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-string%22%3E'%E9%BB%98%E8%AE%A4%E4%B8%BA%E7%A9%BA'%3C%2Fspan%3E%2C%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3Evalue_0_1%3C%2Fspan%3E%3A%20%5B%5D%2C%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3Evalue%3C%2Fspan%3E%3A%20%5B%5D%2C%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3Etitle2%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-string%22%3E'%E8%AE%BE%E7%BD%AE%E5%80%BC'%3C%2Fspan%3E%2C%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3Evalue2%3C%2Fspan%3E%3A%20%5B%3Cspan%20class%3D%22hljs-string%22%3E'%E5%A4%A9%E6%B4%A5%E5%B8%82'%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-string%22%3E'%E5%B8%82%E8%BE%96%E5%8C%BA'%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-string%22%3E'%E5%92%8C%E5%B9%B3%E5%8C%BA'%3C%2Fspan%3E%5D%2C%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3Evalue3%3C%2Fspan%3E%3A%20%5B%3Cspan%20class%3D%22hljs-string%22%3E'%E5%B9%BF%E4%B8%9C%E7%9C%81'%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-string%22%3E'%E4%B8%AD%E5%B1%B1%E5%B8%82'%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-string%22%3E'--'%3C%2Fspan%3E%5D%2C%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3EaddressData%3C%2Fspan%3E%3A%20ChinaAddressV4Data%2C%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3Evalue4%3C%2Fspan%3E%3A%20%5B%5D%2C%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3Evalue5%3C%2Fspan%3E%3A%20%5B%3Cspan%20class%3D%22hljs-string%22%3E'%E5%B9%BF%E4%B8%9C%E7%9C%81'%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-string%22%3E'%E6%B7%B1%E5%9C%B3%20%E5%B8%82'%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-string%22%3E'%E5%8D%97%E5%B1%B1%E5%8C%BA'%3C%2Fspan%3E%5D%2C%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3EshowAddress%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-literal%22%3Efalse%3C%2Fspan%3E%0A%20%20%20%20%7D%0A%20%20%7D%2C%0A%20%20%3Cspan%20class%3D%22hljs-attr%22%3Emethods%3C%2Fspan%3E%3A%20%7B%0A%20%20%20%20doShowAddress%20()%20%7B%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-keyword%22%3Ethis%3C%2Fspan%3E.showAddress%20%3D%20%3Cspan%20class%3D%22hljs-literal%22%3Etrue%3C%2Fspan%3E%0A%20%20%20%20%20%20setTimeout(%3Cspan%20class%3D%22hljs-function%22%3E%3Cspan%20class%3D%22hljs-params%22%3E()%3C%2Fspan%3E%20%3D%26gt%3B%3C%2Fspan%3E%20%7B%0A%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-keyword%22%3Ethis%3C%2Fspan%3E.showAddress%20%3D%20%3Cspan%20class%3D%22hljs-literal%22%3Efalse%3C%2Fspan%3E%0A%20%20%20%20%20%20%7D%2C%20%3Cspan%20class%3D%22hljs-number%22%3E2000%3C%2Fspan%3E)%0A%20%20%20%20%7D%2C%0A%20%20%20%20onShadowChange%20(ids%2C%20names)%20%7B%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-built_in%22%3Econsole%3C%2Fspan%3E.log(ids%2C%20names)%0A%20%20%20%20%7D%2C%0A%20%20%20%20changeData%20()%20%7B%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-keyword%22%3Ethis%3C%2Fspan%3E.value2%20%3D%20%5B%3Cspan%20class%3D%22hljs-string%22%3E'430000'%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-string%22%3E'430400'%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-string%22%3E'430407'%3C%2Fspan%3E%5D%0A%20%20%20%20%7D%2C%0A%20%20%20%20changeDataByLabels%20()%20%7B%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-keyword%22%3Ethis%3C%2Fspan%3E.value2%20%3D%20%5B%3Cspan%20class%3D%22hljs-string%22%3E'%E5%B9%BF%E4%B8%9C%E7%9C%81'%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-string%22%3E'%E5%B9%BF%E5%B7%9E%E5%B8%82'%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-string%22%3E'%E5%A4%A9%E6%B2%B3%E5%8C%BA'%3C%2Fspan%3E%5D%0A%20%20%20%20%7D%2C%0A%20%20%20%20changeDataByLabels2%20()%20%7B%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-keyword%22%3Ethis%3C%2Fspan%3E.value2%20%3D%20%5B%3Cspan%20class%3D%22hljs-string%22%3E'%E5%B9%BF%E4%B8%9C%E7%9C%81'%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-string%22%3E'%E4%B8%AD%E5%B1%B1%E5%B8%82'%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-string%22%3E'--'%3C%2Fspan%3E%5D%0A%20%20%20%20%7D%2C%0A%20%20%20%20getName%20(value)%20%7B%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-keyword%22%3Ereturn%3C%2Fspan%3E%20value2name(value%2C%20ChinaAddressV4Data)%0A%20%20%20%20%7D%2C%0A%20%20%20%20logHide%20(str)%20%7B%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-built_in%22%3Econsole%3C%2Fspan%3E.log(%3Cspan%20class%3D%22hljs-string%22%3E'on-hide'%3C%2Fspan%3E%2C%20str)%0A%20%20%20%20%7D%2C%0A%20%20%20%20logShow%20(str)%20%7B%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-built_in%22%3Econsole%3C%2Fspan%3E.log(%3Cspan%20class%3D%22hljs-string%22%3E'on-show'%3C%2Fspan%3E)%0A%20%20%20%20%7D%0A%20%20%7D%0A%7D%0A%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Escript%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%3C%2Fcode%3E%3C%2Fpre%3E`)

  const domainMap = {
    'development': 'http://localhost:8080/',
    'production': 'https://vux.li/demos/v2/'
  }

  export default {
    head: {
      title: 'XAddress component tutorial | VUX - Vue.js Mobile UI Component Framework',
      meta: [{
        name: 'description',
        content: 'Vue component x-address for the VUX framework.'
      }, {
        name: 'keywords',
        content: 'x-address, vue-x-address, vux-x-address, vue mobile components'
      }, {
        property: 'og:title',
        content: 'XAddress component tutorial | VUX - Vue.js Mobile UI Component Framework'
      }, {
        property: 'og:description',
        content: 'Vue component x-address for the VUX framework.'
      }],
      // https://support.google.com/webmasters/answer/189077?hl=en
      link: [{"rel":"alternate","hreflang":"zh-CN","href":"/zh-CN/components/x-address.html"}],
      script: [
        {
          innerHTML:'{"@context":"http://schema.org/","@type":"SoftwareApplication","name":"Vue Component x-address","screenshot":"","description":"Vue.js component for VUX","url":"/en/components/x-address.html","applicationCategory":"Component","author":{"@type":"Organization","name":"VUX","url":"https://vux.li"},"downloadUrl":"https://vux.li","softwareVersion":"2.9.2","aggregateRating":{"@type":"AggregateRating","ratingValue":5,"reviewCount":46},"operatingSystem":"iOS >= 7, Android >= 4.1","offers":{"@type":"Offer","price":0,"priceCurrency":"USD","availability":"http://schema.org/InStock"}}',
          type: 'application/ld+json'
        }
      ],
      __dangerouslyDisableSanitizers: ['script']
    },
    filters: {
      parseCode (str) {
        return str.replace(/`(.*?)`/g, '<code>$1</code>')
      }
    },
    async mounted () {
      const rs = await Axios.get('https://api.github.com/search/issues?q=repo:airyland/vux%20label:component/' + this.componentName)
      this.issues = rs.data.items
      this.hasReady = true
    },
    watch: {
      async sourceCodeDialogVisibility (val) {
        if (val) {
          await this.$nextTick()
          const mask = document.querySelector('.v-modal')
          mask && mask.addEventListener('click', () => {
            this.sourceCodeDialogVisibility = false
          })
        }
      }
    },
    methods: {
      onCopyError () {
        this.$message({
          type: 'error',
          message: 'copy fail!'
        })
      },
      onCopy () {
        this.$message({
          type: 'success',
          message: 'copy done!'
        })
      },
      showSourceCode () {
        this.sourceCodeDialogVisibility = true
      },
      getTypeHTML (type) {
        type = type || 'String'
        if (/,/.test(type)) {
          const list = type.split(',').map(function (one) {
            return one.replace(/^s+|s+$/g, '')
          }).map(function (one) {
            const type = one ?  one.toLowerCase() : 'string'
            return '<span class="type">' + type + '</span>'
          })
          return list.join('<br>')
        } else {
          type = type ?  type.toLowerCase() : 'string'
          return '<span class="type">' + type + '</span>'
        }
      }
    },
    computed: {
      lang () {
        if (this.$route.path.indexOf('/en/') !== -1) {
          return 'en'
        }
        if (this.$route.path.indexOf('/zh-CN/') !== -1) {
          return 'zh-CN'
        }
        return 'en'
      }
    },
    data () {
      return {
        demos,
        isBeta: false,
        hasReady: false,
        issues: [],
        componentName: 'x-address',
        demoCode,
        sourceCodeDialogVisibility: false,
        showQr: false,
        metas: metas,
        gitMetas,
        componentList,
        localImportCode: `import { XAddress } from 'vux'

export default {
  components: {
    XAddress
  }
}`,
        globalImportCode: `// you can also register globally

import Vue from 'vue'
import { XAddress } from 'vux'

Vue.component('x-address', XAddress)
`,
        needImport: true,
        toc: [],
        domain: domainMap[process.env.NODE_ENV]
      }
    }
  }
  </script>

  <style>
  .component-box {
    position: relative;
  }
  .component-demo {
    position: absolute;
    right: 5px;
    top: 15px;
  }
  .prop-color {
    display: inline-block;
    width: 10px;
    height: 10px;
    border: 1px solid #aaa;
  }
  .changelog-version {
    width: 110px;
    display: inline-block;
  }
  .component-extra-links {
    position: relative;
    font-size: 12px;
  }
  .component-extra-links a {
    padding-right: 10px;
    color: #999;
  }
  </style>
    