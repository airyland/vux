
  <template>
    <div class="component-box" :class="demos.length ? 'components-with-toc' : ''">

      <div :class="demos.length ? 'component-header-v2' : 'component-header-v1'">
        <a class="anchor" id="intro">Grid</a>
        <div class="title-box">

          <el-badge value="Beta" v-if="isBeta">
            <h1 class="vux-component-name">Grid</h1>
          </el-badge>
          <h1 v-else class="vux-component-name">Grid</h1>

          <p class="component-extra-links">
            <a href="https://vux.li/demos/v2/#/component/grid" target="_blank">demo url</a>
            <a v-if="!demos.length" href="https://github.com/airyland/vux/blob/v2/src/demos/Grid.vue" target="_blank" @click.prevent="showSourceCode">demo source code</a>
            <a href="https://github.com/airyland/vux/blob/v2/src/components/grid/metas.yml" target="_blank">edit document</a>
            <a href="https://github.com/airyland/vux/blob/v2/src/components/grid/" target="_blank">component source code</a>
            <el-popover trigger="hover" v-if="hasReady">
              <div style="width:100%;text-align:center;">
                <img class="qr" width="100" src="https://qr.vux.li/api.php?text=https%3A%2F%2Fvux.li%2Fdemos%2Fv2%2F%23%2Fcomponent%2Fgrid"/>
              </div>
              <a href="javascript:" slot="reference">
              view demos on mobile
              </a>
            </el-popover>
          </p>

          <div class="component-description">
            <template v-if="false">
            
            </template>
          </div>

        </div>

        <div v-if="!demos.length" class="component-demo" style="width:377px;height:600px;display:inline-block;border:1px solid #ececec;border-radius:5px;overflow:hidden;z-index:2500;">
          <iframe src="https://vux.li/demos/v2?locale=en&transition=none/#/component/grid" width="375" height="600" border="0" frameborder="0"></iframe>
        </div>
        <div class="toc">
          <ul v-for="t in toc">
            <li>
              <a :href="'#' + (t.anchor || t.title)">{{ t.title }}</a>
              <ul v-if="t.list" v-for="_t in t.list">
                <li><a :href="'#' + _t.anchor">{{ _t.title.slice(0, 12) }}</a></li>
              </ul>
            </li>
          </ul>
        </div>
      
        <template v-if="needImport">
          <a class="anchor" id="install">Install</a>
          <h2>Install</h2>
          <el-tabs>
            <el-tab-pane label="Local Registration">
              <div class="import-code-box">
              <el-tooltip content="click to copy" placement="top">
                <span
                  v-clipboard:copy="localImportCode"
                  v-clipboard:success="onCopy"
                  v-clipboard:error="onCopyError">
                  <el-icon class="el-icon-document"></el-icon>
                </span>
              </el-tooltip>
              <pre class="hljs"><code><span class="hljs-keyword">import</span> { Grid, GridItem } <span class="hljs-keyword">from</span> <span class="hljs-string">'vux'</span>

<span class="hljs-keyword">export</span> <span class="hljs-keyword">default</span> {
  <span class="hljs-attr">components</span>: {
    Grid,
    GridItem
  }
}</code></pre>
            </div>
            </el-tab-pane>
            <el-tab-pane label="Global Registration">
              <div class="import-code-box">
                <el-tooltip content="click to copy" placement="top">
                  <span
                    v-clipboard:copy="globalImportCode"
                    v-clipboard:success="onCopy"
                    v-clipboard:error="onCopyError">
                    <el-icon class="el-icon-document"></el-icon>
                  </span>
                </el-tooltip>
                <pre class="hljs"><code><span class="hljs-comment">// you can also register globally</span>

<span class="hljs-keyword">import</span> Vue <span class="hljs-keyword">from</span> <span class="hljs-string">'vue'</span>
<span class="hljs-keyword">import</span> { Grid, GridItem } <span class="hljs-keyword">from</span> <span class="hljs-string">'vux'</span>

Vue.component(<span class="hljs-string">'grid'</span>, Grid)
Vue.component(<span class="hljs-string">'grid-item'</span>, GridItem)
</code></pre>
              </div> 
            </el-tab-pane>
          </el-tabs>   
        </template>

        <template v-else>
          <div class="tip">
            <p>You don't need to import this component.</p>
          </div>
        </template>

        <div class="tip" style="width:600px;" v-if="metas.tip">
          
        </div>
      
        <h2 v-if="metas.example">example</h2>
        <div v-if="metas.example" style="width:600px;">
          
        </div>
      </div>

      <div v-if="metas.extra && metas.extra['en']">
        
      </div>
      <div v-if="metas.extra && !metas.extra['en']">
        <pre class="hljs"><code><span class="hljs-tag">&lt;<span class="hljs-name">grid</span>&gt;</span>
  <span class="hljs-tag">&lt;<span class="hljs-name">grid-item</span> <span class="hljs-attr">label</span>=<span class="hljs-string">"Grid"</span> <span class="hljs-attr">v-for</span>=<span class="hljs-string">"i in 9"</span>&gt;</span>
    <span class="hljs-tag">&lt;<span class="hljs-name">img</span> <span class="hljs-attr">slot</span>=<span class="hljs-string">"icon"</span> <span class="hljs-attr">src</span>=<span class="hljs-string">"../assets/grid_icon.png"</span>&gt;</span>
  <span class="hljs-tag">&lt;/<span class="hljs-name">grid-item</span>&gt;</span>
<span class="hljs-tag">&lt;/<span class="hljs-name">grid</span>&gt;</span>
</code></pre>

      </div>
      
      <a v-if="demos.length" class="anchor" id="examples">Examples</a>
      <br/>
      <template v-if="demos.length" v-for="demo in demos">
        <a class="anchor" :id="'examples:' + demo.title">{{ demo.title }}</a>
        <br/>
        <div class="demo-header">
          <span class="demo-title">{{ demo.title }}</span>
        </div>
        <div class="demos" :style="{height: demo.height}">
          <div class="demo-iframe-box">
            <lazy-component>
              <iframe
                :src="domain + '?no-background-color=' + demo.noBackgroundColor +'&locale=en&transition=none&hide-nav=true&hide-tab-bar=true#/components/' + demo.file"
                width="375"
                height="600"
                border="0"
                frameborder="0"
                style="margin: 0 auto;"></iframe>
            </lazy-component>
          </div>
          <div class="demo-code-box" :style="{overflow: demo.height === demo.oriHeight ? 'hidden' : 'scroll'}">
            <div v-html="demo.code" contenteditable></div>
            <div v-if="demo.height === demo.oriHeight" class="demo-code-masker" @click="demo.height='auto'">
              <div>
                  <img class="demo-qr" width="100" :src="'https://qr.vux.li/api.php?text=' + encodeURIComponent(domain + '?locale=en#/components/' + demo.file)"/>
                  <br/>
                  <span>
                    <el-icon class="el-icon-arrow-left"/>
                    <el-icon class="el-icon-arrow-right"/>
                    Show code
                  <br/>
                  <!--<span class="demo-path">src/demos/{{ demo.file }}.vue</span>-->
                </span>
              </div>
            </div>
            <span v-if="demo.height === 'auto'" class="hide-code" @click="demo.height=demo.oriHeight">
              <el-icon class="el-icon-close"></el-icon>
            </span>
          </div>
        </div>
      </template>

      <template v-for="component in componentList">
        <div>
          <a v-if="componentList.length > 1" class="anchor" :id="'components:' + component.name">{{ component.name }}</a>
          <a v-else class="anchor" id="api">API</a>
          <br/>
          <h2
            v-show="componentList.length > 1"
            class="vux-component-name-sub-item">{{ component.name }}</h2>
            
          <template v-if="component.meta.items && component.meta.description">
            <div v-html="component.meta.description"></div>
          </template>

          <template v-if="component.meta.props">
            <h2>Props</h2>
            <table>
              <thead>
                <tr>
                  <td>name</td>
                  <td style="width:48px;">type</td>
                  <td>default</td>
                  <td>description</td>
                  <td>required version</td>
                </tr>
              </thead>
              <tbody>
                <tr v-for="(prop, i) in component.meta.props">
                  <td class="prop-name">
                    <el-tooltip content="click to copy" placement="left" :hide-after="0" :open-delay="50">
                      <span
                      v-clipboard:copy="i"
                      v-clipboard:success="onCopy">{{ i }}</span>
                    </el-tooltip>
                  </td>
                  <td v-html="getTypeHTML(prop.type)"></td>
                  <td>{{ prop.default}}</td>
                  <td v-html="prop['en'].replace(/`(.*?)`/g, '<code>$1</code>')"></td>
                  <td>{{ prop.version || '--'}}</td>
                </tr>
              </tbody>
            </table>
          </template>

          <template v-if="component.meta.events">
            <h2>Events</h2>
            <table>
              <thead>
                <tr>
                  <td>name</td>
                  <td>params</td>
                  <td>description</td>
                  <td>required version</td>
                </tr>
              </thead>
              <tbody>
                <tr v-for="(event, i) in component.meta.events">
                  <td class="prop-name">
                    <el-tooltip content="click to copy" placement="left" :hide-after="0" :open-delay="50">
                      <span
                      v-clipboard:copy="'@' + i"
                      v-clipboard:success="onCopy">@{{ i }}</span>
                    </el-tooltip>
                  </td>
                  <td v-html="event.params ? event.params.replace(/`(.*?)`/g, '<code>$1</code>') : '--'"></td>
                  <td v-html="event['en'] ? event['en'].replace(/`(.*?)`/g, '<code>$1</code>') : '--'"></td>
                  <td>{{ event['version'] || '--' }}</td>
                </tr>
              </tbody>
            </table>
          </template>
      

          <template v-if="component.meta.slots">
            <h2>Slots</h2>
            <table>
              <thead>
                <tr>
                  <td>name</td>
                  <td>description</td>
                  <td>required version</td>
                </tr>
              </thead>
              <tbody>
                <tr v-for="(slot, i) in component.meta.slots" :class="{'slot-disabled': slot['status'] === 'deprecated'}">
                  <td class="prop-name">
                    <el-tooltip content="click to copy" placement="left" :hide-after="0" :open-delay="50">
                      <span
                      v-clipboard:copy="i"
                      v-clipboard:success="onCopy">{{ i === 'default' ? 'default' : i }}</span>
                    </el-tooltip>
                  </td>
                  <td v-html="slot['en'] ? slot['en'].replace(/`(.*?)`/g, '<code>$1</code>') : ''"></td>
                  <td>{{ slot['version'] || '--' }}</td>
                </tr>
              </tbody>
            </table>
          </template>
          
          <template v-if="component.meta.methods">
            <h2>Functions</h2>
            <table>
              <thead>
                <tr>
                  <td>name</td>
                  <td>params</td>
                  <td>description</td>
                  <td>required version</td>
                </tr>
              </thead>
              <tbody>
                <tr v-for="(method, i) in component.meta.methods">
                  <td class="prop-name">
                    <el-tooltip content="click to copy" placement="left" :hide-after="0" :open-delay="50">
                      <span
                      v-clipboard:copy="i"
                      v-clipboard:success="onCopy">{{ i }}</span>
                    </el-tooltip>
                  </td>
                  <td v-html="method['params'] ? method['params'].replace(/`(.*?)`/g, '<code>$1</code>') : ''"></td>
                  <td v-html="method['en'].replace(/`(.*?)`/g, '<code>$1</code>')"></td>
                  <td>{{ method['version'] }}</td>
                </tr>
              </tbody>
            </table>
          </template>

          <template v-if="component.meta.variables">
            <a class="anchor" id="variables">Variables</a>
            <br/>
            <h2>Variables</h2>
            <table>
              <thead>
                <tr>
                  <td>name</td>
                  <td>default</td>
                  <td>description</td>
                  <td>inherited name</td>
                </tr>
              </thead>
              <tbody>
                <tr v-for="(variable, i) in component.meta.variables">
                  <td class="prop-name">
                    <el-tooltip content="click to copy" placement="left" :hide-after="0" :open-delay="50">
                      <span
                      v-clipboard:copy="'@' + variable.name"
                      v-clipboard:success="onCopy">@{{ variable.name }}</span>
                    </el-tooltip>
                  </td>
                  <td>
                    <em
                      :ref="'propColor' + i"
                      v-if="!$refs['propColor' + i] || ($refs['propColor' + i][0] && $refs['propColor' + i][0].style.backgroundColor)"
                      class="prop-color"
                      :style="{ backgroundColor: variable.value }">
                    </em>
                    {{ variable.value }}
                  </td>
                  <td>{{ variable['desc']['en'] || '--' }}</td>
                  <td>{{ variable.inherited_name }}</td>
                </tr>
              </tbody>
            </table>
          </template>
      
          <template v-if="component.meta.tips && component.meta.tips['en']">
            <a class="anchor" id="tips">Tips</a>
            <br>
            <h2>Tips</h2>
            <div>
              <ul>
                <li v-for="tip in component.meta.tips['en']">
                <el-tag size="mini" type="success" class="component-tip-tag">Q</el-tag> <span class="component-tip-question">{{ tip.q }}</span>
                <div v-html="tip.a" class="tip-answer-box"></div>
                </li>
              </ul>
            </div>
          </template>
        </div>
      </template>

      <!--<h2>社区相关讨论</h2>
      [即将上线]
      -->
    
      <br>
      <div v-if="issues.length">
        <a class="anchor" id="Issues">Issues</a>
        <br/>
        <h2>Related issues</h2>
        <ul>
          <li v-for="issue in issues"><a target="_blank" :href="issue.html_url">#{{ issue.number}} <span style="color:#666;">{{ issue.title }}</span></a></li>
        </ul>
      </div>
      <br>
    
      <div v-if="gitMetas">
        <a class="anchor" id="contributors">Contributors</a>
        <h2>Contributors</h2>
        <p>Total commits quantity: {{ gitMetas.commitCount }}，Total contributors quantity: {{gitMetas.commitUniqueCount}}
        </p>
        <a v-for="person in gitMetas.commitMembers" class="contributor-item" :href="'https://github.com/' + person.authorName" target="_blank" :title="'contribute' + person.count">{{person.authorName}}</a>
      </div>
      <br>

      <div v-if="metas.changes">
        <a class="anchor" id="changelog">Changelog</a>
        <br/>
        <h2>Releases</h2>
        <ul v-if="metas.changes">
          <template v-for="(changelog, version) in metas.changes">
            <li v-for="log in changelog['en']">
              <router-link :to="'/en/changelog/' + version + '.html'" class="changelog-version">{{version}}</router-link> {{log}}
            </li>
          </template>
        </ul>
      </div>

      <h2 v-if="metas.references">Referrences</h2>
      <ul v-if="metas.references">
        <li v-for="link in metas.references['en']">
          <a :href="link.link" target="_blank">{{link.title}}</a>
        </li>
      </ul>

      <el-dialog
        class="sourcec-code-dialog"
        top="0"
        width="80%"
        :visible.sync="sourceCodeDialogVisibility">
        <div class="code-box" contenteditable v-html="demoCode"></div>
      </el-dialog>

    </div>
  </template>


  <script>
  import Axios from 'axios'

  // const metas = require('json-loader!yaml-loader!../../../src/components/grid/metas.yml')
  const metas = {
  "icon": "&#xe661;",
  "import_code": "import { Grid, GridItem } from 'vux'",
  "category": {
    "en": "Layout",
    "zh-CN": "布局"
  },
  "tags": {
    "en": [
      "grid",
      "layout"
    ],
    "zh-CN": [
      "宫格",
      "九宫格",
      "布局"
    ]
  },
  "items": [
    "grid",
    "grid-item"
  ],
  "extra": "\n``` html\n<grid>\n  <grid-item label=\"Grid\" v-for=\"i in 9\">\n    <img slot=\"icon\" src=\"../assets/grid_icon.png\">\n  </grid-item>\n</grid>\n```\n",
  "grid": {
    "props": {
      "rows": {
        "type": "Number",
        "version": "v2.2.0",
        "default": 3,
        "en": "(deprecated after v2.6.0) the number of rows. Less than 5 will be better",
        "zh-CN": "(v2.6.0 之后废弃，使用 col 替代)宫格行数，建议少于`5`"
      },
      "cols": {
        "type": "Number",
        "version": "v2.6.1",
        "default": 3,
        "en": "the number of columns. if there is more than one row in grid, need to set cols value, otherwise all grid items will show in one row with the same width",
        "zh-CN": "列数。如果为非单行 Grid，需要设置 cols，否则所有 GridItem 会平均宽度显示在一行。"
      },
      "show-lr-borders": {
        "type": "Boolean",
        "version": "v2.8.1",
        "default": true,
        "en": "whether show left and right borders",
        "zh-CN": "是否显示左右边框"
      },
      "show-vertical-dividers": {
        "type": "Boolean",
        "version": "v2.8.1",
        "default": true,
        "en": "whether show vertical dividers",
        "zh-CN": "是否显示垂直分割线"
      }
    },
    "slots": {
      "default": {
        "en": "default slot for `grid-item` list",
        "zh-CN": "用于`grid-item`的插槽"
      }
    }
  },
  "grid-item": {
    "props": {
      "icon": {
        "en": "icon url. if using local resources, it is better to use `slot=icon`",
        "zh-CN": "图标地址，如果是线上地址，推荐使用该prop。如果是本地图标资源，使用`slot=icon`可以保证资源被正确打包"
      },
      "label": {
        "en": "`label` text",
        "zh-CN": "`label` 文字"
      },
      "link": {
        "en": "vue-router's path",
        "zh-CN": "vue-router 路径"
      }
    },
    "slots": {
      "icon": {
        "en": "icon slot, use tag:`img`",
        "zh-CN": "图标内容，直接使用`img`标签"
      },
      "label": {
        "en": "slot for label, the same func as prop:label",
        "zh-CN": "label 文字的 slot，作用同 prop:label"
      }
    }
  },
  "changes": {
    "v2.8.1": {
      "en": [
        "[feature] add prop:show-lr-borders and prop:show-vertical-dividers #2488"
      ],
      "zh-CN": [
        "[feature] 支持 prop:show-lr-borders、prop:show-vertical-dividers 用以隐藏左右边线及垂直分割线 #2488"
      ]
    },
    "v2.6.1": {
      "en": [
        "[feature] add `cols` props"
      ],
      "zh-CN": [
        "[feature] 添加 `cols` 属性，自定义列数"
      ]
    },
    "v2.6.0": {
      "en": [
        "[change] prop:rows is deprecated #1971"
      ],
      "zh-CN": [
        "[change] rows 属性已经废弃，使用自动计算 #1971"
      ]
    },
    "v2.2.0": {
      "en": [
        "[feature] Support dynamic rows",
        "[enhance] Hide slot:icon and slot:label if not being set"
      ],
      "zh-CN": [
        "[feature] 支持定义列数",
        "[enhance] 如果没有使用 icon 和 label，则直接隐藏 slot:icon 和 slot:label"
      ]
    },
    "v2.0.14": {
      "en": [
        "[feature] Add component `grid`"
      ],
      "zh-CN": [
        "[feature] 增加`grid`九宫格组件"
      ]
    }
  }
}
  const demos = []

  let componentList = []
  if (Array.isArray(metas.items)) {
    try {
      metas.items.forEach((item, index) => {
        const meta = {
          name: item,
          meta: metas[item]
        }
        if (meta.meta.props === null) {
          delete meta.meta.props
        }
        if (index === metas.items.length - 1) {
          if (meta.meta) {
            meta.meta.variables = metas.variables
          }
        }
        componentList.push(meta)
      })
    } catch (e) {
      console.log(e)
    }
  } else {
    componentList.push({
      meta: metas
    })
  }
  const gitMetas = require('./grid_git_metas.json')
  const demoCode = decodeURIComponent(`%3Cpre%20class%3D%22hljs%22%3E%3Ccode%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Etemplate%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ediv%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Egroup-title%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E2%20columns%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Egroup-title%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Egrid%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Egrid-item%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Alabel%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22%24t('Grid')%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Ev-for%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22i%20in%202%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Akey%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22i%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Eimg%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Eslot%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22icon%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Esrc%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22..%2Fassets%2Fgrid_icon.png%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Egrid-item%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Egrid%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Egroup-title%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E3%20columns%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Egroup-title%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Egrid%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Ashow-lr-borders%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22false%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Ashow-vertical-dividers%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22false%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Egrid-item%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Elink%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22%2Fcomponent%2Fcell%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Alabel%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22%24t('Go%20to%20Cell')%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Eimg%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Eslot%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22icon%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Esrc%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22..%2Fassets%2Fgrid_icon.png%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Egrid-item%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Egrid-item%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Alink%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22%7B%20path%3A%20'%2Fcomponent%2Fcell'%7D%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Alabel%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22%24t('Go%20to%20Cell')%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Eimg%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Eslot%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22icon%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Esrc%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22..%2Fassets%2Fgrid_icon.png%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Egrid-item%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Egrid-item%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Elink%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22%2Fcomponent%2Fcell%22%3C%2Fspan%3E%20%40%3Cspan%20class%3D%22hljs-attr%22%3Eon-item-click%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22onItemClick%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Eimg%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Eslot%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22icon%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Esrc%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22..%2Fassets%2Fgrid_icon.png%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Espan%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Eslot%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22label%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%7B%7B%20%24t('Go%20to%20Cell')%20%7D%7D%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Espan%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Egrid-item%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Egrid%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Egroup-title%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E4%20columns%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Egroup-title%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Egrid%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Ashow-lr-borders%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22false%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Egrid-item%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Alabel%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22%24t('Grid')%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Ev-for%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22i%20in%204%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Akey%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22i%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Eimg%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Eslot%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22icon%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Esrc%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22..%2Fassets%2Fgrid_icon.png%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Egrid-item%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Egrid%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Egroup-title%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%20%7B%7B%20%24t('Custom%20content')%20%7D%7D%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Egroup-title%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Egrid%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Ashow-vertical-dividers%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22false%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Egrid-item%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Ev-for%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22i%20in%205%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Akey%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22i%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Espan%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Eclass%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22grid-center%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%7B%7Bi%7D%7D%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Espan%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Egrid-item%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Egrid%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Egroup-title%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%20%7B%7B%20%24t('Custom%20col')%20%7D%7D%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Egroup-title%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Egrid%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Acols%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%223%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Ashow-lr-borders%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22false%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Egrid-item%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Ev-for%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22i%20in%206%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Akey%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22i%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Espan%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Eclass%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22grid-center%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%7B%7Bi%7D%7D%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Espan%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Egrid-item%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Egrid%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ediv%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Etemplate%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%0A%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ei18n%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0AGrid%3A%0A%20%20zh-CN%3A%20%E4%B9%9D%E5%AE%AB%E6%A0%BC%0AGo%20to%20Cell%3A%0A%20%20zh-CN%3A%20%E8%B7%B3%E8%BD%AC%E5%88%B0Cell%0ACustom%20content%3A%0A%20%20zh-CN%3A%20%E8%87%AA%E5%AE%9A%E4%B9%89%E5%86%85%E5%AE%B9%0ACustom%20col%3A%0A%20%20zh-CN%3A%20%E8%87%AA%E5%AE%9A%E4%B9%89%E5%88%97%0A%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ei18n%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%0A%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Escript%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22javascript%22%3E%0A%3Cspan%20class%3D%22hljs-keyword%22%3Eimport%3C%2Fspan%3E%20%7B%20Grid%2C%20GridItem%2C%20GroupTitle%20%7D%20%3Cspan%20class%3D%22hljs-keyword%22%3Efrom%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-string%22%3E'vux'%3C%2Fspan%3E%0A%0A%3Cspan%20class%3D%22hljs-keyword%22%3Eexport%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-keyword%22%3Edefault%3C%2Fspan%3E%20%7B%0A%20%20%3Cspan%20class%3D%22hljs-attr%22%3Ecomponents%3C%2Fspan%3E%3A%20%7B%0A%20%20%20%20Grid%2C%0A%20%20%20%20GridItem%2C%0A%20%20%20%20GroupTitle%0A%20%20%7D%2C%0A%20%20%3Cspan%20class%3D%22hljs-attr%22%3Emethods%3C%2Fspan%3E%3A%20%7B%0A%20%20%20%20onItemClick%20()%20%7B%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-built_in%22%3Econsole%3C%2Fspan%3E.log(%3Cspan%20class%3D%22hljs-string%22%3E'on%20item%20click'%3C%2Fspan%3E)%0A%20%20%20%20%7D%0A%20%20%7D%0A%7D%0A%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Escript%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%0A%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Estyle%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Escoped%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22css%22%3E%0A%3Cspan%20class%3D%22hljs-selector-class%22%3E.grid-center%3C%2Fspan%3E%20%7B%0A%20%20%3Cspan%20class%3D%22hljs-attribute%22%3Edisplay%3C%2Fspan%3E%3A%20block%3B%0A%20%20%3Cspan%20class%3D%22hljs-attribute%22%3Etext-align%3C%2Fspan%3E%3A%20center%3B%0A%20%20%3Cspan%20class%3D%22hljs-attribute%22%3Ecolor%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-number%22%3E%23666%3C%2Fspan%3E%3B%0A%7D%0A%3Cspan%20class%3D%22hljs-selector-class%22%3E.weui-grids%3C%2Fspan%3E%20%7B%0A%20%20%3Cspan%20class%3D%22hljs-attribute%22%3Ebackground-color%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-number%22%3E%23fff%3C%2Fspan%3E%3B%0A%7D%0A%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Estyle%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%3C%2Fcode%3E%3C%2Fpre%3E`)

  const domainMap = {
    'development': 'http://localhost:8080/',
    'production': 'https://vux.li/demos/v2/'
  }

  export default {
    head: {
      title: 'Grid component tutorial | VUX - Vue.js Mobile UI Component Framework',
      meta: [{
        name: 'description',
        content: 'Vue component grid for the VUX framework.'
      }, {
        name: 'keywords',
        content: 'grid, vue-grid, vux-grid, vue mobile components'
      }, {
        property: 'og:title',
        content: 'Grid component tutorial | VUX - Vue.js Mobile UI Component Framework'
      }, {
        property: 'og:description',
        content: 'Vue component grid for the VUX framework.'
      }],
      // https://support.google.com/webmasters/answer/189077?hl=en
      link: [{"rel":"alternate","hreflang":"zh-CN","href":"/zh-CN/components/grid.html"}],
      script: [
        {
          innerHTML:'{"@context":"http://schema.org/","@type":"SoftwareApplication","name":"Vue Component grid","screenshot":"","description":"Vue.js component for VUX","url":"/en/components/grid.html","applicationCategory":"Component","author":{"@type":"Organization","name":"VUX","url":"https://vux.li"},"downloadUrl":"https://vux.li","softwareVersion":"2.9.2","aggregateRating":{"@type":"AggregateRating","ratingValue":5,"reviewCount":21},"operatingSystem":"iOS >= 7, Android >= 4.1","offers":{"@type":"Offer","price":0,"priceCurrency":"USD","availability":"http://schema.org/InStock"}}',
          type: 'application/ld+json'
        }
      ],
      __dangerouslyDisableSanitizers: ['script']
    },
    filters: {
      parseCode (str) {
        return str.replace(/`(.*?)`/g, '<code>$1</code>')
      }
    },
    async mounted () {
      const rs = await Axios.get('https://api.github.com/search/issues?q=repo:airyland/vux%20label:component/' + this.componentName)
      this.issues = rs.data.items
      this.hasReady = true
    },
    watch: {
      async sourceCodeDialogVisibility (val) {
        if (val) {
          await this.$nextTick()
          const mask = document.querySelector('.v-modal')
          mask && mask.addEventListener('click', () => {
            this.sourceCodeDialogVisibility = false
          })
        }
      }
    },
    methods: {
      onCopyError () {
        this.$message({
          type: 'error',
          message: 'copy fail!'
        })
      },
      onCopy () {
        this.$message({
          type: 'success',
          message: 'copy done!'
        })
      },
      showSourceCode () {
        this.sourceCodeDialogVisibility = true
      },
      getTypeHTML (type) {
        type = type || 'String'
        if (/,/.test(type)) {
          const list = type.split(',').map(function (one) {
            return one.replace(/^s+|s+$/g, '')
          }).map(function (one) {
            const type = one ?  one.toLowerCase() : 'string'
            return '<span class="type">' + type + '</span>'
          })
          return list.join('<br>')
        } else {
          type = type ?  type.toLowerCase() : 'string'
          return '<span class="type">' + type + '</span>'
        }
      }
    },
    computed: {
      lang () {
        if (this.$route.path.indexOf('/en/') !== -1) {
          return 'en'
        }
        if (this.$route.path.indexOf('/zh-CN/') !== -1) {
          return 'zh-CN'
        }
        return 'en'
      }
    },
    data () {
      return {
        demos,
        isBeta: false,
        hasReady: false,
        issues: [],
        componentName: 'grid',
        demoCode,
        sourceCodeDialogVisibility: false,
        showQr: false,
        metas: metas,
        gitMetas,
        componentList,
        localImportCode: `import { Grid, GridItem } from 'vux'

export default {
  components: {
    Grid,
    GridItem
  }
}`,
        globalImportCode: `// you can also register globally

import Vue from 'vue'
import { Grid, GridItem } from 'vux'

Vue.component('grid', Grid)
Vue.component('grid-item', GridItem)
`,
        needImport: true,
        toc: [],
        domain: domainMap[process.env.NODE_ENV]
      }
    }
  }
  </script>

  <style>
  .component-box {
    position: relative;
  }
  .component-demo {
    position: absolute;
    right: 5px;
    top: 15px;
  }
  .prop-color {
    display: inline-block;
    width: 10px;
    height: 10px;
    border: 1px solid #aaa;
  }
  .changelog-version {
    width: 110px;
    display: inline-block;
  }
  .component-extra-links {
    position: relative;
    font-size: 12px;
  }
  .component-extra-links a {
    padding-right: 10px;
    color: #999;
  }
  </style>
    