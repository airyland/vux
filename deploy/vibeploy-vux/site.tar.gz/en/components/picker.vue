
  <template>
    <div class="component-box" :class="demos.length ? 'components-with-toc' : ''">

      <div :class="demos.length ? 'component-header-v2' : 'component-header-v1'">
        <a class="anchor" id="intro">Picker</a>
        <div class="title-box">

          <el-badge value="Beta" v-if="isBeta">
            <h1 class="vux-component-name">Picker</h1>
          </el-badge>
          <h1 v-else class="vux-component-name">Picker</h1>

          <p class="component-extra-links">
            <a href="https://vux.li/demos/v2/#/component/picker" target="_blank">demo url</a>
            <a v-if="!demos.length" href="https://github.com/airyland/vux/blob/v2/src/demos/Picker.vue" target="_blank" @click.prevent="showSourceCode">demo source code</a>
            <a href="https://github.com/airyland/vux/blob/v2/src/components/picker/metas.yml" target="_blank">edit document</a>
            <a href="https://github.com/airyland/vux/blob/v2/src/components/picker/" target="_blank">component source code</a>
            <el-popover trigger="hover" v-if="hasReady">
              <div style="width:100%;text-align:center;">
                <img class="qr" width="100" src="https://qr.vux.li/api.php?text=https%3A%2F%2Fvux.li%2Fdemos%2Fv2%2F%23%2Fcomponent%2Fpicker"/>
              </div>
              <a href="javascript:" slot="reference">
              view demos on mobile
              </a>
            </el-popover>
          </p>

          <div class="component-description">
            <template v-if="true">
            <p>Picker是指提供多个选项集合供用户选择其中一项的控件。Picker展示区域有限，部分选项会被隐藏，最好是当用户对所有选项都比较熟悉、有预期的时候，才使用Picker。</p>
<ul>
<li>合理的默认选项能让用户减少操作次数，提升效率。</li>
<li>选项的排列顺序要依据当前上下文情景而定，例如衣服尺码按从小到大的顺序排列，而不是根据衣服尺码的首字母在字母表的顺序排列。</li>
<li>滚轮选择器控制在五列以内。为了保证手机屏幕触控精度，以免发生误触，滚轮选择器建议控制在五列以内。</li>
<li>使用相对概念增强感知。比起绝对的“某年某月日”，用“今天”、“昨天”等相对概念，能更快的激发人对时间的感知。</li>
<li>如果选项非常多，而且选项本身比较复杂难理解需要辅助的解释，建议用容纳更多的选项的其他形式，例如日历或者新页面。</li>
</ul>

            </template>
          </div>

        </div>

        <div v-if="!demos.length" class="component-demo" style="width:377px;height:600px;display:inline-block;border:1px solid #ececec;border-radius:5px;overflow:hidden;z-index:2500;">
          <iframe src="https://vux.li/demos/v2?locale=en&transition=none/#/component/picker" width="375" height="600" border="0" frameborder="0"></iframe>
        </div>
        <div class="toc">
          <ul v-for="t in toc">
            <li>
              <a :href="'#' + (t.anchor || t.title)">{{ t.title }}</a>
              <ul v-if="t.list" v-for="_t in t.list">
                <li><a :href="'#' + _t.anchor">{{ _t.title.slice(0, 12) }}</a></li>
              </ul>
            </li>
          </ul>
        </div>
      
        <template v-if="needImport">
          <a class="anchor" id="install">Install</a>
          <h2>Install</h2>
          <el-tabs>
            <el-tab-pane label="Local Registration">
              <div class="import-code-box">
              <el-tooltip content="click to copy" placement="top">
                <span
                  v-clipboard:copy="localImportCode"
                  v-clipboard:success="onCopy"
                  v-clipboard:error="onCopyError">
                  <el-icon class="el-icon-document"></el-icon>
                </span>
              </el-tooltip>
              <pre class="hljs"><code><span class="hljs-keyword">import</span> { Picker } <span class="hljs-keyword">from</span> <span class="hljs-string">'vux'</span>

<span class="hljs-keyword">export</span> <span class="hljs-keyword">default</span> {
  <span class="hljs-attr">components</span>: {
    Picker
  }
}</code></pre>
            </div>
            </el-tab-pane>
            <el-tab-pane label="Global Registration">
              <div class="import-code-box">
                <el-tooltip content="click to copy" placement="top">
                  <span
                    v-clipboard:copy="globalImportCode"
                    v-clipboard:success="onCopy"
                    v-clipboard:error="onCopyError">
                    <el-icon class="el-icon-document"></el-icon>
                  </span>
                </el-tooltip>
                <pre class="hljs"><code><span class="hljs-comment">// you can also register globally</span>

<span class="hljs-keyword">import</span> Vue <span class="hljs-keyword">from</span> <span class="hljs-string">'vue'</span>
<span class="hljs-keyword">import</span> { Picker } <span class="hljs-keyword">from</span> <span class="hljs-string">'vux'</span>

Vue.component(<span class="hljs-string">'picker'</span>, Picker)
</code></pre>
              </div> 
            </el-tab-pane>
          </el-tabs>   
        </template>

        <template v-else>
          <div class="tip">
            <p>You don't need to import this component.</p>
          </div>
        </template>

        <div class="tip" style="width:600px;" v-if="metas.tip">
          
        </div>
      
        <h2 v-if="metas.example">example</h2>
        <div v-if="metas.example" style="width:600px;">
          
        </div>
      </div>

      <div v-if="metas.extra && metas.extra['en']">
        
      </div>
      <div v-if="metas.extra && !metas.extra['en']">
        <div class="warning">
<p>请确保列表项的<code>value</code>值是字符串，使用数字会出错。
<br />
如果你的业务接口返回数字值为数字，需要你先处理成字符串；同样，获取到值时为字符串，你需要自己转换成数字。</p>
</div>
<p>非联动情况下，列表数据格式示例：</p>
<pre class="hljs"><code><span class="hljs-comment">// data</span>
[[<span class="hljs-string">'小米'</span>, <span class="hljs-string">'iPhone'</span>, <span class="hljs-string">'华为'</span>, <span class="hljs-string">'情怀'</span>, <span class="hljs-string">'三星'</span>, <span class="hljs-string">'其他'</span>, <span class="hljs-string">'不告诉你'</span>], [<span class="hljs-string">'小米1'</span>, <span class="hljs-string">'iPhone2'</span>, <span class="hljs-string">'华为3'</span>, <span class="hljs-string">'情怀4'</span>, <span class="hljs-string">'三星5'</span>, <span class="hljs-string">'其他6'</span>, <span class="hljs-string">'不告诉你7'</span>]]

<span class="hljs-comment">// 或者使用 name =&gt; value 的形式</span>
[[{
  <span class="hljs-attr">name</span>: <span class="hljs-string">'2019届5班'</span>,
  <span class="hljs-attr">value</span>: <span class="hljs-string">'1'</span>
}, {
  <span class="hljs-attr">name</span>: <span class="hljs-string">'2019届4班'</span>,
  <span class="hljs-attr">value</span>: <span class="hljs-string">'2'</span>
}]]

<span class="hljs-comment">// value</span>
[<span class="hljs-string">'小米'</span>, <span class="hljs-string">'小米1'</span>]
</code></pre>
<p>联动时，列表数据格式示例：</p>
<pre class="hljs"><code><span class="hljs-comment">// data</span>
[{
  <span class="hljs-attr">name</span>: <span class="hljs-string">'中国'</span>,
  <span class="hljs-attr">value</span>: <span class="hljs-string">'china'</span>,
  <span class="hljs-attr">parent</span>: <span class="hljs-string">'0'</span> <span class="hljs-comment">// 为一级时可以不写 parent，但是此时允许为数字 0、空字符串或者字符串 '0'</span>
}, {
  <span class="hljs-attr">name</span>: <span class="hljs-string">'美国'</span>,
  <span class="hljs-attr">value</span>: <span class="hljs-string">'USA'</span>,
  <span class="hljs-attr">parent</span>: <span class="hljs-string">'0'</span>
}, {
  <span class="hljs-attr">name</span>: <span class="hljs-string">'广东'</span>,
  <span class="hljs-attr">value</span>: <span class="hljs-string">'china001'</span>,
  <span class="hljs-attr">parent</span>: <span class="hljs-string">'china'</span>
}, {
  <span class="hljs-attr">name</span>: <span class="hljs-string">'广西'</span>,
  <span class="hljs-attr">value</span>: <span class="hljs-string">'china002'</span>,
  <span class="hljs-attr">parent</span>: <span class="hljs-string">'china'</span>
}, {
  <span class="hljs-attr">name</span>: <span class="hljs-string">'美国001'</span>,
  <span class="hljs-attr">value</span>: <span class="hljs-string">'usa001'</span>,
  <span class="hljs-attr">parent</span>: <span class="hljs-string">'USA'</span>
}, {
  <span class="hljs-attr">name</span>: <span class="hljs-string">'美国002'</span>,
  <span class="hljs-attr">value</span>: <span class="hljs-string">'usa002'</span>,
  <span class="hljs-attr">parent</span>: <span class="hljs-string">'USA'</span>
}, {
  <span class="hljs-attr">name</span>: <span class="hljs-string">'广州'</span>,
  <span class="hljs-attr">value</span>: <span class="hljs-string">'gz'</span>,
  <span class="hljs-attr">parent</span>: <span class="hljs-string">'china001'</span>
}, {
  <span class="hljs-attr">name</span>: <span class="hljs-string">'深圳'</span>,
  <span class="hljs-attr">value</span>: <span class="hljs-string">'sz'</span>,
  <span class="hljs-attr">parent</span>: <span class="hljs-string">'china001'</span>
}, {
  <span class="hljs-attr">name</span>: <span class="hljs-string">'广西001'</span>,
  <span class="hljs-attr">value</span>: <span class="hljs-string">'gx001'</span>,
  <span class="hljs-attr">parent</span>: <span class="hljs-string">'china002'</span>
}, {
  <span class="hljs-attr">name</span>: <span class="hljs-string">'广西002'</span>,
  <span class="hljs-attr">value</span>: <span class="hljs-string">'gx002'</span>,
  <span class="hljs-attr">parent</span>: <span class="hljs-string">'china002'</span>
}, {
  <span class="hljs-attr">name</span>: <span class="hljs-string">'美国001_001'</span>,
  <span class="hljs-attr">value</span>: <span class="hljs-string">'0003'</span>,
  <span class="hljs-attr">parent</span>: <span class="hljs-string">'usa001'</span>
}, {
  <span class="hljs-attr">name</span>: <span class="hljs-string">'美国001_002'</span>,
  <span class="hljs-attr">value</span>: <span class="hljs-string">'0004'</span>,
  <span class="hljs-attr">parent</span>: <span class="hljs-string">'usa001'</span>
}, {
  <span class="hljs-attr">name</span>: <span class="hljs-string">'美国002_001'</span>,
  <span class="hljs-attr">value</span>: <span class="hljs-string">'0005'</span>,
  <span class="hljs-attr">parent</span>: <span class="hljs-string">'usa002'</span>
}, {
  <span class="hljs-attr">name</span>: <span class="hljs-string">'美国002_002'</span>,
  <span class="hljs-attr">value</span>: <span class="hljs-string">'0006'</span>,
  <span class="hljs-attr">parent</span>: <span class="hljs-string">'usa002'</span>
}]
</code></pre>

      </div>
      
      <a v-if="demos.length" class="anchor" id="examples">Examples</a>
      <br/>
      <template v-if="demos.length" v-for="demo in demos">
        <a class="anchor" :id="'examples:' + demo.title">{{ demo.title }}</a>
        <br/>
        <div class="demo-header">
          <span class="demo-title">{{ demo.title }}</span>
        </div>
        <div class="demos" :style="{height: demo.height}">
          <div class="demo-iframe-box">
            <lazy-component>
              <iframe
                :src="domain + '?no-background-color=' + demo.noBackgroundColor +'&locale=en&transition=none&hide-nav=true&hide-tab-bar=true#/components/' + demo.file"
                width="375"
                height="600"
                border="0"
                frameborder="0"
                style="margin: 0 auto;"></iframe>
            </lazy-component>
          </div>
          <div class="demo-code-box" :style="{overflow: demo.height === demo.oriHeight ? 'hidden' : 'scroll'}">
            <div v-html="demo.code" contenteditable></div>
            <div v-if="demo.height === demo.oriHeight" class="demo-code-masker" @click="demo.height='auto'">
              <div>
                  <img class="demo-qr" width="100" :src="'https://qr.vux.li/api.php?text=' + encodeURIComponent(domain + '?locale=en#/components/' + demo.file)"/>
                  <br/>
                  <span>
                    <el-icon class="el-icon-arrow-left"/>
                    <el-icon class="el-icon-arrow-right"/>
                    Show code
                  <br/>
                  <!--<span class="demo-path">src/demos/{{ demo.file }}.vue</span>-->
                </span>
              </div>
            </div>
            <span v-if="demo.height === 'auto'" class="hide-code" @click="demo.height=demo.oriHeight">
              <el-icon class="el-icon-close"></el-icon>
            </span>
          </div>
        </div>
      </template>

      <template v-for="component in componentList">
        <div>
          <a v-if="componentList.length > 1" class="anchor" :id="'components:' + component.name">{{ component.name }}</a>
          <a v-else class="anchor" id="api">API</a>
          <br/>
          <h2
            v-show="componentList.length > 1"
            class="vux-component-name-sub-item">{{ component.name }}</h2>
            
          <template v-if="component.meta.items && component.meta.description">
            <div v-html="component.meta.description"></div>
          </template>

          <template v-if="component.meta.props">
            <h2>Props</h2>
            <table>
              <thead>
                <tr>
                  <td>name</td>
                  <td style="width:48px;">type</td>
                  <td>default</td>
                  <td>description</td>
                  <td>required version</td>
                </tr>
              </thead>
              <tbody>
                <tr v-for="(prop, i) in component.meta.props">
                  <td class="prop-name">
                    <el-tooltip content="click to copy" placement="left" :hide-after="0" :open-delay="50">
                      <span
                      v-clipboard:copy="i"
                      v-clipboard:success="onCopy">{{ i }}</span>
                    </el-tooltip>
                  </td>
                  <td v-html="getTypeHTML(prop.type)"></td>
                  <td>{{ prop.default}}</td>
                  <td v-html="prop['en'].replace(/`(.*?)`/g, '<code>$1</code>')"></td>
                  <td>{{ prop.version || '--'}}</td>
                </tr>
              </tbody>
            </table>
          </template>

          <template v-if="component.meta.events">
            <h2>Events</h2>
            <table>
              <thead>
                <tr>
                  <td>name</td>
                  <td>params</td>
                  <td>description</td>
                  <td>required version</td>
                </tr>
              </thead>
              <tbody>
                <tr v-for="(event, i) in component.meta.events">
                  <td class="prop-name">
                    <el-tooltip content="click to copy" placement="left" :hide-after="0" :open-delay="50">
                      <span
                      v-clipboard:copy="'@' + i"
                      v-clipboard:success="onCopy">@{{ i }}</span>
                    </el-tooltip>
                  </td>
                  <td v-html="event.params ? event.params.replace(/`(.*?)`/g, '<code>$1</code>') : '--'"></td>
                  <td v-html="event['en'] ? event['en'].replace(/`(.*?)`/g, '<code>$1</code>') : '--'"></td>
                  <td>{{ event['version'] || '--' }}</td>
                </tr>
              </tbody>
            </table>
          </template>
      

          <template v-if="component.meta.slots">
            <h2>Slots</h2>
            <table>
              <thead>
                <tr>
                  <td>name</td>
                  <td>description</td>
                  <td>required version</td>
                </tr>
              </thead>
              <tbody>
                <tr v-for="(slot, i) in component.meta.slots" :class="{'slot-disabled': slot['status'] === 'deprecated'}">
                  <td class="prop-name">
                    <el-tooltip content="click to copy" placement="left" :hide-after="0" :open-delay="50">
                      <span
                      v-clipboard:copy="i"
                      v-clipboard:success="onCopy">{{ i === 'default' ? 'default' : i }}</span>
                    </el-tooltip>
                  </td>
                  <td v-html="slot['en'] ? slot['en'].replace(/`(.*?)`/g, '<code>$1</code>') : ''"></td>
                  <td>{{ slot['version'] || '--' }}</td>
                </tr>
              </tbody>
            </table>
          </template>
          
          <template v-if="component.meta.methods">
            <h2>Functions</h2>
            <table>
              <thead>
                <tr>
                  <td>name</td>
                  <td>params</td>
                  <td>description</td>
                  <td>required version</td>
                </tr>
              </thead>
              <tbody>
                <tr v-for="(method, i) in component.meta.methods">
                  <td class="prop-name">
                    <el-tooltip content="click to copy" placement="left" :hide-after="0" :open-delay="50">
                      <span
                      v-clipboard:copy="i"
                      v-clipboard:success="onCopy">{{ i }}</span>
                    </el-tooltip>
                  </td>
                  <td v-html="method['params'] ? method['params'].replace(/`(.*?)`/g, '<code>$1</code>') : ''"></td>
                  <td v-html="method['en'].replace(/`(.*?)`/g, '<code>$1</code>')"></td>
                  <td>{{ method['version'] }}</td>
                </tr>
              </tbody>
            </table>
          </template>

          <template v-if="component.meta.variables">
            <a class="anchor" id="variables">Variables</a>
            <br/>
            <h2>Variables</h2>
            <table>
              <thead>
                <tr>
                  <td>name</td>
                  <td>default</td>
                  <td>description</td>
                  <td>inherited name</td>
                </tr>
              </thead>
              <tbody>
                <tr v-for="(variable, i) in component.meta.variables">
                  <td class="prop-name">
                    <el-tooltip content="click to copy" placement="left" :hide-after="0" :open-delay="50">
                      <span
                      v-clipboard:copy="'@' + variable.name"
                      v-clipboard:success="onCopy">@{{ variable.name }}</span>
                    </el-tooltip>
                  </td>
                  <td>
                    <em
                      :ref="'propColor' + i"
                      v-if="!$refs['propColor' + i] || ($refs['propColor' + i][0] && $refs['propColor' + i][0].style.backgroundColor)"
                      class="prop-color"
                      :style="{ backgroundColor: variable.value }">
                    </em>
                    {{ variable.value }}
                  </td>
                  <td>{{ variable['desc']['en'] || '--' }}</td>
                  <td>{{ variable.inherited_name }}</td>
                </tr>
              </tbody>
            </table>
          </template>
      
          <template v-if="component.meta.tips && component.meta.tips['en']">
            <a class="anchor" id="tips">Tips</a>
            <br>
            <h2>Tips</h2>
            <div>
              <ul>
                <li v-for="tip in component.meta.tips['en']">
                <el-tag size="mini" type="success" class="component-tip-tag">Q</el-tag> <span class="component-tip-question">{{ tip.q }}</span>
                <div v-html="tip.a" class="tip-answer-box"></div>
                </li>
              </ul>
            </div>
          </template>
        </div>
      </template>

      <!--<h2>社区相关讨论</h2>
      [即将上线]
      -->
    
      <br>
      <div v-if="issues.length">
        <a class="anchor" id="Issues">Issues</a>
        <br/>
        <h2>Related issues</h2>
        <ul>
          <li v-for="issue in issues"><a target="_blank" :href="issue.html_url">#{{ issue.number}} <span style="color:#666;">{{ issue.title }}</span></a></li>
        </ul>
      </div>
      <br>
    
      <div v-if="gitMetas">
        <a class="anchor" id="contributors">Contributors</a>
        <h2>Contributors</h2>
        <p>Total commits quantity: {{ gitMetas.commitCount }}，Total contributors quantity: {{gitMetas.commitUniqueCount}}
        </p>
        <a v-for="person in gitMetas.commitMembers" class="contributor-item" :href="'https://github.com/' + person.authorName" target="_blank" :title="'contribute' + person.count">{{person.authorName}}</a>
      </div>
      <br>

      <div v-if="metas.changes">
        <a class="anchor" id="changelog">Changelog</a>
        <br/>
        <h2>Releases</h2>
        <ul v-if="metas.changes">
          <template v-for="(changelog, version) in metas.changes">
            <li v-for="log in changelog['en']">
              <router-link :to="'/en/changelog/' + version + '.html'" class="changelog-version">{{version}}</router-link> {{log}}
            </li>
          </template>
        </ul>
      </div>

      <h2 v-if="metas.references">Referrences</h2>
      <ul v-if="metas.references">
        <li v-for="link in metas.references['en']">
          <a :href="link.link" target="_blank">{{link.title}}</a>
        </li>
      </ul>

      <el-dialog
        class="sourcec-code-dialog"
        top="0"
        width="80%"
        :visible.sync="sourceCodeDialogVisibility">
        <div class="code-box" contenteditable v-html="demoCode"></div>
      </el-dialog>

    </div>
  </template>


  <script>
  import Axios from 'axios'

  // const metas = require('json-loader!yaml-loader!../../../src/components/picker/metas.yml')
  const metas = {
  "description": "Picker是指提供多个选项集合供用户选择其中一项的控件。Picker展示区域有限，部分选项会被隐藏，最好是当用户对所有选项都比较熟悉、有预期的时候，才使用Picker。\n- 合理的默认选项能让用户减少操作次数，提升效率。\n- 选项的排列顺序要依据当前上下文情景而定，例如衣服尺码按从小到大的顺序排列，而不是根据衣服尺码的首字母在字母表的顺序排列。\n- 滚轮选择器控制在五列以内。为了保证手机屏幕触控精度，以免发生误触，滚轮选择器建议控制在五列以内。\n- 使用相对概念增强感知。比起绝对的“某年某月日”，用“今天”、“昨天”等相对概念，能更快的激发人对时间的感知。\n- 如果选项非常多，而且选项本身比较复杂难理解需要辅助的解释，建议用容纳更多的选项的其他形式，例如日历或者新页面。\n",
  "category": {
    "en": "Form",
    "zh-CN": "表单"
  },
  "icon": "&#xe627;",
  "tags": {
    "en": [
      "picker",
      "form"
    ],
    "zh-CN": [
      "选择",
      "表单",
      "联动"
    ]
  },
  "extra": "\n::: warning\n  请确保列表项的`value`值是字符串，使用数字会出错。\n  <br />\n  如果你的业务接口返回数字值为数字，需要你先处理成字符串；同样，获取到值时为字符串，你需要自己转换成数字。\n:::\n\n非联动情况下，列表数据格式示例：\n\n``` js\n// data\n[['小米', 'iPhone', '华为', '情怀', '三星', '其他', '不告诉你'], ['小米1', 'iPhone2', '华为3', '情怀4', '三星5', '其他6', '不告诉你7']]\n\n// 或者使用 name => value 的形式\n[[{\n  name: '2019届5班',\n  value: '1'\n}, {\n  name: '2019届4班',\n  value: '2'\n}]]\n\n// value\n['小米', '小米1']\n```\n\n联动时，列表数据格式示例：\n\n``` js\n// data\n[{\n  name: '中国',\n  value: 'china',\n  parent: '0' // 为一级时可以不写 parent，但是此时允许为数字 0、空字符串或者字符串 '0'\n}, {\n  name: '美国',\n  value: 'USA',\n  parent: '0'\n}, {\n  name: '广东',\n  value: 'china001',\n  parent: 'china'\n}, {\n  name: '广西',\n  value: 'china002',\n  parent: 'china'\n}, {\n  name: '美国001',\n  value: 'usa001',\n  parent: 'USA'\n}, {\n  name: '美国002',\n  value: 'usa002',\n  parent: 'USA'\n}, {\n  name: '广州',\n  value: 'gz',\n  parent: 'china001'\n}, {\n  name: '深圳',\n  value: 'sz',\n  parent: 'china001'\n}, {\n  name: '广西001',\n  value: 'gx001',\n  parent: 'china002'\n}, {\n  name: '广西002',\n  value: 'gx002',\n  parent: 'china002'\n}, {\n  name: '美国001_001',\n  value: '0003',\n  parent: 'usa001'\n}, {\n  name: '美国001_002',\n  value: '0004',\n  parent: 'usa001'\n}, {\n  name: '美国002_001',\n  value: '0005',\n  parent: 'usa002'\n}, {\n  name: '美国002_002',\n  value: '0006',\n  parent: 'usa002'\n}]\n```\n",
  "props": {
    "value": {
      "type": "Array",
      "default": "",
      "en": "picker value, use `v-model` for binding",
      "zh-CN": "表单值，使用 `v-model` 绑定"
    },
    "data": {
      "type": "Array",
      "default": "",
      "en": "array list",
      "zh-CN": "选项列表数据"
    },
    "columns": {
      "type": "Number",
      "en": "how many columns in chained-mode",
      "zh-CN": "指定联动模式下的列数，当不指定时表示非联动"
    },
    "fixed-columns": {
      "type": "Number",
      "en": "how many columns will show",
      "zh-CN": "指定显示多少列，隐藏多余的"
    },
    "column-width": {
      "type": "Array",
      "version": "v2.2.0",
      "en": "custom width for each picker column, for example for a 3-column picker: [1/2, 1/5] ",
      "zh-CN": "定义每一列宽度，只需要定义除最后一列宽度，最后一列自动宽度， 比如对于3列选择，可以这样：[1/2, 1/5]"
    }
  },
  "events": {
    "on-change": {
      "params": "`(value)`",
      "en": "emits when value is changed",
      "zh-CN": "选择值变化时触发"
    }
  },
  "methods": {
    "getNameValues": {
      "version": "v2.3.1",
      "en": "get labels of current value",
      "zh-CN": "根据 value 获取字面值"
    }
  },
  "changes": {
    "v2.9.0": {
      "en": [
        "[enhance] show warning when picker value is not a string #2568"
      ],
      "zh-CN": [
        "[enhance] 开发模式下 picker 数据非字符串时显示提示 #2568"
      ]
    },
    "v2.7.9": {
      "en": [
        "[fix] fix typo item_class => itemClass #2457"
      ],
      "zh-CN": [
        "[fix] 修正 itemClass 拼写错误 #2457"
      ]
    },
    "v2.7.8": {
      "en": [
        "[fix] Fix chain mode get value is wrong when the children is empty data."
      ],
      "zh-CN": [
        "[fix] 修复多级联动模式下，子代没有数据时，取值不正确。"
      ]
    },
    "v2.7.3": {
      "en": [
        "[enhance] add development tip for chained-mode picker without specifying prop:columns"
      ],
      "zh-CN": [
        "[enhance] 渲染出错时提示是否联动数据忘了指定列数"
      ]
    },
    "v2.7.0": {
      "en": [
        "[change] picker move distance do not respect html[data-dpr] by default #2082 #1979"
      ],
      "zh-CN": [
        "[change] picker 移动距离不再遵从 html[data-dpr]，需使用 ConfigPlugin 配置 #2082 #1979"
      ]
    },
    "v2.6.2": {
      "en": [
        "[enhance] scroll distance respects html[data-dpr] #1979"
      ],
      "zh-CN": [
        "[enhance] 滚动距离支持从 html[data-dpr] 换算 #1979"
      ]
    },
    "v2.3.1": {
      "en": [
        "[feature] Add getNameValues Method #1418"
      ],
      "zh-CN": [
        "[feature] 增加获取对应文字方法 #1418"
      ]
    },
    "v2.2.1-rc.3": {
      "en": [
        "[fix] Fix no re-rendering when value is set to empty array. #1230"
      ],
      "zh-CN": [
        "[fix] 修复当值设为空数组时不会重新渲染的问题. #1230"
      ]
    },
    "v2.1.1-rc.7": {
      "en": [
        "[enhance] Support PC mouse drag  #1039 @michael829"
      ],
      "zh-CN": [
        "[enhance] 支持 PC 上鼠标选择 #1039 @michael829"
      ]
    },
    "v2.4.1": {
      "en": [
        "[fix] Fix a bug caused by unexpected end of json value #1584"
      ],
      "zh-CN": [
        "[fix] 修复json格式不正确引起的bug #1584"
      ]
    }
  }
}
  const demos = []

  let componentList = []
  if (Array.isArray(metas.items)) {
    try {
      metas.items.forEach((item, index) => {
        const meta = {
          name: item,
          meta: metas[item]
        }
        if (meta.meta.props === null) {
          delete meta.meta.props
        }
        if (index === metas.items.length - 1) {
          if (meta.meta) {
            meta.meta.variables = metas.variables
          }
        }
        componentList.push(meta)
      })
    } catch (e) {
      console.log(e)
    }
  } else {
    componentList.push({
      meta: metas
    })
  }
  const gitMetas = require('./picker_git_metas.json')
  const demoCode = decodeURIComponent(`%3Cpre%20class%3D%22hljs%22%3E%3Ccode%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Etemplate%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ediv%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Egroup-title%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%20%7B%7B%20%24t('Normal%20usage%2C%20the%20first%20one%20is%20selected%20without%20setting%20default%20value')%20%7D%7D%20%7B%7Byear1%7D%7D%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Egroup-title%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Epicker%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Adata%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E'years'%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Ev-model%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E'year1'%3C%2Fspan%3E%20%40%3Cspan%20class%3D%22hljs-attr%22%3Eon-change%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E'change'%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Epicker%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ebr%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Egroup-title%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%20%7B%7B%20%24t('Asynchronous%20loading%20and%20dynamic%20change%20of%20data')%20%7D%7D%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Egroup-title%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Epicker%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Adata%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E'years001'%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Ev-model%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E'year001'%3C%2Fspan%3E%20%40%3Cspan%20class%3D%22hljs-attr%22%3Eon-change%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E'change'%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Epicker%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ebr%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Egroup%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ecell%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Atitle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22%24t('Current%20value')%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Avalue%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22year001%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ecell%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Egroup%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ex-button%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Etype%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22primary%22%3C%2Fspan%3E%20%40%3Cspan%20class%3D%22hljs-attr%22%3Eclick.native%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22changeValue(%5B%5B'1'%2C'3'%2C'5'%2C'7'%2C'9'%2C'11'%5D%2C%5B'2'%2C'3'%2C'4'%2C'5'%5D%2C%5B'a'%2C'b'%2C'c'%5D%5D)%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%20%7B%7B%20%24t('Set%20Data%201')%20%7D%7D%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ex-button%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ex-button%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Etype%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22primary%22%3C%2Fspan%3E%20%40%3Cspan%20class%3D%22hljs-attr%22%3Eclick.native%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22changeValue(%5B%5B'1'%2C'3'%2C'5'%2C'7'%2C'9'%2C'11'%5D%2C%5B'2'%2C'3'%2C'4'%2C'5'%5D%5D)%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%7B%7B%20%24t('Set%20Data%202')%20%7D%7D%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ex-button%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ex-button%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Etype%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22primary%22%3C%2Fspan%3E%20%40%3Cspan%20class%3D%22hljs-attr%22%3Eclick.native%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22changeValue(%5B%5B'2'%2C'4'%2C'6'%2C'8'%2C'10'%2C'11'%5D%5D)%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%7B%7B%20%24t('Set%20Data%203')%20%7D%7D%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ex-button%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ebr%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Egroup-title%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%20%7B%7B%20%24t('With%20default%20value')%20%7D%7D%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Egroup-title%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Epicker%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Adata%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E'years'%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Ev-model%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E'year2'%3C%2Fspan%3E%20%40%3Cspan%20class%3D%22hljs-attr%22%3Eon-change%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E'change'%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Epicker%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ebr%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Egroup-title%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%20%7B%7B%20%24t('Two-way%20data%20binding')%20%7D%7D%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Egroup-title%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Epicker%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Adata%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E'years'%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Ev-model%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E'year3'%3C%2Fspan%3E%20%40%3Cspan%20class%3D%22hljs-attr%22%3Eon-change%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E'change3'%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Epicker%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Eselect%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Ev-model%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E'year5'%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Eoption%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Ev-for%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E'one%20in%20years%5B0%5D'%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Avalue%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E'one.value'%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%7B%7Bone.name%7D%7D%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Eoption%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Eselect%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ebr%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Egroup-title%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%20%7B%7B%20%24t('Multi%20cols%20in%20non%20chained-mode')%20%7D%7D%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Egroup-title%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Epicker%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Adata%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E'years1'%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Ev-model%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E'year4'%3C%2Fspan%3E%20%40%3Cspan%20class%3D%22hljs-attr%22%3Eon-change%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E'change'%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Epicker%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ebr%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Egroup-title%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%20%7B%7B%20%24t('Five%20columns')%20%7D%7D%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Egroup-title%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Epicker%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Adata%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E'year6'%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Ev-model%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E'year6Value'%3C%2Fspan%3E%20%40%3Cspan%20class%3D%22hljs-attr%22%3Eon-change%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E'change'%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Epicker%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ebr%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Egroup-title%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%7B%7B%20%24t('Locations%20in%20chained-mode')%20%7D%7D%3A%20%7B%7B%20%24t('Current%20value')%20%7D%7D%20%7B%7Byear7Value%7D%7D%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ebr%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%20%7B%7B%20%24t('Text%20corresponding%20to%20the%20value')%20%7D%7D%3A%20%7B%7B%24refs.picker1%26amp%3B%26amp%3B%24refs.picker1.getNameValues()%7D%7D%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Egroup-title%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Epicker%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Adata%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E'year7'%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Acolumns%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E3%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Ev-model%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E'year7Value'%3C%2Fspan%3E%20%40%3Cspan%20class%3D%22hljs-attr%22%3Eon-change%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E'change'%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Eref%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22picker1%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Epicker%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ex-button%3C%2Fspan%3E%20%40%3Cspan%20class%3D%22hljs-attr%22%3Eclick.native%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22setData1%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Etype%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22primary%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%20%7B%7B%20%24t('Set%20value%20to')%20%7D%7D%20%5B%22USA%22%2C%20%22usa002%22%2C%20%220005%22%5D%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ex-button%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ex-button%3C%2Fspan%3E%20%40%3Cspan%20class%3D%22hljs-attr%22%3Eclick.native%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22setData2%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Etype%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22primary%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%20%7B%7B%20%24t('Set%20value%20to')%20%7D%7D%20%5B%22china%22%2C%20%22china002%22%2C%20%22gz%22%5D%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ex-button%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ex-button%3C%2Fspan%3E%20%40%3Cspan%20class%3D%22hljs-attr%22%3Eclick.native%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22setList%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Etype%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22primary%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3ESet%20List%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ex-button%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ebr%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Egroup-title%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%20%7B%7B%20%24t('3%20cols%20data%20but%20only%20show%202%20cols')%20%7D%7D%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Egroup-title%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Epicker%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Adata%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E'year7'%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Afixed-columns%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%222%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Acolumns%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E3%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Ev-model%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E'year8Value'%3C%2Fspan%3E%20%40%3Cspan%20class%3D%22hljs-attr%22%3Eon-change%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E'change'%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Epicker%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ediv%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Etemplate%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%0A%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ei18n%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20'Normal%20usage%2C%20the%20first%20one%20is%20selected%20without%20setting%20default%20value'%3A%0A%20%20%20%20zh-CN%3A%20%E9%BB%98%E8%AE%A4%EF%BC%8C%E4%B8%8D%E8%AE%BE%E7%BD%AE%E9%BB%98%E8%AE%A4%E5%80%BC%E6%97%B6%E9%80%89%E4%B8%AD%E7%AC%AC%E4%B8%80%E4%B8%AA%0A%20%20Asynchronous%20loading%20and%20dynamic%20change%20of%20data%3A%0A%20%20%20%20zh-CN%3A%20%E5%BC%82%E6%AD%A5%E5%8A%A0%E8%BD%BD%E5%8F%8A%E5%8A%A8%E6%80%81%E6%94%B9%E5%8F%98%E6%95%B0%E6%8D%AE%0A%20%20Set%20data%201%3A%0A%20%20%20%20zh-CN%3A%20%E8%AE%BE%E7%BD%AE%E6%95%B0%E5%80%BC1%0A%20%20Set%20data%202%3A%0A%20%20%20%20zh-CN%3A%20%E8%AE%BE%E7%BD%AE%E6%95%B0%E5%80%BC2%0A%20%20Set%20data%203%3A%0A%20%20%20%20zh-CN%3A%20%E8%AE%BE%E7%BD%AE%E6%95%B0%E5%80%BC3%0A%20%20With%20default%20value%3A%0A%20%20%20%20zh-CN%3A%20%E8%AE%BE%E7%BD%AE%E9%BB%98%E8%AE%A4%E5%80%BC%E6%97%B6%0A%20%20Two-way%20data%20binding%3A%0A%20%20%20%20zh-CN%3A%20%E5%8F%8C%E5%90%91%E7%BB%91%E5%AE%9A%0A%20%20Multi%20cols%20in%20non%20chained-mode%3A%0A%20%20%20%20zh-CN%3A%20%E9%9D%9E%E8%81%94%E5%8A%A8%E5%A4%9A%E5%88%97%0A%20%20Five%20columns%3A%0A%20%20%20%20zh-CN%3A%20%E4%BA%94%E5%88%97%0A%20%20Locations%20in%20chained-mode%3A%0A%20%20%20%20zh-CN%3A%20%E5%9C%B0%E5%8C%BA%E8%81%94%E5%8A%A8%0A%20%20Text%20corresponding%20to%20the%20value%3A%0A%20%20%20%20zh-CN%3A%20%E9%80%89%E4%B8%AD%E5%80%BC%E6%89%80%E5%AF%B9%E5%BA%94%E7%9A%84%E6%96%87%E5%AD%97%0A%20%203%20cols%20data%20but%20only%20show%202%20cols%3A%0A%20%20%20%20zh-CN%3A%203%E5%88%97%E7%9A%84%E6%95%B0%E6%8D%AE%EF%BC%8C%E5%8F%AA%E6%98%BE%E7%A4%BA%E4%B8%A4%E5%88%97%0A%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ei18n%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%0A%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Escript%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22javascript%22%3E%0A%3Cspan%20class%3D%22hljs-keyword%22%3Eimport%3C%2Fspan%3E%20%7B%20Cell%2C%20Group%2C%20Picker%2C%20GroupTitle%2C%20XButton%20%7D%20%3Cspan%20class%3D%22hljs-keyword%22%3Efrom%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-string%22%3E'vux'%3C%2Fspan%3E%0A%0A%3Cspan%20class%3D%22hljs-keyword%22%3Elet%3C%2Fspan%3E%20years%20%3D%20%5B%5D%0A%3Cspan%20class%3D%22hljs-keyword%22%3Efor%3C%2Fspan%3E%20(%3Cspan%20class%3D%22hljs-keyword%22%3Evar%3C%2Fspan%3E%20i%20%3D%20%3Cspan%20class%3D%22hljs-number%22%3E2000%3C%2Fspan%3E%3B%20i%20%26lt%3B%3D%20%3Cspan%20class%3D%22hljs-number%22%3E2030%3C%2Fspan%3E%3B%20i%2B%2B)%20%7B%0A%20%20years.push(%7B%0A%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3Ename%3C%2Fspan%3E%3A%20i%20%2B%20%3Cspan%20class%3D%22hljs-string%22%3E'%E5%B9%B4'%3C%2Fspan%3E%2C%0A%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3Evalue%3C%2Fspan%3E%3A%20i%20%2B%20%3Cspan%20class%3D%22hljs-string%22%3E''%3C%2Fspan%3E%0A%20%20%7D)%0A%7D%0A%3Cspan%20class%3D%22hljs-keyword%22%3Eexport%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-keyword%22%3Edefault%3C%2Fspan%3E%20%7B%0A%20%20%3Cspan%20class%3D%22hljs-attr%22%3Ecomponents%3C%2Fspan%3E%3A%20%7B%0A%20%20%20%20Picker%2C%0A%20%20%20%20GroupTitle%2C%0A%20%20%20%20XButton%2C%0A%20%20%20%20Cell%2C%0A%20%20%20%20Group%0A%20%20%7D%2C%0A%20%20%3Cspan%20class%3D%22hljs-attr%22%3Emethods%3C%2Fspan%3E%3A%20%7B%0A%20%20%20%20changeValue%20(value)%20%7B%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-keyword%22%3Ethis%3C%2Fspan%3E.years001%20%3D%20value%0A%20%20%20%20%7D%2C%0A%20%20%20%20change%20(value)%20%7B%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-built_in%22%3Econsole%3C%2Fspan%3E.log(%3Cspan%20class%3D%22hljs-string%22%3E'new%20Value'%3C%2Fspan%3E%2C%20value)%0A%20%20%20%20%7D%2C%0A%20%20%20%20change3%20(value)%20%7B%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-keyword%22%3Ethis%3C%2Fspan%3E.year5%20%3D%20value%5B%3Cspan%20class%3D%22hljs-number%22%3E0%3C%2Fspan%3E%5D%0A%20%20%20%20%7D%2C%0A%20%20%20%20setData1%20()%20%7B%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-keyword%22%3Ethis%3C%2Fspan%3E.year7Value%20%3D%20%5B%3Cspan%20class%3D%22hljs-string%22%3E'USA'%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-string%22%3E'usa002'%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-string%22%3E'0005'%3C%2Fspan%3E%5D%0A%20%20%20%20%7D%2C%0A%20%20%20%20setData2%20()%20%7B%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-keyword%22%3Ethis%3C%2Fspan%3E.year7Value%20%3D%20%5B%3Cspan%20class%3D%22hljs-string%22%3E'china'%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-string%22%3E'china002'%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-string%22%3E'gz'%3C%2Fspan%3E%5D%0A%20%20%20%20%7D%2C%0A%20%20%20%20setList%20()%20%7B%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-keyword%22%3Ethis%3C%2Fspan%3E.year7.push(%7B%0A%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3Ename%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-string%22%3E'%E7%BE%8E%E5%9B%BD002_003'%3C%2Fspan%3E%2C%0A%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3Evalue%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-string%22%3E'0007'%3C%2Fspan%3E%2C%0A%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3Eparent%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-string%22%3E'usa002'%3C%2Fspan%3E%0A%20%20%20%20%20%20%7D)%0A%20%20%20%20%7D%0A%20%20%7D%2C%0A%20%20%3Cspan%20class%3D%22hljs-attr%22%3Ewatch%3C%2Fspan%3E%3A%20%7B%0A%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3Eyear5%3C%2Fspan%3E%3A%20%7B%0A%20%20%20%20%20%20handler%20(val)%20%7B%0A%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-keyword%22%3Ethis%3C%2Fspan%3E.year3%5B%3Cspan%20class%3D%22hljs-number%22%3E0%3C%2Fspan%3E%5D%20%3D%20val%0A%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-comment%22%3E%2F%2F%20this.year3.%24set(0%2C%20val)%3C%2Fspan%3E%0A%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-keyword%22%3Ethis%3C%2Fspan%3E.%24set(%3Cspan%20class%3D%22hljs-keyword%22%3Ethis%3C%2Fspan%3E.year3%2C%20%3Cspan%20class%3D%22hljs-number%22%3E0%3C%2Fspan%3E%2C%20val)%0A%20%20%20%20%20%20%7D%2C%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3Edeep%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-literal%22%3Etrue%3C%2Fspan%3E%0A%20%20%20%20%7D%2C%0A%20%20%20%20change3%20(value)%20%7B%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-keyword%22%3Ethis%3C%2Fspan%3E.year5%20%3D%20value%5B%3Cspan%20class%3D%22hljs-number%22%3E0%3C%2Fspan%3E%5D%0A%20%20%20%20%7D%0A%20%20%7D%2C%0A%20%20data%20()%20%7B%0A%20%20%20%20%3Cspan%20class%3D%22hljs-keyword%22%3Ereturn%3C%2Fspan%3E%20%7B%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3Eyears%3C%2Fspan%3E%3A%20%5Byears%5D%2C%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3Eyears001%3C%2Fspan%3E%3A%20%5B%5D%2C%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3Eyear001%3C%2Fspan%3E%3A%20%5B%5D%2C%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3Eyears1%3C%2Fspan%3E%3A%20%5Byears%2C%20%5B%3Cspan%20class%3D%22hljs-number%22%3E1%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-number%22%3E2%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-number%22%3E3%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-number%22%3E4%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-number%22%3E5%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-number%22%3E6%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-number%22%3E7%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-number%22%3E8%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-number%22%3E9%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-number%22%3E10%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-number%22%3E11%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-number%22%3E12%3C%2Fspan%3E%5D%5D%2C%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3Eyear1%3C%2Fspan%3E%3A%20%5B%3Cspan%20class%3D%22hljs-string%22%3E''%3C%2Fspan%3E%5D%2C%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3Eyear2%3C%2Fspan%3E%3A%20%5B%3Cspan%20class%3D%22hljs-string%22%3E'2002'%3C%2Fspan%3E%5D%2C%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3Eyear3%3C%2Fspan%3E%3A%20%5B%3Cspan%20class%3D%22hljs-string%22%3E'2005'%3C%2Fspan%3E%5D%2C%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3Eyear4%3C%2Fspan%3E%3A%20%5B%3Cspan%20class%3D%22hljs-string%22%3E'2002'%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-string%22%3E'4'%3C%2Fspan%3E%5D%2C%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3Eyear5%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-string%22%3E'2005'%3C%2Fspan%3E%2C%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3Eyear6%3C%2Fspan%3E%3A%20%5B%0A%20%20%20%20%20%20%20%20%5B%3Cspan%20class%3D%22hljs-string%22%3E'%E4%BD%A0'%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-string%22%3E'%E6%88%91'%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-string%22%3E'%E4%BB%96'%3C%2Fspan%3E%5D%2C%0A%20%20%20%20%20%20%20%20%5B%3Cspan%20class%3D%22hljs-string%22%3E'you'%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-string%22%3E'I'%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-string%22%3E'him'%3C%2Fspan%3E%5D%2C%0A%20%20%20%20%20%20%20%20%5B%3Cspan%20class%3D%22hljs-string%22%3E'ni'%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-string%22%3E'wo'%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-string%22%3E'ta'%3C%2Fspan%3E%5D%2C%0A%20%20%20%20%20%20%20%20%5B%3Cspan%20class%3D%22hljs-number%22%3E1%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-number%22%3E2%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-number%22%3E3%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-number%22%3E4%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-number%22%3E5%3C%2Fspan%3E%5D%2C%0A%20%20%20%20%20%20%20%20%5B%3Cspan%20class%3D%22hljs-number%22%3E5%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-number%22%3E4%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-number%22%3E3%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-number%22%3E2%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-number%22%3E1%3C%2Fspan%3E%5D%0A%20%20%20%20%20%20%5D%2C%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3Eyear6Value%3C%2Fspan%3E%3A%20%5B%3Cspan%20class%3D%22hljs-string%22%3E'%E6%88%91'%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-string%22%3E'him'%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-string%22%3E'ni'%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-string%22%3E'1'%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-string%22%3E'2'%3C%2Fspan%3E%5D%2C%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3Eyear7%3C%2Fspan%3E%3A%20%5B%7B%0A%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3Ename%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-string%22%3E'%E4%B8%AD%E5%9B%BD'%3C%2Fspan%3E%2C%0A%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3Evalue%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-string%22%3E'china'%3C%2Fspan%3E%2C%0A%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3Eparent%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-number%22%3E0%3C%2Fspan%3E%0A%20%20%20%20%20%20%7D%2C%20%7B%0A%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3Ename%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-string%22%3E'%E7%BE%8E%E5%9B%BD'%3C%2Fspan%3E%2C%0A%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3Evalue%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-string%22%3E'USA'%3C%2Fspan%3E%2C%0A%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3Eparent%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-number%22%3E0%3C%2Fspan%3E%0A%20%20%20%20%20%20%7D%2C%20%7B%0A%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3Ename%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-string%22%3E'%E5%B9%BF%E4%B8%9C'%3C%2Fspan%3E%2C%0A%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3Evalue%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-string%22%3E'china001'%3C%2Fspan%3E%2C%0A%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3Eparent%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-string%22%3E'china'%3C%2Fspan%3E%0A%20%20%20%20%20%20%7D%2C%20%7B%0A%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3Ename%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-string%22%3E'%E5%B9%BF%E8%A5%BF'%3C%2Fspan%3E%2C%0A%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3Evalue%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-string%22%3E'china002'%3C%2Fspan%3E%2C%0A%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3Eparent%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-string%22%3E'china'%3C%2Fspan%3E%0A%20%20%20%20%20%20%7D%2C%20%7B%0A%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3Ename%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-string%22%3E'%E7%BE%8E%E5%9B%BD001'%3C%2Fspan%3E%2C%0A%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3Evalue%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-string%22%3E'usa001'%3C%2Fspan%3E%2C%0A%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3Eparent%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-string%22%3E'USA'%3C%2Fspan%3E%0A%20%20%20%20%20%20%7D%2C%20%7B%0A%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3Ename%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-string%22%3E'%E7%BE%8E%E5%9B%BD002'%3C%2Fspan%3E%2C%0A%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3Evalue%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-string%22%3E'usa002'%3C%2Fspan%3E%2C%0A%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3Eparent%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-string%22%3E'USA'%3C%2Fspan%3E%0A%20%20%20%20%20%20%7D%2C%20%7B%0A%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3Ename%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-string%22%3E'%E5%B9%BF%E5%B7%9E'%3C%2Fspan%3E%2C%0A%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3Evalue%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-string%22%3E'gz'%3C%2Fspan%3E%2C%0A%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3Eparent%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-string%22%3E'china001'%3C%2Fspan%3E%0A%20%20%20%20%20%20%7D%2C%20%7B%0A%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3Ename%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-string%22%3E'%E6%B7%B1%E5%9C%B3'%3C%2Fspan%3E%2C%0A%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3Evalue%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-string%22%3E'sz'%3C%2Fspan%3E%2C%0A%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3Eparent%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-string%22%3E'china001'%3C%2Fspan%3E%0A%20%20%20%20%20%20%7D%2C%20%7B%0A%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3Ename%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-string%22%3E'%E5%B9%BF%E8%A5%BF001'%3C%2Fspan%3E%2C%0A%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3Evalue%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-string%22%3E'gz'%3C%2Fspan%3E%2C%0A%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3Eparent%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-string%22%3E'china002'%3C%2Fspan%3E%0A%20%20%20%20%20%20%7D%2C%20%7B%0A%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3Ename%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-string%22%3E'%E5%B9%BF%E8%A5%BF002'%3C%2Fspan%3E%2C%0A%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3Evalue%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-string%22%3E'sz'%3C%2Fspan%3E%2C%0A%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3Eparent%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-string%22%3E'china002'%3C%2Fspan%3E%0A%20%20%20%20%20%20%7D%2C%20%7B%0A%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3Ename%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-string%22%3E'%E7%BE%8E%E5%9B%BD001_001'%3C%2Fspan%3E%2C%0A%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3Evalue%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-string%22%3E'0003'%3C%2Fspan%3E%2C%0A%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3Eparent%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-string%22%3E'usa001'%3C%2Fspan%3E%0A%20%20%20%20%20%20%7D%2C%20%7B%0A%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3Ename%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-string%22%3E'%E7%BE%8E%E5%9B%BD001_002'%3C%2Fspan%3E%2C%0A%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3Evalue%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-string%22%3E'0004'%3C%2Fspan%3E%2C%0A%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3Eparent%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-string%22%3E'usa001'%3C%2Fspan%3E%0A%20%20%20%20%20%20%7D%2C%20%7B%0A%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3Ename%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-string%22%3E'%E7%BE%8E%E5%9B%BD002_001'%3C%2Fspan%3E%2C%0A%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3Evalue%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-string%22%3E'0005'%3C%2Fspan%3E%2C%0A%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3Eparent%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-string%22%3E'usa002'%3C%2Fspan%3E%0A%20%20%20%20%20%20%7D%2C%20%7B%0A%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3Ename%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-string%22%3E'%E7%BE%8E%E5%9B%BD002_002'%3C%2Fspan%3E%2C%0A%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3Evalue%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-string%22%3E'0006'%3C%2Fspan%3E%2C%0A%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3Eparent%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-string%22%3E'usa002'%3C%2Fspan%3E%0A%20%20%20%20%20%20%7D%5D%2C%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3Eyear7Value%3C%2Fspan%3E%3A%20%5B%5D%2C%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3Eyear8Value%3C%2Fspan%3E%3A%20%5B%5D%0A%20%20%20%20%7D%0A%20%20%7D%0A%7D%0A%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Escript%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%3C%2Fcode%3E%3C%2Fpre%3E`)

  const domainMap = {
    'development': 'http://localhost:8080/',
    'production': 'https://vux.li/demos/v2/'
  }

  export default {
    head: {
      title: 'Picker component tutorial | VUX - Vue.js Mobile UI Component Framework',
      meta: [{
        name: 'description',
        content: 'Vue component picker for the VUX framework.'
      }, {
        name: 'keywords',
        content: 'picker, vue-picker, vux-picker, vue mobile components'
      }, {
        property: 'og:title',
        content: 'Picker component tutorial | VUX - Vue.js Mobile UI Component Framework'
      }, {
        property: 'og:description',
        content: 'Vue component picker for the VUX framework.'
      }],
      // https://support.google.com/webmasters/answer/189077?hl=en
      link: [{"rel":"alternate","hreflang":"zh-CN","href":"/zh-CN/components/picker.html"}],
      script: [
        {
          innerHTML:'{"@context":"http://schema.org/","@type":"SoftwareApplication","name":"Vue Component picker","screenshot":"","description":"Vue.js component for VUX","url":"/en/components/picker.html","applicationCategory":"Component","author":{"@type":"Organization","name":"VUX","url":"https://vux.li"},"downloadUrl":"https://vux.li","softwareVersion":"2.9.2","aggregateRating":{"@type":"AggregateRating","ratingValue":5,"reviewCount":45},"operatingSystem":"iOS >= 7, Android >= 4.1","offers":{"@type":"Offer","price":0,"priceCurrency":"USD","availability":"http://schema.org/InStock"}}',
          type: 'application/ld+json'
        }
      ],
      __dangerouslyDisableSanitizers: ['script']
    },
    filters: {
      parseCode (str) {
        return str.replace(/`(.*?)`/g, '<code>$1</code>')
      }
    },
    async mounted () {
      const rs = await Axios.get('https://api.github.com/search/issues?q=repo:airyland/vux%20label:component/' + this.componentName)
      this.issues = rs.data.items
      this.hasReady = true
    },
    watch: {
      async sourceCodeDialogVisibility (val) {
        if (val) {
          await this.$nextTick()
          const mask = document.querySelector('.v-modal')
          mask && mask.addEventListener('click', () => {
            this.sourceCodeDialogVisibility = false
          })
        }
      }
    },
    methods: {
      onCopyError () {
        this.$message({
          type: 'error',
          message: 'copy fail!'
        })
      },
      onCopy () {
        this.$message({
          type: 'success',
          message: 'copy done!'
        })
      },
      showSourceCode () {
        this.sourceCodeDialogVisibility = true
      },
      getTypeHTML (type) {
        type = type || 'String'
        if (/,/.test(type)) {
          const list = type.split(',').map(function (one) {
            return one.replace(/^s+|s+$/g, '')
          }).map(function (one) {
            const type = one ?  one.toLowerCase() : 'string'
            return '<span class="type">' + type + '</span>'
          })
          return list.join('<br>')
        } else {
          type = type ?  type.toLowerCase() : 'string'
          return '<span class="type">' + type + '</span>'
        }
      }
    },
    computed: {
      lang () {
        if (this.$route.path.indexOf('/en/') !== -1) {
          return 'en'
        }
        if (this.$route.path.indexOf('/zh-CN/') !== -1) {
          return 'zh-CN'
        }
        return 'en'
      }
    },
    data () {
      return {
        demos,
        isBeta: false,
        hasReady: false,
        issues: [],
        componentName: 'picker',
        demoCode,
        sourceCodeDialogVisibility: false,
        showQr: false,
        metas: metas,
        gitMetas,
        componentList,
        localImportCode: `import { Picker } from 'vux'

export default {
  components: {
    Picker
  }
}`,
        globalImportCode: `// you can also register globally

import Vue from 'vue'
import { Picker } from 'vux'

Vue.component('picker', Picker)
`,
        needImport: true,
        toc: [],
        domain: domainMap[process.env.NODE_ENV]
      }
    }
  }
  </script>

  <style>
  .component-box {
    position: relative;
  }
  .component-demo {
    position: absolute;
    right: 5px;
    top: 15px;
  }
  .prop-color {
    display: inline-block;
    width: 10px;
    height: 10px;
    border: 1px solid #aaa;
  }
  .changelog-version {
    width: 110px;
    display: inline-block;
  }
  .component-extra-links {
    position: relative;
    font-size: 12px;
  }
  .component-extra-links a {
    padding-right: 10px;
    color: #999;
  }
  </style>
    