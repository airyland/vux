
  <template>
    <div class="component-box" :class="demos.length ? 'components-with-toc' : ''">

      <div :class="demos.length ? 'component-header-v2' : 'component-header-v1'">
        <a class="anchor" id="intro">Group</a>
        <div class="title-box">

          <el-badge value="Beta" v-if="isBeta">
            <h1 class="vux-component-name">Group</h1>
          </el-badge>
          <h1 v-else class="vux-component-name">Group</h1>

          <p class="component-extra-links">
            <a href="https://vux.li/demos/v2/#/component/group" target="_blank">demo url</a>
            <a v-if="!demos.length" href="https://github.com/airyland/vux/blob/v2/src/demos/Group.vue" target="_blank" @click.prevent="showSourceCode">demo source code</a>
            <a href="https://github.com/airyland/vux/blob/v2/src/components/group/metas.yml" target="_blank">edit document</a>
            <a href="https://github.com/airyland/vux/blob/v2/src/components/group/" target="_blank">component source code</a>
            <el-popover trigger="hover" v-if="hasReady">
              <div style="width:100%;text-align:center;">
                <img class="qr" width="100" src="https://qr.vux.li/api.php?text=https%3A%2F%2Fvux.li%2Fdemos%2Fv2%2F%23%2Fcomponent%2Fgroup"/>
              </div>
              <a href="javascript:" slot="reference">
              view demos on mobile
              </a>
            </el-popover>
          </p>

          <div class="component-description">
            <template v-if="false">
            
            </template>
          </div>

        </div>

        <div v-if="!demos.length" class="component-demo" style="width:377px;height:600px;display:inline-block;border:1px solid #ececec;border-radius:5px;overflow:hidden;z-index:2500;">
          <iframe src="https://vux.li/demos/v2?locale=en&transition=none/#/component/group" width="375" height="600" border="0" frameborder="0"></iframe>
        </div>
        <div class="toc">
          <ul v-for="t in toc">
            <li>
              <a :href="'#' + (t.anchor || t.title)">{{ t.title }}</a>
              <ul v-if="t.list" v-for="_t in t.list">
                <li><a :href="'#' + _t.anchor">{{ _t.title.slice(0, 12) }}</a></li>
              </ul>
            </li>
          </ul>
        </div>
      
        <template v-if="needImport">
          <a class="anchor" id="install">Install</a>
          <h2>Install</h2>
          <el-tabs>
            <el-tab-pane label="Local Registration">
              <div class="import-code-box">
              <el-tooltip content="click to copy" placement="top">
                <span
                  v-clipboard:copy="localImportCode"
                  v-clipboard:success="onCopy"
                  v-clipboard:error="onCopyError">
                  <el-icon class="el-icon-document"></el-icon>
                </span>
              </el-tooltip>
              <pre class="hljs"><code><span class="hljs-keyword">import</span> { Group } <span class="hljs-keyword">from</span> <span class="hljs-string">'vux'</span>

<span class="hljs-keyword">export</span> <span class="hljs-keyword">default</span> {
  <span class="hljs-attr">components</span>: {
    Group
  }
}</code></pre>
            </div>
            </el-tab-pane>
            <el-tab-pane label="Global Registration">
              <div class="import-code-box">
                <el-tooltip content="click to copy" placement="top">
                  <span
                    v-clipboard:copy="globalImportCode"
                    v-clipboard:success="onCopy"
                    v-clipboard:error="onCopyError">
                    <el-icon class="el-icon-document"></el-icon>
                  </span>
                </el-tooltip>
                <pre class="hljs"><code><span class="hljs-comment">// you can also register globally</span>

<span class="hljs-keyword">import</span> Vue <span class="hljs-keyword">from</span> <span class="hljs-string">'vue'</span>
<span class="hljs-keyword">import</span> { Group } <span class="hljs-keyword">from</span> <span class="hljs-string">'vux'</span>

Vue.component(<span class="hljs-string">'group'</span>, Group)
</code></pre>
              </div> 
            </el-tab-pane>
          </el-tabs>   
        </template>

        <template v-else>
          <div class="tip">
            <p>You don't need to import this component.</p>
          </div>
        </template>

        <div class="tip" style="width:600px;" v-if="metas.tip">
          
        </div>
      
        <h2 v-if="metas.example">example</h2>
        <div v-if="metas.example" style="width:600px;">
          
        </div>
      </div>

      <div v-if="metas.extra && metas.extra['en']">
        <p><code>Group</code> is a special component for wrapping form elements</p>

      </div>
      <div v-if="metas.extra && !metas.extra['en']">
        
      </div>
      
      <a v-if="demos.length" class="anchor" id="examples">Examples</a>
      <br/>
      <template v-if="demos.length" v-for="demo in demos">
        <a class="anchor" :id="'examples:' + demo.title">{{ demo.title }}</a>
        <br/>
        <div class="demo-header">
          <span class="demo-title">{{ demo.title }}</span>
        </div>
        <div class="demos" :style="{height: demo.height}">
          <div class="demo-iframe-box">
            <lazy-component>
              <iframe
                :src="domain + '?no-background-color=' + demo.noBackgroundColor +'&locale=en&transition=none&hide-nav=true&hide-tab-bar=true#/components/' + demo.file"
                width="375"
                height="600"
                border="0"
                frameborder="0"
                style="margin: 0 auto;"></iframe>
            </lazy-component>
          </div>
          <div class="demo-code-box" :style="{overflow: demo.height === demo.oriHeight ? 'hidden' : 'scroll'}">
            <div v-html="demo.code" contenteditable></div>
            <div v-if="demo.height === demo.oriHeight" class="demo-code-masker" @click="demo.height='auto'">
              <div>
                  <img class="demo-qr" width="100" :src="'https://qr.vux.li/api.php?text=' + encodeURIComponent(domain + '?locale=en#/components/' + demo.file)"/>
                  <br/>
                  <span>
                    <el-icon class="el-icon-arrow-left"/>
                    <el-icon class="el-icon-arrow-right"/>
                    Show code
                  <br/>
                  <!--<span class="demo-path">src/demos/{{ demo.file }}.vue</span>-->
                </span>
              </div>
            </div>
            <span v-if="demo.height === 'auto'" class="hide-code" @click="demo.height=demo.oriHeight">
              <el-icon class="el-icon-close"></el-icon>
            </span>
          </div>
        </div>
      </template>

      <template v-for="component in componentList">
        <div>
          <a v-if="componentList.length > 1" class="anchor" :id="'components:' + component.name">{{ component.name }}</a>
          <a v-else class="anchor" id="api">API</a>
          <br/>
          <h2
            v-show="componentList.length > 1"
            class="vux-component-name-sub-item">{{ component.name }}</h2>
            
          <template v-if="component.meta.items && component.meta.description">
            <div v-html="component.meta.description"></div>
          </template>

          <template v-if="component.meta.props">
            <h2>Props</h2>
            <table>
              <thead>
                <tr>
                  <td>name</td>
                  <td style="width:48px;">type</td>
                  <td>default</td>
                  <td>description</td>
                  <td>required version</td>
                </tr>
              </thead>
              <tbody>
                <tr v-for="(prop, i) in component.meta.props">
                  <td class="prop-name">
                    <el-tooltip content="click to copy" placement="left" :hide-after="0" :open-delay="50">
                      <span
                      v-clipboard:copy="i"
                      v-clipboard:success="onCopy">{{ i }}</span>
                    </el-tooltip>
                  </td>
                  <td v-html="getTypeHTML(prop.type)"></td>
                  <td>{{ prop.default}}</td>
                  <td v-html="prop['en'].replace(/`(.*?)`/g, '<code>$1</code>')"></td>
                  <td>{{ prop.version || '--'}}</td>
                </tr>
              </tbody>
            </table>
          </template>

          <template v-if="component.meta.events">
            <h2>Events</h2>
            <table>
              <thead>
                <tr>
                  <td>name</td>
                  <td>params</td>
                  <td>description</td>
                  <td>required version</td>
                </tr>
              </thead>
              <tbody>
                <tr v-for="(event, i) in component.meta.events">
                  <td class="prop-name">
                    <el-tooltip content="click to copy" placement="left" :hide-after="0" :open-delay="50">
                      <span
                      v-clipboard:copy="'@' + i"
                      v-clipboard:success="onCopy">@{{ i }}</span>
                    </el-tooltip>
                  </td>
                  <td v-html="event.params ? event.params.replace(/`(.*?)`/g, '<code>$1</code>') : '--'"></td>
                  <td v-html="event['en'] ? event['en'].replace(/`(.*?)`/g, '<code>$1</code>') : '--'"></td>
                  <td>{{ event['version'] || '--' }}</td>
                </tr>
              </tbody>
            </table>
          </template>
      

          <template v-if="component.meta.slots">
            <h2>Slots</h2>
            <table>
              <thead>
                <tr>
                  <td>name</td>
                  <td>description</td>
                  <td>required version</td>
                </tr>
              </thead>
              <tbody>
                <tr v-for="(slot, i) in component.meta.slots" :class="{'slot-disabled': slot['status'] === 'deprecated'}">
                  <td class="prop-name">
                    <el-tooltip content="click to copy" placement="left" :hide-after="0" :open-delay="50">
                      <span
                      v-clipboard:copy="i"
                      v-clipboard:success="onCopy">{{ i === 'default' ? 'default' : i }}</span>
                    </el-tooltip>
                  </td>
                  <td v-html="slot['en'] ? slot['en'].replace(/`(.*?)`/g, '<code>$1</code>') : ''"></td>
                  <td>{{ slot['version'] || '--' }}</td>
                </tr>
              </tbody>
            </table>
          </template>
          
          <template v-if="component.meta.methods">
            <h2>Functions</h2>
            <table>
              <thead>
                <tr>
                  <td>name</td>
                  <td>params</td>
                  <td>description</td>
                  <td>required version</td>
                </tr>
              </thead>
              <tbody>
                <tr v-for="(method, i) in component.meta.methods">
                  <td class="prop-name">
                    <el-tooltip content="click to copy" placement="left" :hide-after="0" :open-delay="50">
                      <span
                      v-clipboard:copy="i"
                      v-clipboard:success="onCopy">{{ i }}</span>
                    </el-tooltip>
                  </td>
                  <td v-html="method['params'] ? method['params'].replace(/`(.*?)`/g, '<code>$1</code>') : ''"></td>
                  <td v-html="method['en'].replace(/`(.*?)`/g, '<code>$1</code>')"></td>
                  <td>{{ method['version'] }}</td>
                </tr>
              </tbody>
            </table>
          </template>

          <template v-if="component.meta.variables">
            <a class="anchor" id="variables">Variables</a>
            <br/>
            <h2>Variables</h2>
            <table>
              <thead>
                <tr>
                  <td>name</td>
                  <td>default</td>
                  <td>description</td>
                  <td>inherited name</td>
                </tr>
              </thead>
              <tbody>
                <tr v-for="(variable, i) in component.meta.variables">
                  <td class="prop-name">
                    <el-tooltip content="click to copy" placement="left" :hide-after="0" :open-delay="50">
                      <span
                      v-clipboard:copy="'@' + variable.name"
                      v-clipboard:success="onCopy">@{{ variable.name }}</span>
                    </el-tooltip>
                  </td>
                  <td>
                    <em
                      :ref="'propColor' + i"
                      v-if="!$refs['propColor' + i] || ($refs['propColor' + i][0] && $refs['propColor' + i][0].style.backgroundColor)"
                      class="prop-color"
                      :style="{ backgroundColor: variable.value }">
                    </em>
                    {{ variable.value }}
                  </td>
                  <td>{{ variable['desc']['en'] || '--' }}</td>
                  <td>{{ variable.inherited_name }}</td>
                </tr>
              </tbody>
            </table>
          </template>
      
          <template v-if="component.meta.tips && component.meta.tips['en']">
            <a class="anchor" id="tips">Tips</a>
            <br>
            <h2>Tips</h2>
            <div>
              <ul>
                <li v-for="tip in component.meta.tips['en']">
                <el-tag size="mini" type="success" class="component-tip-tag">Q</el-tag> <span class="component-tip-question">{{ tip.q }}</span>
                <div v-html="tip.a" class="tip-answer-box"></div>
                </li>
              </ul>
            </div>
          </template>
        </div>
      </template>

      <!--<h2>社区相关讨论</h2>
      [即将上线]
      -->
    
      <br>
      <div v-if="issues.length">
        <a class="anchor" id="Issues">Issues</a>
        <br/>
        <h2>Related issues</h2>
        <ul>
          <li v-for="issue in issues"><a target="_blank" :href="issue.html_url">#{{ issue.number}} <span style="color:#666;">{{ issue.title }}</span></a></li>
        </ul>
      </div>
      <br>
    
      <div v-if="gitMetas">
        <a class="anchor" id="contributors">Contributors</a>
        <h2>Contributors</h2>
        <p>Total commits quantity: {{ gitMetas.commitCount }}，Total contributors quantity: {{gitMetas.commitUniqueCount}}
        </p>
        <a v-for="person in gitMetas.commitMembers" class="contributor-item" :href="'https://github.com/' + person.authorName" target="_blank" :title="'contribute' + person.count">{{person.authorName}}</a>
      </div>
      <br>

      <div v-if="metas.changes">
        <a class="anchor" id="changelog">Changelog</a>
        <br/>
        <h2>Releases</h2>
        <ul v-if="metas.changes">
          <template v-for="(changelog, version) in metas.changes">
            <li v-for="log in changelog['en']">
              <router-link :to="'/en/changelog/' + version + '.html'" class="changelog-version">{{version}}</router-link> {{log}}
            </li>
          </template>
        </ul>
      </div>

      <h2 v-if="metas.references">Referrences</h2>
      <ul v-if="metas.references">
        <li v-for="link in metas.references['en']">
          <a :href="link.link" target="_blank">{{link.title}}</a>
        </li>
      </ul>

      <el-dialog
        class="sourcec-code-dialog"
        top="0"
        width="80%"
        :visible.sync="sourceCodeDialogVisibility">
        <div class="code-box" contenteditable v-html="demoCode"></div>
      </el-dialog>

    </div>
  </template>


  <script>
  import Axios from 'axios'

  // const metas = require('json-loader!yaml-loader!../../../src/components/group/metas.yml')
  const metas = {
  "category": {
    "en": "Form",
    "zh-CN": "表单"
  },
  "icon": "&#xe62a;",
  "tags": {
    "en": [
      "form",
      "group"
    ],
    "zh-CN": [
      "表单",
      "分组"
    ]
  },
  "extra": {
    "en": "`Group` is a special component for wrapping form elements",
    "zh-CN": "`Group`是一个特殊的表单`wrapper`组件，主要用于将表单分组，单个表单元素也算一组。常见的表单组件都`必须`作为`Group`的子组件。 属于`Group`子组件的有：Cell, XInput, XTextarea, XSwitch, Calendar, XNumber, Radio, XAddress, Datetime, Selector\n"
  },
  "props": {
    "title": {
      "type": "String",
      "default": "",
      "en": "group title",
      "zh-CN": "分组标题"
    },
    "title-color": {
      "type": "String",
      "default": "",
      "en": "group title's color",
      "zh-CN": "分组标题文字颜色"
    },
    "label-width": {
      "type": "String",
      "default": "",
      "en": "common label width for child components",
      "zh-CN": "为子元素设定统一label宽度"
    },
    "label-align": {
      "type": "String",
      "default": "",
      "en": "common label text-align for child components",
      "zh-CN": "为子元素设定统一对齐方式"
    },
    "label-margin-right": {
      "type": "String",
      "default": "",
      "en": "common margin right value for child components",
      "zh-CN": "为子元素设定统一的右边margin"
    },
    "gutter": {
      "type": "String",
      "default": "",
      "en": "set the marginTop value when there is no title",
      "zh-CN": "设定group的上边距，只能用于没有标题时"
    }
  },
  "slots": {
    "default": {
      "en": "content body for child components",
      "zh-CN": "子组件插槽"
    },
    "title": {
      "version": "v2.5.1",
      "en": "title slot",
      "zh-CN": "标题插槽"
    }
  },
  "changes": {
    "v2.5.4": {
      "en": [
        "[enhance] XSwitch：labelAlign support justify #1707"
      ],
      "zh-CN": [
        "[enhance] XSwitch的labelAlign 支持 justify #1707"
      ]
    },
    "v2.5.3": {
      "en": [
        "[enhance] prop:labelAlign support justify #1574"
      ],
      "zh-CN": [
        "[enhance] labelAlign 支持 justify #1574"
      ]
    },
    "v2.5.1": {
      "en": [
        "[feature] Add slot:title #1650"
      ],
      "zh-CN": [
        "[feature] 添加 slot:title #1650"
      ]
    },
    "v2.3.2": {
      "en": [
        "[feature] prop:gutter could be a number"
      ],
      "zh-CN": [
        "[feature] gutter 属性允许为数字类型"
      ]
    },
    "v2.1.1-rc.2": {
      "en": [
        "[feature] Support title margin-top variable"
      ],
      "zh-CN": [
        "[feature] 支持 margin-top 等 less 变量"
      ]
    }
  },
  "variables": [
    {
      "name": "group-title-margin-top",
      "value": ".77em",
      "is_inherited": false,
      "inherited_name": "",
      "desc": {
        "zh-CN": "标题的margin-top",
        "en": "margin-top of title"
      }
    },
    {
      "name": "group-title-margin-bottom",
      "value": ".3em",
      "is_inherited": false,
      "inherited_name": "",
      "desc": {
        "zh-CN": "标题的margin-bottom",
        "en": "margin-bottom of title"
      }
    },
    {
      "name": "group-footer-title-margin-top",
      "value": ".3em",
      "is_inherited": false,
      "inherited_name": "",
      "desc": {
        "zh-CN": "底部标题的margin-top",
        "en": "margin-top of footer title"
      }
    },
    {
      "name": "group-footer-title-margin-bottom",
      "value": ".77em",
      "is_inherited": false,
      "inherited_name": "",
      "desc": {
        "zh-CN": "底部标题的margin-bottom",
        "en": "margin-bottom of footer title"
      }
    }
  ]
}
  const demos = []

  let componentList = []
  if (Array.isArray(metas.items)) {
    try {
      metas.items.forEach((item, index) => {
        const meta = {
          name: item,
          meta: metas[item]
        }
        if (meta.meta.props === null) {
          delete meta.meta.props
        }
        if (index === metas.items.length - 1) {
          if (meta.meta) {
            meta.meta.variables = metas.variables
          }
        }
        componentList.push(meta)
      })
    } catch (e) {
      console.log(e)
    }
  } else {
    componentList.push({
      meta: metas
    })
  }
  const gitMetas = require('./group_git_metas.json')
  const demoCode = decodeURIComponent(`%3Cpre%20class%3D%22hljs%22%3E%3Ccode%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Etemplate%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ediv%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Egroup%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Elabel-width%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%224.5em%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Elabel-margin-right%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%222em%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Elabel-align%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22right%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ecell%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Etitle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22Cell%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Evalue%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22value%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Eis-link%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ecell%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ecell%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Etitle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22Cell%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Evalue%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22value%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Eis-link%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Evalue-align%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22left%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ecell%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ex-input%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Etitle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22%E4%B8%8A%E6%8A%A5%E4%BA%BA%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Ev-model%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22value1%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ex-input%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ex-input%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Eplaceholder%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22I'm%20placeholder%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Eimg%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Eslot%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22restricted-label%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Estyle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22display%3Ainline-block%3Bvertical-align%3Amiddle%3B%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Esrc%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22http%3A%2F%2Fdn-placeholder.qbox.me%2F110x110%2FFF2D55%2F000%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Ewidth%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%2224%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Eheight%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%2224%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ex-input%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ex-input%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Etitle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22%E4%B8%8A%26lt%3Bi%20class%3D'vux-blank-half'%26gt%3B%26lt%3B%2Fi%26gt%3B%E6%8A%A5%26lt%3Bi%20class%3D'vux-blank-half'%26gt%3B%26lt%3B%2Fi%26gt%3B%E4%BA%BA%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Ev-model%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22value1%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ex-input%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ex-number%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Etitle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22Quantity%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Ealign%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22left%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Ev-model%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22numberValue%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Ebutton-style%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22round%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Amin%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%220%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Amax%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%225%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ex-number%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Edatetime%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Etitle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22%E6%97%B6%26amp%3Bemsp%3B%26amp%3Bemsp%3B%26amp%3Bnbsp%3B%E9%97%B4%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Ev-model%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22time1%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Evalue-text-align%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22left%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Edatetime%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Eselector%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Etitle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22%E9%9A%90%E6%82%A3%E7%B1%BB%E5%88%AB%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Aoptions%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22%5B'%E5%B7%A5%E8%89%BA%E6%8A%80%E6%9C%AF'%2C%20'%E5%85%B6%E4%BB%96'%5D%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Ev-model%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22value2%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Eselector%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Eselector%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Etitle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22%E9%9A%90%E6%82%A3%E7%B1%BB%E5%88%AB%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Eplaceholder%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22Placeholder%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Aoptions%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22%5B'%E5%B7%A5%E8%89%BA%E6%8A%80%E6%9C%AF'%2C%20'%E5%85%B6%E4%BB%96'%5D%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Ev-model%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22value7%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Eselector%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Eselector%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Etitle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22%E9%9A%90%E6%82%A3%E7%B1%BB%E5%88%AB%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Aoptions%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22%5B'%E5%B7%A5%E8%89%BA%E6%8A%80%E6%9C%AF'%2C%20'%E5%85%B6%E4%BB%96'%5D%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Ev-model%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22value8%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Eselector%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ex-input%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Etitle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22%E9%9A%90%E6%82%A3%E9%83%A8%E4%BD%8D%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Eplaceholder%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22%E5%BF%85%E5%A1%AB%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Ev-model%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22value3%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ex-input%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ex-input%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Etitle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22%E5%AF%86%E7%A0%81%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Etype%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22password%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Eplaceholder%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22%E5%BF%85%E5%A1%AB%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Ev-model%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22value4%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ex-input%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Epopup-picker%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Etitle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22%E8%AF%B7%E9%80%89%E6%8B%A9%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Adata%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22list%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Ev-model%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22value5%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Evalue-text-align%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22left%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Epopup-picker%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Epopup-picker%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Etitle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22%E8%AF%B7%E9%80%89%E6%8B%A9%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Eplaceholder%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22Required%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Adata%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22list%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Ev-model%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22value6%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Evalue-text-align%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22left%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Epopup-picker%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ex-address%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Etitle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22%E5%9C%B0%E5%9D%80%E9%80%89%E6%8B%A9%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Ev-model%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22addressValue%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Eraw-value%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Alist%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22addressData%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Evalue-text-align%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22left%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ex-address%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ex-textarea%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Etitle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22%E8%AF%A6%E7%BB%86%E4%BF%A1%E6%81%AF%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Eplaceholder%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22%E8%AF%B7%E5%A1%AB%E5%86%99%E8%AF%A6%E7%BB%86%E4%BF%A1%E6%81%AF%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Ashow-counter%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22false%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Arows%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%223%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ex-textarea%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ex-textarea%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Eplaceholder%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22%E8%AF%B7%E5%A1%AB%E5%86%99%E8%AF%A6%E7%BB%86%E4%BF%A1%E6%81%AF%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Ashow-counter%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22false%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Arows%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%223%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Eimg%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Eslot%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22restricted-label%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Estyle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22display%3Ainline-block%3Bvertical-align%3Amiddle%3B%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Esrc%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22http%3A%2F%2Fdn-placeholder.qbox.me%2F110x110%2FFF2D55%2F000%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Ewidth%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%2224%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Eheight%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%2224%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ex-textarea%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Egroup%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ebr%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Egroup%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Egroup-title%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Eslot%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22title%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3EI'm%20a%20title%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Espan%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Estyle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22float%3Aright%3B%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3Eright%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Espan%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Egroup-title%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ecell%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Etitle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22cell%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ecell%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Egroup%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ebr%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Egroup%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Etitle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22justify%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Elabel-width%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%225.5em%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Elabel-margin-right%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%222em%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Elabel-align%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22justify%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ecell%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Etitle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22%E5%93%88%E5%93%88%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Evalue%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22value%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Eis-link%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ecell%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ecell%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Etitle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22%E5%93%88%E5%93%88%E5%93%88%E5%93%88%E5%93%88%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Evalue%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22value%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Eis-link%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Evalue-align%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22left%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ecell%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ex-input%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Etitle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22%E4%B8%8A%E6%8A%A5%E4%BA%BA%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Ev-model%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22value1%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ex-input%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ex-number%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Etitle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22Quantity%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Ealign%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22left%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Ev-model%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22numberValue%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Ebutton-style%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22round%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Amin%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%220%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Amax%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%225%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ex-number%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Edatetime%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Etitle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22%E6%97%B6%E9%97%B4%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Ev-model%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22time1%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Evalue-text-align%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22left%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Edatetime%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Eselector%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Etitle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22%E9%9A%90%E6%82%A3%E7%B1%BB%E5%88%AB%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Aoptions%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22%5B'%E5%B7%A5%E8%89%BA%E6%8A%80%E6%9C%AF'%2C%20'%E5%85%B6%E4%BB%96'%5D%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Ev-model%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22value2%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Eselector%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Epopup-picker%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Etitle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22%E8%AF%B7%E9%80%89%E6%8B%A9%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Adata%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22list%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Ev-model%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22value5%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Evalue-text-align%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22left%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Epopup-picker%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ex-address%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Etitle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22%E5%9C%B0%E5%9D%80%E9%80%89%E6%8B%A9%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Ev-model%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22addressValue%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Eraw-value%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Alist%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22addressData%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Evalue-text-align%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22left%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Elabel-align%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22justify%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ex-address%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ex-switch%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Etitle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22%E9%80%89%E6%8B%A9%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ex-switch%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ex-textarea%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Etitle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22%E8%AF%A6%E7%BB%86%E4%BF%A1%E6%81%AF%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Eplaceholder%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22%E8%AF%B7%E5%A1%AB%E5%86%99%E8%AF%A6%E7%BB%86%E4%BF%A1%E6%81%AF%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Ashow-counter%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22false%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Arows%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%223%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ex-textarea%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Egroup%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ebr%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ediv%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Etemplate%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%0A%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Escript%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22javascript%22%3E%0A%20%20%3Cspan%20class%3D%22hljs-keyword%22%3Eimport%3C%2Fspan%3E%20%7B%20GroupTitle%2C%20Group%2C%20Cell%2C%20XInput%2C%20Selector%2C%20PopupPicker%2C%20Datetime%2C%20XNumber%2C%20ChinaAddressData%2C%20XAddress%2C%20XTextarea%2C%20XSwitch%20%7D%20%3Cspan%20class%3D%22hljs-keyword%22%3Efrom%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-string%22%3E'vux'%3C%2Fspan%3E%0A%0A%20%20%3Cspan%20class%3D%22hljs-keyword%22%3Eexport%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-keyword%22%3Edefault%3C%2Fspan%3E%20%7B%0A%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3Ecomponents%3C%2Fspan%3E%3A%20%7B%0A%20%20%20%20%20%20Group%2C%0A%20%20%20%20%20%20GroupTitle%2C%0A%20%20%20%20%20%20Cell%2C%0A%20%20%20%20%20%20XInput%2C%0A%20%20%20%20%20%20Selector%2C%0A%20%20%20%20%20%20PopupPicker%2C%0A%20%20%20%20%20%20XAddress%2C%0A%20%20%20%20%20%20Datetime%2C%0A%20%20%20%20%20%20XNumber%2C%0A%20%20%20%20%20%20XTextarea%2C%0A%20%20%20%20%20%20XSwitch%0A%20%20%20%20%7D%2C%0A%20%20%20%20data%20()%20%7B%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-keyword%22%3Ereturn%3C%2Fspan%3E%20%7B%0A%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3EaddressData%3C%2Fspan%3E%3A%20ChinaAddressData%2C%0A%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3EaddressValue%3C%2Fspan%3E%3A%20%5B%3Cspan%20class%3D%22hljs-string%22%3E'%E5%B9%BF%E4%B8%9C%E7%9C%81'%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-string%22%3E'%E6%B7%B1%E5%9C%B3%E5%B8%82'%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-string%22%3E'%E5%8D%97%E5%B1%B1%E5%8C%BA'%3C%2Fspan%3E%5D%2C%0A%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3Evalue1%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-string%22%3E'%E5%BC%A0%E4%B8%89'%3C%2Fspan%3E%2C%0A%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3Evalue2%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-string%22%3E'%E5%B7%A5%E8%89%BA%E6%8A%80%E6%9C%AF'%3C%2Fspan%3E%2C%0A%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3Evalue3%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-string%22%3E''%3C%2Fspan%3E%2C%0A%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3Evalue7%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-string%22%3E''%3C%2Fspan%3E%2C%0A%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3Evalue8%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-string%22%3E''%3C%2Fspan%3E%2C%0A%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3Evalue4%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-string%22%3E''%3C%2Fspan%3E%2C%0A%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3Etime1%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-string%22%3E'2017-06-01'%3C%2Fspan%3E%2C%0A%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3Evalue5%3C%2Fspan%3E%3A%20%5B%3Cspan%20class%3D%22hljs-string%22%3E'A'%3C%2Fspan%3E%5D%2C%0A%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3Evalue6%3C%2Fspan%3E%3A%20%5B%5D%2C%0A%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3Elist%3C%2Fspan%3E%3A%20%5B%5B%3Cspan%20class%3D%22hljs-string%22%3E'A'%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-string%22%3E'B'%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-string%22%3E'C'%3C%2Fspan%3E%5D%5D%2C%0A%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3EnumberValue%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-number%22%3E0%3C%2Fspan%3E%0A%20%20%20%20%20%20%7D%0A%20%20%20%20%7D%0A%20%20%7D%0A%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Escript%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%3C%2Fcode%3E%3C%2Fpre%3E`)

  const domainMap = {
    'development': 'http://localhost:8080/',
    'production': 'https://vux.li/demos/v2/'
  }

  export default {
    head: {
      title: 'Group component tutorial | VUX - Vue.js Mobile UI Component Framework',
      meta: [{
        name: 'description',
        content: 'Vue component group for the VUX framework.'
      }, {
        name: 'keywords',
        content: 'group, vue-group, vux-group, vue mobile components'
      }, {
        property: 'og:title',
        content: 'Group component tutorial | VUX - Vue.js Mobile UI Component Framework'
      }, {
        property: 'og:description',
        content: 'Vue component group for the VUX framework.'
      }],
      // https://support.google.com/webmasters/answer/189077?hl=en
      link: [{"rel":"alternate","hreflang":"zh-CN","href":"/zh-CN/components/group.html"}],
      script: [
        {
          innerHTML:'{"@context":"http://schema.org/","@type":"SoftwareApplication","name":"Vue Component group","screenshot":"","description":"Vue.js component for VUX","url":"/en/components/group.html","applicationCategory":"Component","author":{"@type":"Organization","name":"VUX","url":"https://vux.li"},"downloadUrl":"https://vux.li","softwareVersion":"2.9.2","aggregateRating":{"@type":"AggregateRating","ratingValue":5,"reviewCount":19},"operatingSystem":"iOS >= 7, Android >= 4.1","offers":{"@type":"Offer","price":0,"priceCurrency":"USD","availability":"http://schema.org/InStock"}}',
          type: 'application/ld+json'
        }
      ],
      __dangerouslyDisableSanitizers: ['script']
    },
    filters: {
      parseCode (str) {
        return str.replace(/`(.*?)`/g, '<code>$1</code>')
      }
    },
    async mounted () {
      const rs = await Axios.get('https://api.github.com/search/issues?q=repo:airyland/vux%20label:component/' + this.componentName)
      this.issues = rs.data.items
      this.hasReady = true
    },
    watch: {
      async sourceCodeDialogVisibility (val) {
        if (val) {
          await this.$nextTick()
          const mask = document.querySelector('.v-modal')
          mask && mask.addEventListener('click', () => {
            this.sourceCodeDialogVisibility = false
          })
        }
      }
    },
    methods: {
      onCopyError () {
        this.$message({
          type: 'error',
          message: 'copy fail!'
        })
      },
      onCopy () {
        this.$message({
          type: 'success',
          message: 'copy done!'
        })
      },
      showSourceCode () {
        this.sourceCodeDialogVisibility = true
      },
      getTypeHTML (type) {
        type = type || 'String'
        if (/,/.test(type)) {
          const list = type.split(',').map(function (one) {
            return one.replace(/^s+|s+$/g, '')
          }).map(function (one) {
            const type = one ?  one.toLowerCase() : 'string'
            return '<span class="type">' + type + '</span>'
          })
          return list.join('<br>')
        } else {
          type = type ?  type.toLowerCase() : 'string'
          return '<span class="type">' + type + '</span>'
        }
      }
    },
    computed: {
      lang () {
        if (this.$route.path.indexOf('/en/') !== -1) {
          return 'en'
        }
        if (this.$route.path.indexOf('/zh-CN/') !== -1) {
          return 'zh-CN'
        }
        return 'en'
      }
    },
    data () {
      return {
        demos,
        isBeta: false,
        hasReady: false,
        issues: [],
        componentName: 'group',
        demoCode,
        sourceCodeDialogVisibility: false,
        showQr: false,
        metas: metas,
        gitMetas,
        componentList,
        localImportCode: `import { Group } from 'vux'

export default {
  components: {
    Group
  }
}`,
        globalImportCode: `// you can also register globally

import Vue from 'vue'
import { Group } from 'vux'

Vue.component('group', Group)
`,
        needImport: true,
        toc: [],
        domain: domainMap[process.env.NODE_ENV]
      }
    }
  }
  </script>

  <style>
  .component-box {
    position: relative;
  }
  .component-demo {
    position: absolute;
    right: 5px;
    top: 15px;
  }
  .prop-color {
    display: inline-block;
    width: 10px;
    height: 10px;
    border: 1px solid #aaa;
  }
  .changelog-version {
    width: 110px;
    display: inline-block;
  }
  .component-extra-links {
    position: relative;
    font-size: 12px;
  }
  .component-extra-links a {
    padding-right: 10px;
    color: #999;
  }
  </style>
    