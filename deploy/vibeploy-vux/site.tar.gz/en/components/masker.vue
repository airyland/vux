
  <template>
    <div class="component-box" :class="demos.length ? 'components-with-toc' : ''">

      <div :class="demos.length ? 'component-header-v2' : 'component-header-v1'">
        <a class="anchor" id="intro">Masker</a>
        <div class="title-box">

          <el-badge value="Beta" v-if="isBeta">
            <h1 class="vux-component-name">Masker</h1>
          </el-badge>
          <h1 v-else class="vux-component-name">Masker</h1>

          <p class="component-extra-links">
            <a href="https://vux.li/demos/v2/#/component/masker" target="_blank">demo url</a>
            <a v-if="!demos.length" href="https://github.com/airyland/vux/blob/v2/src/demos/Masker.vue" target="_blank" @click.prevent="showSourceCode">demo source code</a>
            <a href="https://github.com/airyland/vux/blob/v2/src/components/masker/metas.yml" target="_blank">edit document</a>
            <a href="https://github.com/airyland/vux/blob/v2/src/components/masker/" target="_blank">component source code</a>
            <el-popover trigger="hover" v-if="hasReady">
              <div style="width:100%;text-align:center;">
                <img class="qr" width="100" src="https://qr.vux.li/api.php?text=https%3A%2F%2Fvux.li%2Fdemos%2Fv2%2F%23%2Fcomponent%2Fmasker"/>
              </div>
              <a href="javascript:" slot="reference">
              view demos on mobile
              </a>
            </el-popover>
          </p>

          <div class="component-description">
            <template v-if="false">
            
            </template>
          </div>

        </div>

        <div v-if="!demos.length" class="component-demo" style="width:377px;height:600px;display:inline-block;border:1px solid #ececec;border-radius:5px;overflow:hidden;z-index:2500;">
          <iframe src="https://vux.li/demos/v2?locale=en&transition=none/#/component/masker" width="375" height="600" border="0" frameborder="0"></iframe>
        </div>
        <div class="toc">
          <ul v-for="t in toc">
            <li>
              <a :href="'#' + (t.anchor || t.title)">{{ t.title }}</a>
              <ul v-if="t.list" v-for="_t in t.list">
                <li><a :href="'#' + _t.anchor">{{ _t.title.slice(0, 12) }}</a></li>
              </ul>
            </li>
          </ul>
        </div>
      
        <template v-if="needImport">
          <a class="anchor" id="install">Install</a>
          <h2>Install</h2>
          <el-tabs>
            <el-tab-pane label="Local Registration">
              <div class="import-code-box">
              <el-tooltip content="click to copy" placement="top">
                <span
                  v-clipboard:copy="localImportCode"
                  v-clipboard:success="onCopy"
                  v-clipboard:error="onCopyError">
                  <el-icon class="el-icon-document"></el-icon>
                </span>
              </el-tooltip>
              <pre class="hljs"><code><span class="hljs-keyword">import</span> { Masker } <span class="hljs-keyword">from</span> <span class="hljs-string">'vux'</span>

<span class="hljs-keyword">export</span> <span class="hljs-keyword">default</span> {
  <span class="hljs-attr">components</span>: {
    Masker
  }
}</code></pre>
            </div>
            </el-tab-pane>
            <el-tab-pane label="Global Registration">
              <div class="import-code-box">
                <el-tooltip content="click to copy" placement="top">
                  <span
                    v-clipboard:copy="globalImportCode"
                    v-clipboard:success="onCopy"
                    v-clipboard:error="onCopyError">
                    <el-icon class="el-icon-document"></el-icon>
                  </span>
                </el-tooltip>
                <pre class="hljs"><code><span class="hljs-comment">// you can also register globally</span>

<span class="hljs-keyword">import</span> Vue <span class="hljs-keyword">from</span> <span class="hljs-string">'vue'</span>
<span class="hljs-keyword">import</span> { Masker } <span class="hljs-keyword">from</span> <span class="hljs-string">'vux'</span>

Vue.component(<span class="hljs-string">'masker'</span>, Masker)
</code></pre>
              </div> 
            </el-tab-pane>
          </el-tabs>   
        </template>

        <template v-else>
          <div class="tip">
            <p>You don't need to import this component.</p>
          </div>
        </template>

        <div class="tip" style="width:600px;" v-if="metas.tip">
          
        </div>
      
        <h2 v-if="metas.example">example</h2>
        <div v-if="metas.example" style="width:600px;">
          
        </div>
      </div>

      <div v-if="metas.extra && metas.extra['en']">
        
      </div>
      <div v-if="metas.extra && !metas.extra['en']">
        
      </div>
      
      <a v-if="demos.length" class="anchor" id="examples">Examples</a>
      <br/>
      <template v-if="demos.length" v-for="demo in demos">
        <a class="anchor" :id="'examples:' + demo.title">{{ demo.title }}</a>
        <br/>
        <div class="demo-header">
          <span class="demo-title">{{ demo.title }}</span>
        </div>
        <div class="demos" :style="{height: demo.height}">
          <div class="demo-iframe-box">
            <lazy-component>
              <iframe
                :src="domain + '?no-background-color=' + demo.noBackgroundColor +'&locale=en&transition=none&hide-nav=true&hide-tab-bar=true#/components/' + demo.file"
                width="375"
                height="600"
                border="0"
                frameborder="0"
                style="margin: 0 auto;"></iframe>
            </lazy-component>
          </div>
          <div class="demo-code-box" :style="{overflow: demo.height === demo.oriHeight ? 'hidden' : 'scroll'}">
            <div v-html="demo.code" contenteditable></div>
            <div v-if="demo.height === demo.oriHeight" class="demo-code-masker" @click="demo.height='auto'">
              <div>
                  <img class="demo-qr" width="100" :src="'https://qr.vux.li/api.php?text=' + encodeURIComponent(domain + '?locale=en#/components/' + demo.file)"/>
                  <br/>
                  <span>
                    <el-icon class="el-icon-arrow-left"/>
                    <el-icon class="el-icon-arrow-right"/>
                    Show code
                  <br/>
                  <!--<span class="demo-path">src/demos/{{ demo.file }}.vue</span>-->
                </span>
              </div>
            </div>
            <span v-if="demo.height === 'auto'" class="hide-code" @click="demo.height=demo.oriHeight">
              <el-icon class="el-icon-close"></el-icon>
            </span>
          </div>
        </div>
      </template>

      <template v-for="component in componentList">
        <div>
          <a v-if="componentList.length > 1" class="anchor" :id="'components:' + component.name">{{ component.name }}</a>
          <a v-else class="anchor" id="api">API</a>
          <br/>
          <h2
            v-show="componentList.length > 1"
            class="vux-component-name-sub-item">{{ component.name }}</h2>
            
          <template v-if="component.meta.items && component.meta.description">
            <div v-html="component.meta.description"></div>
          </template>

          <template v-if="component.meta.props">
            <h2>Props</h2>
            <table>
              <thead>
                <tr>
                  <td>name</td>
                  <td style="width:48px;">type</td>
                  <td>default</td>
                  <td>description</td>
                  <td>required version</td>
                </tr>
              </thead>
              <tbody>
                <tr v-for="(prop, i) in component.meta.props">
                  <td class="prop-name">
                    <el-tooltip content="click to copy" placement="left" :hide-after="0" :open-delay="50">
                      <span
                      v-clipboard:copy="i"
                      v-clipboard:success="onCopy">{{ i }}</span>
                    </el-tooltip>
                  </td>
                  <td v-html="getTypeHTML(prop.type)"></td>
                  <td>{{ prop.default}}</td>
                  <td v-html="prop['en'].replace(/`(.*?)`/g, '<code>$1</code>')"></td>
                  <td>{{ prop.version || '--'}}</td>
                </tr>
              </tbody>
            </table>
          </template>

          <template v-if="component.meta.events">
            <h2>Events</h2>
            <table>
              <thead>
                <tr>
                  <td>name</td>
                  <td>params</td>
                  <td>description</td>
                  <td>required version</td>
                </tr>
              </thead>
              <tbody>
                <tr v-for="(event, i) in component.meta.events">
                  <td class="prop-name">
                    <el-tooltip content="click to copy" placement="left" :hide-after="0" :open-delay="50">
                      <span
                      v-clipboard:copy="'@' + i"
                      v-clipboard:success="onCopy">@{{ i }}</span>
                    </el-tooltip>
                  </td>
                  <td v-html="event.params ? event.params.replace(/`(.*?)`/g, '<code>$1</code>') : '--'"></td>
                  <td v-html="event['en'] ? event['en'].replace(/`(.*?)`/g, '<code>$1</code>') : '--'"></td>
                  <td>{{ event['version'] || '--' }}</td>
                </tr>
              </tbody>
            </table>
          </template>
      

          <template v-if="component.meta.slots">
            <h2>Slots</h2>
            <table>
              <thead>
                <tr>
                  <td>name</td>
                  <td>description</td>
                  <td>required version</td>
                </tr>
              </thead>
              <tbody>
                <tr v-for="(slot, i) in component.meta.slots" :class="{'slot-disabled': slot['status'] === 'deprecated'}">
                  <td class="prop-name">
                    <el-tooltip content="click to copy" placement="left" :hide-after="0" :open-delay="50">
                      <span
                      v-clipboard:copy="i"
                      v-clipboard:success="onCopy">{{ i === 'default' ? 'default' : i }}</span>
                    </el-tooltip>
                  </td>
                  <td v-html="slot['en'] ? slot['en'].replace(/`(.*?)`/g, '<code>$1</code>') : ''"></td>
                  <td>{{ slot['version'] || '--' }}</td>
                </tr>
              </tbody>
            </table>
          </template>
          
          <template v-if="component.meta.methods">
            <h2>Functions</h2>
            <table>
              <thead>
                <tr>
                  <td>name</td>
                  <td>params</td>
                  <td>description</td>
                  <td>required version</td>
                </tr>
              </thead>
              <tbody>
                <tr v-for="(method, i) in component.meta.methods">
                  <td class="prop-name">
                    <el-tooltip content="click to copy" placement="left" :hide-after="0" :open-delay="50">
                      <span
                      v-clipboard:copy="i"
                      v-clipboard:success="onCopy">{{ i }}</span>
                    </el-tooltip>
                  </td>
                  <td v-html="method['params'] ? method['params'].replace(/`(.*?)`/g, '<code>$1</code>') : ''"></td>
                  <td v-html="method['en'].replace(/`(.*?)`/g, '<code>$1</code>')"></td>
                  <td>{{ method['version'] }}</td>
                </tr>
              </tbody>
            </table>
          </template>

          <template v-if="component.meta.variables">
            <a class="anchor" id="variables">Variables</a>
            <br/>
            <h2>Variables</h2>
            <table>
              <thead>
                <tr>
                  <td>name</td>
                  <td>default</td>
                  <td>description</td>
                  <td>inherited name</td>
                </tr>
              </thead>
              <tbody>
                <tr v-for="(variable, i) in component.meta.variables">
                  <td class="prop-name">
                    <el-tooltip content="click to copy" placement="left" :hide-after="0" :open-delay="50">
                      <span
                      v-clipboard:copy="'@' + variable.name"
                      v-clipboard:success="onCopy">@{{ variable.name }}</span>
                    </el-tooltip>
                  </td>
                  <td>
                    <em
                      :ref="'propColor' + i"
                      v-if="!$refs['propColor' + i] || ($refs['propColor' + i][0] && $refs['propColor' + i][0].style.backgroundColor)"
                      class="prop-color"
                      :style="{ backgroundColor: variable.value }">
                    </em>
                    {{ variable.value }}
                  </td>
                  <td>{{ variable['desc']['en'] || '--' }}</td>
                  <td>{{ variable.inherited_name }}</td>
                </tr>
              </tbody>
            </table>
          </template>
      
          <template v-if="component.meta.tips && component.meta.tips['en']">
            <a class="anchor" id="tips">Tips</a>
            <br>
            <h2>Tips</h2>
            <div>
              <ul>
                <li v-for="tip in component.meta.tips['en']">
                <el-tag size="mini" type="success" class="component-tip-tag">Q</el-tag> <span class="component-tip-question">{{ tip.q }}</span>
                <div v-html="tip.a" class="tip-answer-box"></div>
                </li>
              </ul>
            </div>
          </template>
        </div>
      </template>

      <!--<h2>社区相关讨论</h2>
      [即将上线]
      -->
    
      <br>
      <div v-if="issues.length">
        <a class="anchor" id="Issues">Issues</a>
        <br/>
        <h2>Related issues</h2>
        <ul>
          <li v-for="issue in issues"><a target="_blank" :href="issue.html_url">#{{ issue.number}} <span style="color:#666;">{{ issue.title }}</span></a></li>
        </ul>
      </div>
      <br>
    
      <div v-if="gitMetas">
        <a class="anchor" id="contributors">Contributors</a>
        <h2>Contributors</h2>
        <p>Total commits quantity: {{ gitMetas.commitCount }}，Total contributors quantity: {{gitMetas.commitUniqueCount}}
        </p>
        <a v-for="person in gitMetas.commitMembers" class="contributor-item" :href="'https://github.com/' + person.authorName" target="_blank" :title="'contribute' + person.count">{{person.authorName}}</a>
      </div>
      <br>

      <div v-if="metas.changes">
        <a class="anchor" id="changelog">Changelog</a>
        <br/>
        <h2>Releases</h2>
        <ul v-if="metas.changes">
          <template v-for="(changelog, version) in metas.changes">
            <li v-for="log in changelog['en']">
              <router-link :to="'/en/changelog/' + version + '.html'" class="changelog-version">{{version}}</router-link> {{log}}
            </li>
          </template>
        </ul>
      </div>

      <h2 v-if="metas.references">Referrences</h2>
      <ul v-if="metas.references">
        <li v-for="link in metas.references['en']">
          <a :href="link.link" target="_blank">{{link.title}}</a>
        </li>
      </ul>

      <el-dialog
        class="sourcec-code-dialog"
        top="0"
        width="80%"
        :visible.sync="sourceCodeDialogVisibility">
        <div class="code-box" contenteditable v-html="demoCode"></div>
      </el-dialog>

    </div>
  </template>


  <script>
  import Axios from 'axios'

  // const metas = require('json-loader!yaml-loader!../../../src/components/masker/metas.yml')
  const metas = {
  "category": {
    "en": "Deprecated",
    "zh-CN": "不再维护"
  },
  "icon": "&#xe651;",
  "props": {
    "color": {
      "type": "String",
      "default": "0, 0, 0",
      "en": "the mask's color in rgb format, for example, '0, 0, 0'",
      "zh-CN": "遮罩颜色，rgb值，'0, 0, 0'"
    },
    "opacity": {
      "type": "Number",
      "default": 0.5,
      "en": "the opacity of the mask",
      "zh-CN": "遮罩透明度"
    },
    "fullscreen": {
      "type": "Boolean",
      "version": "v2.1.1-rc.14",
      "default": false,
      "en": "if masker is fullscreen",
      "zh-CN": "遮罩是否全屏"
    }
  },
  "slots": {
    "default": {
      "en": "content below the mask",
      "zh-CN": "背景内容，位于遮罩下方，一般为图片"
    },
    "content": {
      "en": "content above the mask",
      "zh-CN": "遮罩上方内容，一般显示标题消息"
    }
  },
  "changes": {
    "v2.1.1-rc.14": {
      "en": [
        "[feature] Support prop:fullscreen"
      ],
      "zh-CN": [
        "[feature] 支持通过prop设置是否全屏显示"
      ]
    }
  }
}
  const demos = []

  let componentList = []
  if (Array.isArray(metas.items)) {
    try {
      metas.items.forEach((item, index) => {
        const meta = {
          name: item,
          meta: metas[item]
        }
        if (meta.meta.props === null) {
          delete meta.meta.props
        }
        if (index === metas.items.length - 1) {
          if (meta.meta) {
            meta.meta.variables = metas.variables
          }
        }
        componentList.push(meta)
      })
    } catch (e) {
      console.log(e)
    }
  } else {
    componentList.push({
      meta: metas
    })
  }
  const gitMetas = require('./masker_git_metas.json')
  const demoCode = decodeURIComponent(`%3Cpre%20class%3D%22hljs%22%3E%3Ccode%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Etemplate%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ediv%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ediv%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Estyle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22margin%3A%2010px%3Boverflow%3A%20hidden%3B%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Ev-for%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22item%20in%20list%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Emasker%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Estyle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22border-radius%3A%202px%3B%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ediv%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Eclass%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22m-img%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Astyle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22%7BbackgroundImage%3A%20'url('%20%2B%20item.img%20%2B%20')'%7D%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ediv%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ediv%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Eslot%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22content%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Eclass%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22m-title%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%20%20%20%20%7B%7Bitem.title%7D%7D%0A%20%20%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ebr%3C%2Fspan%3E%2F%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Espan%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Eclass%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22m-time%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E2016-03-18%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Espan%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ediv%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Emasker%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ediv%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ediv%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Estyle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22margin%3A%2010px%3Boverflow%3A%20hidden%3B%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Emasker%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Estyle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22border-radius%3A%202px%3B%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Ecolor%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22F9C90C%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Aopacity%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%220.8%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ediv%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Eclass%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22m-img%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Estyle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22background-image%3Aurl(https%3A%2F%2Fcdn.xiaotaojiang.com%2Fuploads%2F56%2F4b3601364b86fdfd234ef11d8712ad%2F_.jpg)%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ediv%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ediv%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Eslot%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22content%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Eclass%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22m-title%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%20%20%20%20VUX%0A%20%20%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ebr%3C%2Fspan%3E%2F%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Espan%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Eclass%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22m-time%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E2016-03-18%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Espan%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ediv%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Emasker%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ediv%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ediv%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Etemplate%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%0A%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Escript%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22javascript%22%3E%0A%3Cspan%20class%3D%22hljs-keyword%22%3Eimport%3C%2Fspan%3E%20%7B%20Masker%20%7D%20%3Cspan%20class%3D%22hljs-keyword%22%3Efrom%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-string%22%3E'vux'%3C%2Fspan%3E%0A%0A%3Cspan%20class%3D%22hljs-keyword%22%3Eexport%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-keyword%22%3Edefault%3C%2Fspan%3E%20%7B%0A%20%20%3Cspan%20class%3D%22hljs-attr%22%3Ecomponents%3C%2Fspan%3E%3A%20%7B%0A%20%20%20%20Masker%0A%20%20%7D%2C%0A%20%20data%20()%20%7B%0A%20%20%20%20%3Cspan%20class%3D%22hljs-keyword%22%3Ereturn%3C%2Fspan%3E%20%7B%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3Elist%3C%2Fspan%3E%3A%20%5B%7B%0A%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3Etitle%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-string%22%3E'%E6%B4%97%E9%A2%9C%E6%96%B0%E6%BD%AE%E6%B5%81%EF%BC%81%E4%BA%BA%E6%B0%94%E6%B4%81%E9%9D%A2%E7%9A%82%E6%8E%92%E8%A1%8C%E6%A6%9C'%3C%2Fspan%3E%2C%0A%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3Eimg%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-string%22%3E'https%3A%2F%2Fcdn.xiaotaojiang.com%2Fuploads%2F82%2F1572ec37969ee263735262dc017975%2F_.jpg'%3C%2Fspan%3E%0A%20%20%20%20%20%20%7D%2C%20%7B%0A%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3Etitle%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-string%22%3E'%E7%BE%8E%E5%AE%B9%E7%94%A8%E5%93%81%20%26amp%3B%20%E6%97%A5%E7%94%A8%E5%93%81%EF%BC%88%E4%B8%8A%EF%BC%89'%3C%2Fspan%3E%2C%0A%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3Eimg%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-string%22%3E'https%3A%2F%2Fcdn.xiaotaojiang.com%2Fuploads%2F59%2Fb22e0e62363a4a652f28630b3233b9%2F_.jpg'%3C%2Fspan%3E%0A%20%20%20%20%20%20%7D%2C%20%7B%0A%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3Etitle%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-string%22%3E'%E8%BF%9C%E7%A6%BB%E8%BD%A6%E5%86%85%E6%AF%92%E6%B0%94%EF%BC%8C%E6%97%A5%E6%9C%AC%E8%BD%A6%E8%BD%BD%E7%A9%BA%E6%B0%94%E5%87%80%E5%8C%96%E5%99%A8%E7%B2%BE%E9%80%89'%3C%2Fspan%3E%2C%0A%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3Eimg%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-string%22%3E'https%3A%2F%2Fcdn.xiaotaojiang.com%2Fuploads%2F56%2F4b3601364b86fdfd234ef11d8712ad%2F_.jpg'%3C%2Fspan%3E%0A%20%20%20%20%20%20%7D%5D%0A%20%20%20%20%7D%0A%20%20%7D%0A%7D%0A%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Escript%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%0A%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Estyle%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Elang%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22less%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22css%22%3E%0A%3Cspan%20class%3D%22hljs-selector-class%22%3E.m-img%3C%2Fspan%3E%20%7B%0A%20%20%3Cspan%20class%3D%22hljs-attribute%22%3Epadding-bottom%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-number%22%3E33%25%3C%2Fspan%3E%3B%0A%20%20%3Cspan%20class%3D%22hljs-attribute%22%3Edisplay%3C%2Fspan%3E%3A%20block%3B%0A%20%20%3Cspan%20class%3D%22hljs-attribute%22%3Eposition%3C%2Fspan%3E%3A%20relative%3B%0A%20%20%3Cspan%20class%3D%22hljs-attribute%22%3Emax-width%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-number%22%3E100%25%3C%2Fspan%3E%3B%0A%20%20%3Cspan%20class%3D%22hljs-attribute%22%3Ebackground-size%3C%2Fspan%3E%3A%20cover%3B%0A%20%20%3Cspan%20class%3D%22hljs-attribute%22%3Ebackground-position%3C%2Fspan%3E%3A%20center%20center%3B%0A%20%20%3Cspan%20class%3D%22hljs-attribute%22%3Ecursor%3C%2Fspan%3E%3A%20pointer%3B%0A%20%20%3Cspan%20class%3D%22hljs-attribute%22%3Eborder-radius%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-number%22%3E2px%3C%2Fspan%3E%3B%0A%7D%0A%0A%3Cspan%20class%3D%22hljs-selector-class%22%3E.m-title%3C%2Fspan%3E%20%7B%0A%20%20%3Cspan%20class%3D%22hljs-attribute%22%3Ecolor%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-number%22%3E%23fff%3C%2Fspan%3E%3B%0A%20%20%3Cspan%20class%3D%22hljs-attribute%22%3Etext-align%3C%2Fspan%3E%3A%20center%3B%0A%20%20%3Cspan%20class%3D%22hljs-attribute%22%3Etext-shadow%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-number%22%3E0%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-number%22%3E0%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-number%22%3E2px%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-built_in%22%3Ergba%3C%2Fspan%3E(0%2C%200%2C%200%2C%20.5)%3B%0A%20%20%3Cspan%20class%3D%22hljs-attribute%22%3Efont-weight%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-number%22%3E500%3C%2Fspan%3E%3B%0A%20%20%3Cspan%20class%3D%22hljs-attribute%22%3Efont-size%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-number%22%3E16px%3C%2Fspan%3E%3B%0A%20%20%3Cspan%20class%3D%22hljs-attribute%22%3Eposition%3C%2Fspan%3E%3A%20absolute%3B%0A%20%20%3Cspan%20class%3D%22hljs-attribute%22%3Eleft%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-number%22%3E0%3C%2Fspan%3E%3B%0A%20%20%3Cspan%20class%3D%22hljs-attribute%22%3Eright%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-number%22%3E0%3C%2Fspan%3E%3B%0A%20%20%3Cspan%20class%3D%22hljs-attribute%22%3Ewidth%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-number%22%3E100%25%3C%2Fspan%3E%3B%0A%20%20%3Cspan%20class%3D%22hljs-attribute%22%3Etext-align%3C%2Fspan%3E%3A%20center%3B%0A%20%20%3Cspan%20class%3D%22hljs-attribute%22%3Etop%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-number%22%3E50%25%3C%2Fspan%3E%3B%0A%20%20%3Cspan%20class%3D%22hljs-attribute%22%3Etransform%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-built_in%22%3EtranslateY%3C%2Fspan%3E(-50%25)%3B%0A%7D%0A%0A%3Cspan%20class%3D%22hljs-selector-class%22%3E.m-time%3C%2Fspan%3E%20%7B%0A%20%20%3Cspan%20class%3D%22hljs-attribute%22%3Efont-size%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-number%22%3E12px%3C%2Fspan%3E%3B%0A%20%20%3Cspan%20class%3D%22hljs-attribute%22%3Epadding-top%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-number%22%3E4px%3C%2Fspan%3E%3B%0A%20%20%3Cspan%20class%3D%22hljs-attribute%22%3Eborder-top%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-number%22%3E1px%3C%2Fspan%3E%20solid%20%3Cspan%20class%3D%22hljs-number%22%3E%23f0f0f0%3C%2Fspan%3E%3B%0A%20%20%3Cspan%20class%3D%22hljs-attribute%22%3Edisplay%3C%2Fspan%3E%3A%20inline-block%3B%0A%20%20%3Cspan%20class%3D%22hljs-attribute%22%3Emargin-top%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-number%22%3E5px%3C%2Fspan%3E%3B%0A%7D%0A%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Estyle%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%3C%2Fcode%3E%3C%2Fpre%3E`)

  const domainMap = {
    'development': 'http://localhost:8080/',
    'production': 'https://vux.li/demos/v2/'
  }

  export default {
    head: {
      title: 'Masker component tutorial | VUX - Vue.js Mobile UI Component Framework',
      meta: [{
        name: 'description',
        content: 'Vue component masker for the VUX framework.'
      }, {
        name: 'keywords',
        content: 'masker, vue-masker, vux-masker, vue mobile components'
      }, {
        property: 'og:title',
        content: 'Masker component tutorial | VUX - Vue.js Mobile UI Component Framework'
      }, {
        property: 'og:description',
        content: 'Vue component masker for the VUX framework.'
      }],
      // https://support.google.com/webmasters/answer/189077?hl=en
      link: [{"rel":"alternate","hreflang":"zh-CN","href":"/zh-CN/components/masker.html"}],
      script: [
        {
          innerHTML:'{"@context":"http://schema.org/","@type":"SoftwareApplication","name":"Vue Component masker","screenshot":"","description":"Vue.js component for VUX","url":"/en/components/masker.html","applicationCategory":"Component","author":{"@type":"Organization","name":"VUX","url":"https://vux.li"},"downloadUrl":"https://vux.li","softwareVersion":"2.9.2","aggregateRating":{"@type":"AggregateRating","ratingValue":5,"reviewCount":6},"operatingSystem":"iOS >= 7, Android >= 4.1","offers":{"@type":"Offer","price":0,"priceCurrency":"USD","availability":"http://schema.org/InStock"}}',
          type: 'application/ld+json'
        }
      ],
      __dangerouslyDisableSanitizers: ['script']
    },
    filters: {
      parseCode (str) {
        return str.replace(/`(.*?)`/g, '<code>$1</code>')
      }
    },
    async mounted () {
      const rs = await Axios.get('https://api.github.com/search/issues?q=repo:airyland/vux%20label:component/' + this.componentName)
      this.issues = rs.data.items
      this.hasReady = true
    },
    watch: {
      async sourceCodeDialogVisibility (val) {
        if (val) {
          await this.$nextTick()
          const mask = document.querySelector('.v-modal')
          mask && mask.addEventListener('click', () => {
            this.sourceCodeDialogVisibility = false
          })
        }
      }
    },
    methods: {
      onCopyError () {
        this.$message({
          type: 'error',
          message: 'copy fail!'
        })
      },
      onCopy () {
        this.$message({
          type: 'success',
          message: 'copy done!'
        })
      },
      showSourceCode () {
        this.sourceCodeDialogVisibility = true
      },
      getTypeHTML (type) {
        type = type || 'String'
        if (/,/.test(type)) {
          const list = type.split(',').map(function (one) {
            return one.replace(/^s+|s+$/g, '')
          }).map(function (one) {
            const type = one ?  one.toLowerCase() : 'string'
            return '<span class="type">' + type + '</span>'
          })
          return list.join('<br>')
        } else {
          type = type ?  type.toLowerCase() : 'string'
          return '<span class="type">' + type + '</span>'
        }
      }
    },
    computed: {
      lang () {
        if (this.$route.path.indexOf('/en/') !== -1) {
          return 'en'
        }
        if (this.$route.path.indexOf('/zh-CN/') !== -1) {
          return 'zh-CN'
        }
        return 'en'
      }
    },
    data () {
      return {
        demos,
        isBeta: false,
        hasReady: false,
        issues: [],
        componentName: 'masker',
        demoCode,
        sourceCodeDialogVisibility: false,
        showQr: false,
        metas: metas,
        gitMetas,
        componentList,
        localImportCode: `import { Masker } from 'vux'

export default {
  components: {
    Masker
  }
}`,
        globalImportCode: `// you can also register globally

import Vue from 'vue'
import { Masker } from 'vux'

Vue.component('masker', Masker)
`,
        needImport: true,
        toc: [],
        domain: domainMap[process.env.NODE_ENV]
      }
    }
  }
  </script>

  <style>
  .component-box {
    position: relative;
  }
  .component-demo {
    position: absolute;
    right: 5px;
    top: 15px;
  }
  .prop-color {
    display: inline-block;
    width: 10px;
    height: 10px;
    border: 1px solid #aaa;
  }
  .changelog-version {
    width: 110px;
    display: inline-block;
  }
  .component-extra-links {
    position: relative;
    font-size: 12px;
  }
  .component-extra-links a {
    padding-right: 10px;
    color: #999;
  }
  </style>
    