
  <template>
    <div class="component-box" :class="demos.length ? 'components-with-toc' : ''">

      <div :class="demos.length ? 'component-header-v2' : 'component-header-v1'">
        <a class="anchor" id="intro">WechatEmotion</a>
        <div class="title-box">

          <el-badge value="Beta" v-if="isBeta">
            <h1 class="vux-component-name">WechatEmotion</h1>
          </el-badge>
          <h1 v-else class="vux-component-name">WechatEmotion</h1>

          <p class="component-extra-links">
            <a href="https://vux.li/demos/v2/#/component/wechat-emotion" target="_blank">demo url</a>
            <a v-if="!demos.length" href="https://github.com/airyland/vux/blob/v2/src/demos/WechatEmotion.vue" target="_blank" @click.prevent="showSourceCode">demo source code</a>
            <a href="https://github.com/airyland/vux/blob/v2/src/components/wechat-emotion/metas.yml" target="_blank">edit document</a>
            <a href="https://github.com/airyland/vux/blob/v2/src/components/wechat-emotion/" target="_blank">component source code</a>
            <el-popover trigger="hover" v-if="hasReady">
              <div style="width:100%;text-align:center;">
                <img class="qr" width="100" src="https://qr.vux.li/api.php?text=https%3A%2F%2Fvux.li%2Fdemos%2Fv2%2F%23%2Fcomponent%2Fwechat-emotion"/>
              </div>
              <a href="javascript:" slot="reference">
              view demos on mobile
              </a>
            </el-popover>
          </p>

          <div class="component-description">
            <template v-if="false">
            
            </template>
          </div>

        </div>

        <div v-if="!demos.length" class="component-demo" style="width:377px;height:600px;display:inline-block;border:1px solid #ececec;border-radius:5px;overflow:hidden;z-index:2500;">
          <iframe src="https://vux.li/demos/v2?locale=en&transition=none/#/component/wechat-emotion" width="375" height="600" border="0" frameborder="0"></iframe>
        </div>
        <div class="toc">
          <ul v-for="t in toc">
            <li>
              <a :href="'#' + (t.anchor || t.title)">{{ t.title }}</a>
              <ul v-if="t.list" v-for="_t in t.list">
                <li><a :href="'#' + _t.anchor">{{ _t.title.slice(0, 12) }}</a></li>
              </ul>
            </li>
          </ul>
        </div>
      
        <template v-if="needImport">
          <a class="anchor" id="install">Install</a>
          <h2>Install</h2>
          <el-tabs>
            <el-tab-pane label="Local Registration">
              <div class="import-code-box">
              <el-tooltip content="click to copy" placement="top">
                <span
                  v-clipboard:copy="localImportCode"
                  v-clipboard:success="onCopy"
                  v-clipboard:error="onCopyError">
                  <el-icon class="el-icon-document"></el-icon>
                </span>
              </el-tooltip>
              <pre class="hljs"><code><span class="hljs-keyword">import</span> { WechatEmotion } <span class="hljs-keyword">from</span> <span class="hljs-string">'vux'</span>

<span class="hljs-keyword">export</span> <span class="hljs-keyword">default</span> {
  <span class="hljs-attr">components</span>: {
    WechatEmotion
  }
}</code></pre>
            </div>
            </el-tab-pane>
            <el-tab-pane label="Global Registration">
              <div class="import-code-box">
                <el-tooltip content="click to copy" placement="top">
                  <span
                    v-clipboard:copy="globalImportCode"
                    v-clipboard:success="onCopy"
                    v-clipboard:error="onCopyError">
                    <el-icon class="el-icon-document"></el-icon>
                  </span>
                </el-tooltip>
                <pre class="hljs"><code><span class="hljs-comment">// you can also register globally</span>

<span class="hljs-keyword">import</span> Vue <span class="hljs-keyword">from</span> <span class="hljs-string">'vue'</span>
<span class="hljs-keyword">import</span> { WechatEmotion } <span class="hljs-keyword">from</span> <span class="hljs-string">'vux'</span>

Vue.component(<span class="hljs-string">'wechat-emotion'</span>, WechatEmotion)
</code></pre>
              </div> 
            </el-tab-pane>
          </el-tabs>   
        </template>

        <template v-else>
          <div class="tip">
            <p>You don't need to import this component.</p>
          </div>
        </template>

        <div class="tip" style="width:600px;" v-if="metas.tip">
          
        </div>
      
        <h2 v-if="metas.example">example</h2>
        <div v-if="metas.example" style="width:600px;">
          
        </div>
      </div>

      <div v-if="metas.extra && metas.extra['en']">
        
      </div>
      <div v-if="metas.extra && !metas.extra['en']">
        
      </div>
      
      <a v-if="demos.length" class="anchor" id="examples">Examples</a>
      <br/>
      <template v-if="demos.length" v-for="demo in demos">
        <a class="anchor" :id="'examples:' + demo.title">{{ demo.title }}</a>
        <br/>
        <div class="demo-header">
          <span class="demo-title">{{ demo.title }}</span>
        </div>
        <div class="demos" :style="{height: demo.height}">
          <div class="demo-iframe-box">
            <lazy-component>
              <iframe
                :src="domain + '?no-background-color=' + demo.noBackgroundColor +'&locale=en&transition=none&hide-nav=true&hide-tab-bar=true#/components/' + demo.file"
                width="375"
                height="600"
                border="0"
                frameborder="0"
                style="margin: 0 auto;"></iframe>
            </lazy-component>
          </div>
          <div class="demo-code-box" :style="{overflow: demo.height === demo.oriHeight ? 'hidden' : 'scroll'}">
            <div v-html="demo.code" contenteditable></div>
            <div v-if="demo.height === demo.oriHeight" class="demo-code-masker" @click="demo.height='auto'">
              <div>
                  <img class="demo-qr" width="100" :src="'https://qr.vux.li/api.php?text=' + encodeURIComponent(domain + '?locale=en#/components/' + demo.file)"/>
                  <br/>
                  <span>
                    <el-icon class="el-icon-arrow-left"/>
                    <el-icon class="el-icon-arrow-right"/>
                    Show code
                  <br/>
                  <!--<span class="demo-path">src/demos/{{ demo.file }}.vue</span>-->
                </span>
              </div>
            </div>
            <span v-if="demo.height === 'auto'" class="hide-code" @click="demo.height=demo.oriHeight">
              <el-icon class="el-icon-close"></el-icon>
            </span>
          </div>
        </div>
      </template>

      <template v-for="component in componentList">
        <div>
          <a v-if="componentList.length > 1" class="anchor" :id="'components:' + component.name">{{ component.name }}</a>
          <a v-else class="anchor" id="api">API</a>
          <br/>
          <h2
            v-show="componentList.length > 1"
            class="vux-component-name-sub-item">{{ component.name }}</h2>
            
          <template v-if="component.meta.items && component.meta.description">
            <div v-html="component.meta.description"></div>
          </template>

          <template v-if="component.meta.props">
            <h2>Props</h2>
            <table>
              <thead>
                <tr>
                  <td>name</td>
                  <td style="width:48px;">type</td>
                  <td>default</td>
                  <td>description</td>
                  <td>required version</td>
                </tr>
              </thead>
              <tbody>
                <tr v-for="(prop, i) in component.meta.props">
                  <td class="prop-name">
                    <el-tooltip content="click to copy" placement="left" :hide-after="0" :open-delay="50">
                      <span
                      v-clipboard:copy="i"
                      v-clipboard:success="onCopy">{{ i }}</span>
                    </el-tooltip>
                  </td>
                  <td v-html="getTypeHTML(prop.type)"></td>
                  <td>{{ prop.default}}</td>
                  <td v-html="prop['en'].replace(/`(.*?)`/g, '<code>$1</code>')"></td>
                  <td>{{ prop.version || '--'}}</td>
                </tr>
              </tbody>
            </table>
          </template>

          <template v-if="component.meta.events">
            <h2>Events</h2>
            <table>
              <thead>
                <tr>
                  <td>name</td>
                  <td>params</td>
                  <td>description</td>
                  <td>required version</td>
                </tr>
              </thead>
              <tbody>
                <tr v-for="(event, i) in component.meta.events">
                  <td class="prop-name">
                    <el-tooltip content="click to copy" placement="left" :hide-after="0" :open-delay="50">
                      <span
                      v-clipboard:copy="'@' + i"
                      v-clipboard:success="onCopy">@{{ i }}</span>
                    </el-tooltip>
                  </td>
                  <td v-html="event.params ? event.params.replace(/`(.*?)`/g, '<code>$1</code>') : '--'"></td>
                  <td v-html="event['en'] ? event['en'].replace(/`(.*?)`/g, '<code>$1</code>') : '--'"></td>
                  <td>{{ event['version'] || '--' }}</td>
                </tr>
              </tbody>
            </table>
          </template>
      

          <template v-if="component.meta.slots">
            <h2>Slots</h2>
            <table>
              <thead>
                <tr>
                  <td>name</td>
                  <td>description</td>
                  <td>required version</td>
                </tr>
              </thead>
              <tbody>
                <tr v-for="(slot, i) in component.meta.slots" :class="{'slot-disabled': slot['status'] === 'deprecated'}">
                  <td class="prop-name">
                    <el-tooltip content="click to copy" placement="left" :hide-after="0" :open-delay="50">
                      <span
                      v-clipboard:copy="i"
                      v-clipboard:success="onCopy">{{ i === 'default' ? 'default' : i }}</span>
                    </el-tooltip>
                  </td>
                  <td v-html="slot['en'] ? slot['en'].replace(/`(.*?)`/g, '<code>$1</code>') : ''"></td>
                  <td>{{ slot['version'] || '--' }}</td>
                </tr>
              </tbody>
            </table>
          </template>
          
          <template v-if="component.meta.methods">
            <h2>Functions</h2>
            <table>
              <thead>
                <tr>
                  <td>name</td>
                  <td>params</td>
                  <td>description</td>
                  <td>required version</td>
                </tr>
              </thead>
              <tbody>
                <tr v-for="(method, i) in component.meta.methods">
                  <td class="prop-name">
                    <el-tooltip content="click to copy" placement="left" :hide-after="0" :open-delay="50">
                      <span
                      v-clipboard:copy="i"
                      v-clipboard:success="onCopy">{{ i }}</span>
                    </el-tooltip>
                  </td>
                  <td v-html="method['params'] ? method['params'].replace(/`(.*?)`/g, '<code>$1</code>') : ''"></td>
                  <td v-html="method['en'].replace(/`(.*?)`/g, '<code>$1</code>')"></td>
                  <td>{{ method['version'] }}</td>
                </tr>
              </tbody>
            </table>
          </template>

          <template v-if="component.meta.variables">
            <a class="anchor" id="variables">Variables</a>
            <br/>
            <h2>Variables</h2>
            <table>
              <thead>
                <tr>
                  <td>name</td>
                  <td>default</td>
                  <td>description</td>
                  <td>inherited name</td>
                </tr>
              </thead>
              <tbody>
                <tr v-for="(variable, i) in component.meta.variables">
                  <td class="prop-name">
                    <el-tooltip content="click to copy" placement="left" :hide-after="0" :open-delay="50">
                      <span
                      v-clipboard:copy="'@' + variable.name"
                      v-clipboard:success="onCopy">@{{ variable.name }}</span>
                    </el-tooltip>
                  </td>
                  <td>
                    <em
                      :ref="'propColor' + i"
                      v-if="!$refs['propColor' + i] || ($refs['propColor' + i][0] && $refs['propColor' + i][0].style.backgroundColor)"
                      class="prop-color"
                      :style="{ backgroundColor: variable.value }">
                    </em>
                    {{ variable.value }}
                  </td>
                  <td>{{ variable['desc']['en'] || '--' }}</td>
                  <td>{{ variable.inherited_name }}</td>
                </tr>
              </tbody>
            </table>
          </template>
      
          <template v-if="component.meta.tips && component.meta.tips['en']">
            <a class="anchor" id="tips">Tips</a>
            <br>
            <h2>Tips</h2>
            <div>
              <ul>
                <li v-for="tip in component.meta.tips['en']">
                <el-tag size="mini" type="success" class="component-tip-tag">Q</el-tag> <span class="component-tip-question">{{ tip.q }}</span>
                <div v-html="tip.a" class="tip-answer-box"></div>
                </li>
              </ul>
            </div>
          </template>
        </div>
      </template>

      <!--<h2>社区相关讨论</h2>
      [即将上线]
      -->
    
      <br>
      <div v-if="issues.length">
        <a class="anchor" id="Issues">Issues</a>
        <br/>
        <h2>Related issues</h2>
        <ul>
          <li v-for="issue in issues"><a target="_blank" :href="issue.html_url">#{{ issue.number}} <span style="color:#666;">{{ issue.title }}</span></a></li>
        </ul>
      </div>
      <br>
    
      <div v-if="gitMetas">
        <a class="anchor" id="contributors">Contributors</a>
        <h2>Contributors</h2>
        <p>Total commits quantity: {{ gitMetas.commitCount }}，Total contributors quantity: {{gitMetas.commitUniqueCount}}
        </p>
        <a v-for="person in gitMetas.commitMembers" class="contributor-item" :href="'https://github.com/' + person.authorName" target="_blank" :title="'contribute' + person.count">{{person.authorName}}</a>
      </div>
      <br>

      <div v-if="metas.changes">
        <a class="anchor" id="changelog">Changelog</a>
        <br/>
        <h2>Releases</h2>
        <ul v-if="metas.changes">
          <template v-for="(changelog, version) in metas.changes">
            <li v-for="log in changelog['en']">
              <router-link :to="'/en/changelog/' + version + '.html'" class="changelog-version">{{version}}</router-link> {{log}}
            </li>
          </template>
        </ul>
      </div>

      <h2 v-if="metas.references">Referrences</h2>
      <ul v-if="metas.references">
        <li v-for="link in metas.references['en']">
          <a :href="link.link" target="_blank">{{link.title}}</a>
        </li>
      </ul>

      <el-dialog
        class="sourcec-code-dialog"
        top="0"
        width="80%"
        :visible.sync="sourceCodeDialogVisibility">
        <div class="code-box" contenteditable v-html="demoCode"></div>
      </el-dialog>

    </div>
  </template>


  <script>
  import Axios from 'axios'

  // const metas = require('json-loader!yaml-loader!../../../src/components/wechat-emotion/metas.yml')
  const metas = {
  "category": {
    "en": "Deprecated",
    "zh-CN": "不再维护"
  },
  "category_order": 999,
  "icon": "&#xe63c;",
  "props": {
    "isGif": {
      "type": "Boolean",
      "default": false,
      "en": "if using gif image",
      "zh-CN": "是否为动图"
    }
  },
  "slots": {
    "default": {
      "en": "emotion name, list: '微笑', '撇嘴', '色', '发呆', '得意', '流泪', '害羞', '闭嘴', '睡', '大哭', '尴尬', '发怒', '调皮', '呲牙', '惊讶', '难过', '酷', '冷汗', '抓狂', '吐', '偷笑', '可爱', '白眼', '傲慢', '饥饿', '困', '惊恐', '流汗', '憨笑', '大兵', '奋斗', '咒骂', '疑问', '嘘', '晕', '折磨', '衰', '骷髅', '敲打', '再见', '擦汗', '抠鼻', '鼓掌', '糗大了', '坏笑', '左哼哼', '右哼哼', '哈欠', '鄙视', '委屈', '快哭了', '阴险', '亲亲', '吓', '可怜', '菜刀', '西瓜', '啤酒', '篮球', '乒乓', '咖啡', '饭', '猪头', '玫瑰', '凋谢', '示爱', '爱心', '心碎', '蛋糕', '闪电', '炸弹', '刀', '足球', '瓢虫', '便便', '月亮', '太阳', '礼物', '拥抱', '强', '弱', '握手', '胜利', '抱拳', '勾引', '拳头', '差劲', '爱你', 'NO', 'OK', '爱情', '飞吻', '跳跳', '发抖', '怄火', '转圈', '磕头', '回头', '跳绳', '挥手', '激动', '街舞', '献吻', '左太极', '右太极'",
      "zh-CN": "表情名字, 可选值: '微笑', '撇嘴', '色', '发呆', '得意', '流泪', '害羞', '闭嘴', '睡', '大哭', '尴尬', '发怒', '调皮', '呲牙', '惊讶', '难过', '酷', '冷汗', '抓狂', '吐', '偷笑', '可爱', '白眼', '傲慢', '饥饿', '困', '惊恐', '流汗', '憨笑', '大兵', '奋斗', '咒骂', '疑问', '嘘', '晕', '折磨', '衰', '骷髅', '敲打', '再见', '擦汗', '抠鼻', '鼓掌', '糗大了', '坏笑', '左哼哼', '右哼哼', '哈欠', '鄙视', '委屈', '快哭了', '阴险', '亲亲', '吓', '可怜', '菜刀', '西瓜', '啤酒', '篮球', '乒乓', '咖啡', '饭', '猪头', '玫瑰', '凋谢', '示爱', '爱心', '心碎', '蛋糕', '闪电', '炸弹', '刀', '足球', '瓢虫', '便便', '月亮', '太阳', '礼物', '拥抱', '强', '弱', '握手', '胜利', '抱拳', '勾引', '拳头', '差劲', '爱你', 'NO', 'OK', '爱情', '飞吻', '跳跳', '发抖', '怄火', '转圈', '磕头', '回头', '跳绳', '挥手', '激动', '街舞', '献吻', '左太极', '右太极'"
    }
  }
}
  const demos = []

  let componentList = []
  if (Array.isArray(metas.items)) {
    try {
      metas.items.forEach((item, index) => {
        const meta = {
          name: item,
          meta: metas[item]
        }
        if (meta.meta.props === null) {
          delete meta.meta.props
        }
        if (index === metas.items.length - 1) {
          if (meta.meta) {
            meta.meta.variables = metas.variables
          }
        }
        componentList.push(meta)
      })
    } catch (e) {
      console.log(e)
    }
  } else {
    componentList.push({
      meta: metas
    })
  }
  const gitMetas = require('./wechat-emotion_git_metas.json')
  const demoCode = decodeURIComponent(`%3Cpre%20class%3D%22hljs%22%3E%3Ccode%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Etemplate%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ediv%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Edivider%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%7B%7B%20%24t('wechat%20emotions')%20%7D%7D%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Edivider%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ediv%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Ev-for%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22item%20in%20list%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Eclass%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22vux-center-h%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Eemotion%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%7B%7Bitem%7D%7D%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Eemotion%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Eemotion%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Eis-gif%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%7B%7Bitem%7D%7D%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Eemotion%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ediv%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ediv%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Etemplate%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%0A%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ei18n%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0Awechat%20emotions%3A%0A%20%20zh-CN%3A%20%E5%BE%AE%E4%BF%A1%E8%A1%A8%E6%83%85%E5%88%97%E8%A1%A8%0A%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ei18n%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%0A%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Escript%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22javascript%22%3E%0A%3Cspan%20class%3D%22hljs-keyword%22%3Eimport%3C%2Fspan%3E%20%7B%20WechatEmotion%20%3Cspan%20class%3D%22hljs-keyword%22%3Eas%3C%2Fspan%3E%20Emotion%2C%20Divider%20%7D%20%3Cspan%20class%3D%22hljs-keyword%22%3Efrom%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-string%22%3E'vux'%3C%2Fspan%3E%0A%0A%3Cspan%20class%3D%22hljs-keyword%22%3Eexport%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-keyword%22%3Edefault%3C%2Fspan%3E%20%7B%0A%20%20%3Cspan%20class%3D%22hljs-attr%22%3Ecomponents%3C%2Fspan%3E%3A%20%7B%0A%20%20%20%20Emotion%2C%0A%20%20%20%20Divider%0A%20%20%7D%2C%0A%20%20data%20()%20%7B%0A%20%20%20%20%3Cspan%20class%3D%22hljs-keyword%22%3Ereturn%3C%2Fspan%3E%20%7B%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3Elist%3C%2Fspan%3E%3A%20%5B%3Cspan%20class%3D%22hljs-string%22%3E'%E5%BE%AE%E7%AC%91'%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-string%22%3E'%E6%92%87%E5%98%B4'%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-string%22%3E'%E8%89%B2'%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-string%22%3E'%E5%8F%91%E5%91%86'%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-string%22%3E'%E5%BE%97%E6%84%8F'%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-string%22%3E'%E6%B5%81%E6%B3%AA'%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-string%22%3E'%E5%AE%B3%E7%BE%9E'%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-string%22%3E'%E9%97%AD%E5%98%B4'%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-string%22%3E'%E7%9D%A1'%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-string%22%3E'%E5%A4%A7%E5%93%AD'%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-string%22%3E'%E5%B0%B4%E5%B0%AC'%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-string%22%3E'%E5%8F%91%E6%80%92'%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-string%22%3E'%E8%B0%83%E7%9A%AE'%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-string%22%3E'%E5%91%B2%E7%89%99'%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-string%22%3E'%E6%83%8A%E8%AE%B6'%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-string%22%3E'%E9%9A%BE%E8%BF%87'%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-string%22%3E'%E9%85%B7'%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-string%22%3E'%E5%86%B7%E6%B1%97'%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-string%22%3E'%E6%8A%93%E7%8B%82'%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-string%22%3E'%E5%90%90'%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-string%22%3E'%E5%81%B7%E7%AC%91'%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-string%22%3E'%E5%8F%AF%E7%88%B1'%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-string%22%3E'%E7%99%BD%E7%9C%BC'%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-string%22%3E'%E5%82%B2%E6%85%A2'%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-string%22%3E'%E9%A5%A5%E9%A5%BF'%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-string%22%3E'%E5%9B%B0'%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-string%22%3E'%E6%83%8A%E6%81%90'%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-string%22%3E'%E6%B5%81%E6%B1%97'%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-string%22%3E'%E6%86%A8%E7%AC%91'%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-string%22%3E'%E5%A4%A7%E5%85%B5'%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-string%22%3E'%E5%A5%8B%E6%96%97'%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-string%22%3E'%E5%92%92%E9%AA%82'%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-string%22%3E'%E7%96%91%E9%97%AE'%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-string%22%3E'%E5%98%98'%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-string%22%3E'%E6%99%95'%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-string%22%3E'%E6%8A%98%E7%A3%A8'%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-string%22%3E'%E8%A1%B0'%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-string%22%3E'%E9%AA%B7%E9%AB%85'%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-string%22%3E'%E6%95%B2%E6%89%93'%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-string%22%3E'%E5%86%8D%E8%A7%81'%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-string%22%3E'%E6%93%A6%E6%B1%97'%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-string%22%3E'%E6%8A%A0%E9%BC%BB'%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-string%22%3E'%E9%BC%93%E6%8E%8C'%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-string%22%3E'%E7%B3%97%E5%A4%A7%E4%BA%86'%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-string%22%3E'%E5%9D%8F%E7%AC%91'%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-string%22%3E'%E5%B7%A6%E5%93%BC%E5%93%BC'%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-string%22%3E'%E5%8F%B3%E5%93%BC%E5%93%BC'%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-string%22%3E'%E5%93%88%E6%AC%A0'%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-string%22%3E'%E9%84%99%E8%A7%86'%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-string%22%3E'%E5%A7%94%E5%B1%88'%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-string%22%3E'%E5%BF%AB%E5%93%AD%E4%BA%86'%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-string%22%3E'%E9%98%B4%E9%99%A9'%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-string%22%3E'%E4%BA%B2%E4%BA%B2'%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-string%22%3E'%E5%90%93'%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-string%22%3E'%E5%8F%AF%E6%80%9C'%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-string%22%3E'%E8%8F%9C%E5%88%80'%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-string%22%3E'%E8%A5%BF%E7%93%9C'%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-string%22%3E'%E5%95%A4%E9%85%92'%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-string%22%3E'%E7%AF%AE%E7%90%83'%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-string%22%3E'%E4%B9%92%E4%B9%93'%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-string%22%3E'%E5%92%96%E5%95%A1'%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-string%22%3E'%E9%A5%AD'%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-string%22%3E'%E7%8C%AA%E5%A4%B4'%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-string%22%3E'%E7%8E%AB%E7%91%B0'%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-string%22%3E'%E5%87%8B%E8%B0%A2'%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-string%22%3E'%E7%A4%BA%E7%88%B1'%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-string%22%3E'%E7%88%B1%E5%BF%83'%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-string%22%3E'%E5%BF%83%E7%A2%8E'%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-string%22%3E'%E8%9B%8B%E7%B3%95'%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-string%22%3E'%E9%97%AA%E7%94%B5'%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-string%22%3E'%E7%82%B8%E5%BC%B9'%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-string%22%3E'%E5%88%80'%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-string%22%3E'%E8%B6%B3%E7%90%83'%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-string%22%3E'%E7%93%A2%E8%99%AB'%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-string%22%3E'%E4%BE%BF%E4%BE%BF'%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-string%22%3E'%E6%9C%88%E4%BA%AE'%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-string%22%3E'%E5%A4%AA%E9%98%B3'%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-string%22%3E'%E7%A4%BC%E7%89%A9'%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-string%22%3E'%E6%8B%A5%E6%8A%B1'%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-string%22%3E'%E5%BC%BA'%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-string%22%3E'%E5%BC%B1'%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-string%22%3E'%E6%8F%A1%E6%89%8B'%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-string%22%3E'%E8%83%9C%E5%88%A9'%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-string%22%3E'%E6%8A%B1%E6%8B%B3'%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-string%22%3E'%E5%8B%BE%E5%BC%95'%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-string%22%3E'%E6%8B%B3%E5%A4%B4'%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-string%22%3E'%E5%B7%AE%E5%8A%B2'%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-string%22%3E'%E7%88%B1%E4%BD%A0'%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-string%22%3E'NO'%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-string%22%3E'OK'%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-string%22%3E'%E7%88%B1%E6%83%85'%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-string%22%3E'%E9%A3%9E%E5%90%BB'%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-string%22%3E'%E8%B7%B3%E8%B7%B3'%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-string%22%3E'%E5%8F%91%E6%8A%96'%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-string%22%3E'%E6%80%84%E7%81%AB'%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-string%22%3E'%E8%BD%AC%E5%9C%88'%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-string%22%3E'%E7%A3%95%E5%A4%B4'%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-string%22%3E'%E5%9B%9E%E5%A4%B4'%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-string%22%3E'%E8%B7%B3%E7%BB%B3'%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-string%22%3E'%E6%8C%A5%E6%89%8B'%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-string%22%3E'%E6%BF%80%E5%8A%A8'%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-string%22%3E'%E8%A1%97%E8%88%9E'%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-string%22%3E'%E7%8C%AE%E5%90%BB'%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-string%22%3E'%E5%B7%A6%E5%A4%AA%E6%9E%81'%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-string%22%3E'%E5%8F%B3%E5%A4%AA%E6%9E%81'%3C%2Fspan%3E%5D%0A%20%20%20%20%7D%0A%20%20%7D%0A%7D%0A%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Escript%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%3C%2Fcode%3E%3C%2Fpre%3E`)

  const domainMap = {
    'development': 'http://localhost:8080/',
    'production': 'https://vux.li/demos/v2/'
  }

  export default {
    head: {
      title: 'WechatEmotion component tutorial | VUX - Vue.js Mobile UI Component Framework',
      meta: [{
        name: 'description',
        content: 'Vue component wechat-emotion for the VUX framework.'
      }, {
        name: 'keywords',
        content: 'wechat-emotion, vue-wechat-emotion, vux-wechat-emotion, vue mobile components'
      }, {
        property: 'og:title',
        content: 'WechatEmotion component tutorial | VUX - Vue.js Mobile UI Component Framework'
      }, {
        property: 'og:description',
        content: 'Vue component wechat-emotion for the VUX framework.'
      }],
      // https://support.google.com/webmasters/answer/189077?hl=en
      link: [{"rel":"alternate","hreflang":"zh-CN","href":"/zh-CN/components/wechat-emotion.html"}],
      script: [
        {
          innerHTML:'{"@context":"http://schema.org/","@type":"SoftwareApplication","name":"Vue Component wechat-emotion","screenshot":"","description":"Vue.js component for VUX","url":"/en/components/wechat-emotion.html","applicationCategory":"Component","author":{"@type":"Organization","name":"VUX","url":"https://vux.li"},"downloadUrl":"https://vux.li","softwareVersion":"2.9.2","aggregateRating":{"@type":"AggregateRating","ratingValue":5,"reviewCount":3},"operatingSystem":"iOS >= 7, Android >= 4.1","offers":{"@type":"Offer","price":0,"priceCurrency":"USD","availability":"http://schema.org/InStock"}}',
          type: 'application/ld+json'
        }
      ],
      __dangerouslyDisableSanitizers: ['script']
    },
    filters: {
      parseCode (str) {
        return str.replace(/`(.*?)`/g, '<code>$1</code>')
      }
    },
    async mounted () {
      const rs = await Axios.get('https://api.github.com/search/issues?q=repo:airyland/vux%20label:component/' + this.componentName)
      this.issues = rs.data.items
      this.hasReady = true
    },
    watch: {
      async sourceCodeDialogVisibility (val) {
        if (val) {
          await this.$nextTick()
          const mask = document.querySelector('.v-modal')
          mask && mask.addEventListener('click', () => {
            this.sourceCodeDialogVisibility = false
          })
        }
      }
    },
    methods: {
      onCopyError () {
        this.$message({
          type: 'error',
          message: 'copy fail!'
        })
      },
      onCopy () {
        this.$message({
          type: 'success',
          message: 'copy done!'
        })
      },
      showSourceCode () {
        this.sourceCodeDialogVisibility = true
      },
      getTypeHTML (type) {
        type = type || 'String'
        if (/,/.test(type)) {
          const list = type.split(',').map(function (one) {
            return one.replace(/^s+|s+$/g, '')
          }).map(function (one) {
            const type = one ?  one.toLowerCase() : 'string'
            return '<span class="type">' + type + '</span>'
          })
          return list.join('<br>')
        } else {
          type = type ?  type.toLowerCase() : 'string'
          return '<span class="type">' + type + '</span>'
        }
      }
    },
    computed: {
      lang () {
        if (this.$route.path.indexOf('/en/') !== -1) {
          return 'en'
        }
        if (this.$route.path.indexOf('/zh-CN/') !== -1) {
          return 'zh-CN'
        }
        return 'en'
      }
    },
    data () {
      return {
        demos,
        isBeta: false,
        hasReady: false,
        issues: [],
        componentName: 'wechat-emotion',
        demoCode,
        sourceCodeDialogVisibility: false,
        showQr: false,
        metas: metas,
        gitMetas,
        componentList,
        localImportCode: `import { WechatEmotion } from 'vux'

export default {
  components: {
    WechatEmotion
  }
}`,
        globalImportCode: `// you can also register globally

import Vue from 'vue'
import { WechatEmotion } from 'vux'

Vue.component('wechat-emotion', WechatEmotion)
`,
        needImport: true,
        toc: [],
        domain: domainMap[process.env.NODE_ENV]
      }
    }
  }
  </script>

  <style>
  .component-box {
    position: relative;
  }
  .component-demo {
    position: absolute;
    right: 5px;
    top: 15px;
  }
  .prop-color {
    display: inline-block;
    width: 10px;
    height: 10px;
    border: 1px solid #aaa;
  }
  .changelog-version {
    width: 110px;
    display: inline-block;
  }
  .component-extra-links {
    position: relative;
    font-size: 12px;
  }
  .component-extra-links a {
    padding-right: 10px;
    color: #999;
  }
  </style>
    