
  <template>
    <div class="component-box" :class="demos.length ? 'components-with-toc' : ''">

      <div :class="demos.length ? 'component-header-v2' : 'component-header-v1'">
        <a class="anchor" id="intro">Swiper</a>
        <div class="title-box">

          <el-badge value="Beta" v-if="isBeta">
            <h1 class="vux-component-name">Swiper</h1>
          </el-badge>
          <h1 v-else class="vux-component-name">Swiper</h1>

          <p class="component-extra-links">
            <a href="https://vux.li/demos/v2/#/component/swiper" target="_blank">demo url</a>
            <a v-if="!demos.length" href="https://github.com/airyland/vux/blob/v2/src/demos/Swiper.vue" target="_blank" @click.prevent="showSourceCode">demo source code</a>
            <a href="https://github.com/airyland/vux/blob/v2/src/components/swiper/metas.yml" target="_blank">edit document</a>
            <a href="https://github.com/airyland/vux/blob/v2/src/components/swiper/" target="_blank">component source code</a>
            <el-popover trigger="hover" v-if="hasReady">
              <div style="width:100%;text-align:center;">
                <img class="qr" width="100" src="https://qr.vux.li/api.php?text=https%3A%2F%2Fvux.li%2Fdemos%2Fv2%2F%23%2Fcomponent%2Fswiper"/>
              </div>
              <a href="javascript:" slot="reference">
              view demos on mobile
              </a>
            </el-popover>
          </p>

          <div class="component-description">
            <template v-if="false">
            
            </template>
          </div>

        </div>

        <div v-if="!demos.length" class="component-demo" style="width:377px;height:600px;display:inline-block;border:1px solid #ececec;border-radius:5px;overflow:hidden;z-index:2500;">
          <iframe src="https://vux.li/demos/v2?locale=en&transition=none/#/component/swiper" width="375" height="600" border="0" frameborder="0"></iframe>
        </div>
        <div class="toc">
          <ul v-for="t in toc">
            <li>
              <a :href="'#' + (t.anchor || t.title)">{{ t.title }}</a>
              <ul v-if="t.list" v-for="_t in t.list">
                <li><a :href="'#' + _t.anchor">{{ _t.title.slice(0, 12) }}</a></li>
              </ul>
            </li>
          </ul>
        </div>
      
        <template v-if="needImport">
          <a class="anchor" id="install">Install</a>
          <h2>Install</h2>
          <el-tabs>
            <el-tab-pane label="Local Registration">
              <div class="import-code-box">
              <el-tooltip content="click to copy" placement="top">
                <span
                  v-clipboard:copy="localImportCode"
                  v-clipboard:success="onCopy"
                  v-clipboard:error="onCopyError">
                  <el-icon class="el-icon-document"></el-icon>
                </span>
              </el-tooltip>
              <pre class="hljs"><code><span class="hljs-keyword">import</span> { Swiper } <span class="hljs-keyword">from</span> <span class="hljs-string">'vux'</span>

<span class="hljs-keyword">export</span> <span class="hljs-keyword">default</span> {
  <span class="hljs-attr">components</span>: {
    Swiper
  }
}</code></pre>
            </div>
            </el-tab-pane>
            <el-tab-pane label="Global Registration">
              <div class="import-code-box">
                <el-tooltip content="click to copy" placement="top">
                  <span
                    v-clipboard:copy="globalImportCode"
                    v-clipboard:success="onCopy"
                    v-clipboard:error="onCopyError">
                    <el-icon class="el-icon-document"></el-icon>
                  </span>
                </el-tooltip>
                <pre class="hljs"><code><span class="hljs-comment">// you can also register globally</span>

<span class="hljs-keyword">import</span> Vue <span class="hljs-keyword">from</span> <span class="hljs-string">'vue'</span>
<span class="hljs-keyword">import</span> { Swiper } <span class="hljs-keyword">from</span> <span class="hljs-string">'vux'</span>

Vue.component(<span class="hljs-string">'swiper'</span>, Swiper)
</code></pre>
              </div> 
            </el-tab-pane>
          </el-tabs>   
        </template>

        <template v-else>
          <div class="tip">
            <p>You don't need to import this component.</p>
          </div>
        </template>

        <div class="tip" style="width:600px;" v-if="metas.tip">
          
        </div>
      
        <h2 v-if="metas.example">example</h2>
        <div v-if="metas.example" style="width:600px;">
          
        </div>
      </div>

      <div v-if="metas.extra && metas.extra['en']">
        
      </div>
      <div v-if="metas.extra && !metas.extra['en']">
        <div class="tip">
<p><code>list</code>为图片列表快捷设置，如果你需要自定义一些样式，或者内容并不为纯图片，可以引用<code>swiper-item</code>组件来自定义。
<br>
<code>list</code> 格式如下
<br></p>
<pre class="hljs"><code>[{
  <span class="hljs-attr">url</span>: <span class="hljs-string">'javascript:'</span>,
  <span class="hljs-attr">img</span>: <span class="hljs-string">'https://static.vux.li/demo/1.jpg'</span>,
  <span class="hljs-attr">title</span>: <span class="hljs-string">'送你一朵fua'</span>
}, {
  <span class="hljs-attr">url</span>: <span class="hljs-string">'javascript:'</span>,
  <span class="hljs-attr">img</span>: <span class="hljs-string">'https://static.vux.li/demo/5.jpg'</span>,
  <span class="hljs-attr">title</span>: <span class="hljs-string">'送你一次旅行'</span>,
  <span class="hljs-attr">fallbackImg</span>: <span class="hljs-string">'https://static.vux.li/demo/3.jpg'</span>
}]
</code></pre>
<p><code>fallbackImg</code> 在 <code>v2.5.13</code> 支持，它将在 <code>img</code> 加载失败时显示，注意的是 <code>fallbackImg</code> 可能会在 <code>img</code> 加载成功时也进行了加载，只是不会显示（取决于浏览器实现）。</p>
</div>
<div class="warning">
<p>不要在<code>swiper</code>里嵌套<code>scroller</code>，在<code>web</code>上过于复杂化而且手势会有冲突，相关<code>Issue</code>将不会处理。
<br>
<br>
该组件场景是固定高度的内容列表，不支持为不同 swiper-item 设置不同高度。
<br>
<br>
如果确实需要设置不同高度，可以通过 ref 获取 swiper, 通过 this.$refs.swiper.xheight = '100px' 设置。 切记，需要放在 $nextTick 中执行。</p>
</div>

      </div>
      
      <a v-if="demos.length" class="anchor" id="examples">Examples</a>
      <br/>
      <template v-if="demos.length" v-for="demo in demos">
        <a class="anchor" :id="'examples:' + demo.title">{{ demo.title }}</a>
        <br/>
        <div class="demo-header">
          <span class="demo-title">{{ demo.title }}</span>
        </div>
        <div class="demos" :style="{height: demo.height}">
          <div class="demo-iframe-box">
            <lazy-component>
              <iframe
                :src="domain + '?no-background-color=' + demo.noBackgroundColor +'&locale=en&transition=none&hide-nav=true&hide-tab-bar=true#/components/' + demo.file"
                width="375"
                height="600"
                border="0"
                frameborder="0"
                style="margin: 0 auto;"></iframe>
            </lazy-component>
          </div>
          <div class="demo-code-box" :style="{overflow: demo.height === demo.oriHeight ? 'hidden' : 'scroll'}">
            <div v-html="demo.code" contenteditable></div>
            <div v-if="demo.height === demo.oriHeight" class="demo-code-masker" @click="demo.height='auto'">
              <div>
                  <img class="demo-qr" width="100" :src="'https://qr.vux.li/api.php?text=' + encodeURIComponent(domain + '?locale=en#/components/' + demo.file)"/>
                  <br/>
                  <span>
                    <el-icon class="el-icon-arrow-left"/>
                    <el-icon class="el-icon-arrow-right"/>
                    Show code
                  <br/>
                  <!--<span class="demo-path">src/demos/{{ demo.file }}.vue</span>-->
                </span>
              </div>
            </div>
            <span v-if="demo.height === 'auto'" class="hide-code" @click="demo.height=demo.oriHeight">
              <el-icon class="el-icon-close"></el-icon>
            </span>
          </div>
        </div>
      </template>

      <template v-for="component in componentList">
        <div>
          <a v-if="componentList.length > 1" class="anchor" :id="'components:' + component.name">{{ component.name }}</a>
          <a v-else class="anchor" id="api">API</a>
          <br/>
          <h2
            v-show="componentList.length > 1"
            class="vux-component-name-sub-item">{{ component.name }}</h2>
            
          <template v-if="component.meta.items && component.meta.description">
            <div v-html="component.meta.description"></div>
          </template>

          <template v-if="component.meta.props">
            <h2>Props</h2>
            <table>
              <thead>
                <tr>
                  <td>name</td>
                  <td style="width:48px;">type</td>
                  <td>default</td>
                  <td>description</td>
                  <td>required version</td>
                </tr>
              </thead>
              <tbody>
                <tr v-for="(prop, i) in component.meta.props">
                  <td class="prop-name">
                    <el-tooltip content="click to copy" placement="left" :hide-after="0" :open-delay="50">
                      <span
                      v-clipboard:copy="i"
                      v-clipboard:success="onCopy">{{ i }}</span>
                    </el-tooltip>
                  </td>
                  <td v-html="getTypeHTML(prop.type)"></td>
                  <td>{{ prop.default}}</td>
                  <td v-html="prop['en'].replace(/`(.*?)`/g, '<code>$1</code>')"></td>
                  <td>{{ prop.version || '--'}}</td>
                </tr>
              </tbody>
            </table>
          </template>

          <template v-if="component.meta.events">
            <h2>Events</h2>
            <table>
              <thead>
                <tr>
                  <td>name</td>
                  <td>params</td>
                  <td>description</td>
                  <td>required version</td>
                </tr>
              </thead>
              <tbody>
                <tr v-for="(event, i) in component.meta.events">
                  <td class="prop-name">
                    <el-tooltip content="click to copy" placement="left" :hide-after="0" :open-delay="50">
                      <span
                      v-clipboard:copy="'@' + i"
                      v-clipboard:success="onCopy">@{{ i }}</span>
                    </el-tooltip>
                  </td>
                  <td v-html="event.params ? event.params.replace(/`(.*?)`/g, '<code>$1</code>') : '--'"></td>
                  <td v-html="event['en'] ? event['en'].replace(/`(.*?)`/g, '<code>$1</code>') : '--'"></td>
                  <td>{{ event['version'] || '--' }}</td>
                </tr>
              </tbody>
            </table>
          </template>
      

          <template v-if="component.meta.slots">
            <h2>Slots</h2>
            <table>
              <thead>
                <tr>
                  <td>name</td>
                  <td>description</td>
                  <td>required version</td>
                </tr>
              </thead>
              <tbody>
                <tr v-for="(slot, i) in component.meta.slots" :class="{'slot-disabled': slot['status'] === 'deprecated'}">
                  <td class="prop-name">
                    <el-tooltip content="click to copy" placement="left" :hide-after="0" :open-delay="50">
                      <span
                      v-clipboard:copy="i"
                      v-clipboard:success="onCopy">{{ i === 'default' ? 'default' : i }}</span>
                    </el-tooltip>
                  </td>
                  <td v-html="slot['en'] ? slot['en'].replace(/`(.*?)`/g, '<code>$1</code>') : ''"></td>
                  <td>{{ slot['version'] || '--' }}</td>
                </tr>
              </tbody>
            </table>
          </template>
          
          <template v-if="component.meta.methods">
            <h2>Functions</h2>
            <table>
              <thead>
                <tr>
                  <td>name</td>
                  <td>params</td>
                  <td>description</td>
                  <td>required version</td>
                </tr>
              </thead>
              <tbody>
                <tr v-for="(method, i) in component.meta.methods">
                  <td class="prop-name">
                    <el-tooltip content="click to copy" placement="left" :hide-after="0" :open-delay="50">
                      <span
                      v-clipboard:copy="i"
                      v-clipboard:success="onCopy">{{ i }}</span>
                    </el-tooltip>
                  </td>
                  <td v-html="method['params'] ? method['params'].replace(/`(.*?)`/g, '<code>$1</code>') : ''"></td>
                  <td v-html="method['en'].replace(/`(.*?)`/g, '<code>$1</code>')"></td>
                  <td>{{ method['version'] }}</td>
                </tr>
              </tbody>
            </table>
          </template>

          <template v-if="component.meta.variables">
            <a class="anchor" id="variables">Variables</a>
            <br/>
            <h2>Variables</h2>
            <table>
              <thead>
                <tr>
                  <td>name</td>
                  <td>default</td>
                  <td>description</td>
                  <td>inherited name</td>
                </tr>
              </thead>
              <tbody>
                <tr v-for="(variable, i) in component.meta.variables">
                  <td class="prop-name">
                    <el-tooltip content="click to copy" placement="left" :hide-after="0" :open-delay="50">
                      <span
                      v-clipboard:copy="'@' + variable.name"
                      v-clipboard:success="onCopy">@{{ variable.name }}</span>
                    </el-tooltip>
                  </td>
                  <td>
                    <em
                      :ref="'propColor' + i"
                      v-if="!$refs['propColor' + i] || ($refs['propColor' + i][0] && $refs['propColor' + i][0].style.backgroundColor)"
                      class="prop-color"
                      :style="{ backgroundColor: variable.value }">
                    </em>
                    {{ variable.value }}
                  </td>
                  <td>{{ variable['desc']['en'] || '--' }}</td>
                  <td>{{ variable.inherited_name }}</td>
                </tr>
              </tbody>
            </table>
          </template>
      
          <template v-if="component.meta.tips && component.meta.tips['en']">
            <a class="anchor" id="tips">Tips</a>
            <br>
            <h2>Tips</h2>
            <div>
              <ul>
                <li v-for="tip in component.meta.tips['en']">
                <el-tag size="mini" type="success" class="component-tip-tag">Q</el-tag> <span class="component-tip-question">{{ tip.q }}</span>
                <div v-html="tip.a" class="tip-answer-box"></div>
                </li>
              </ul>
            </div>
          </template>
        </div>
      </template>

      <!--<h2>社区相关讨论</h2>
      [即将上线]
      -->
    
      <br>
      <div v-if="issues.length">
        <a class="anchor" id="Issues">Issues</a>
        <br/>
        <h2>Related issues</h2>
        <ul>
          <li v-for="issue in issues"><a target="_blank" :href="issue.html_url">#{{ issue.number}} <span style="color:#666;">{{ issue.title }}</span></a></li>
        </ul>
      </div>
      <br>
    
      <div v-if="gitMetas">
        <a class="anchor" id="contributors">Contributors</a>
        <h2>Contributors</h2>
        <p>Total commits quantity: {{ gitMetas.commitCount }}，Total contributors quantity: {{gitMetas.commitUniqueCount}}
        </p>
        <a v-for="person in gitMetas.commitMembers" class="contributor-item" :href="'https://github.com/' + person.authorName" target="_blank" :title="'contribute' + person.count">{{person.authorName}}</a>
      </div>
      <br>

      <div v-if="metas.changes">
        <a class="anchor" id="changelog">Changelog</a>
        <br/>
        <h2>Releases</h2>
        <ul v-if="metas.changes">
          <template v-for="(changelog, version) in metas.changes">
            <li v-for="log in changelog['en']">
              <router-link :to="'/en/changelog/' + version + '.html'" class="changelog-version">{{version}}</router-link> {{log}}
            </li>
          </template>
        </ul>
      </div>

      <h2 v-if="metas.references">Referrences</h2>
      <ul v-if="metas.references">
        <li v-for="link in metas.references['en']">
          <a :href="link.link" target="_blank">{{link.title}}</a>
        </li>
      </ul>

      <el-dialog
        class="sourcec-code-dialog"
        top="0"
        width="80%"
        :visible.sync="sourceCodeDialogVisibility">
        <div class="code-box" contenteditable v-html="demoCode"></div>
      </el-dialog>

    </div>
  </template>


  <script>
  import Axios from 'axios'

  // const metas = require('json-loader!yaml-loader!../../../src/components/swiper/metas.yml')
  const metas = {
  "category": {
    "en": "Data Display",
    "zh-CN": "数据展示"
  },
  "icon": "&#xe612;",
  "extra": "::: tip\n  `list`为图片列表快捷设置，如果你需要自定义一些样式，或者内容并不为纯图片，可以引用`swiper-item`组件来自定义。\n  <br>\n  `list` 格式如下\n  <br>\n\n  ``` js\n  [{\n    url: 'javascript:',\n    img: 'https://static.vux.li/demo/1.jpg',\n    title: '送你一朵fua'\n  }, {\n    url: 'javascript:',\n    img: 'https://static.vux.li/demo/5.jpg',\n    title: '送你一次旅行',\n    fallbackImg: 'https://static.vux.li/demo/3.jpg'\n  }]\n  ```\n\n  `fallbackImg` 在 `v2.5.13` 支持，它将在 `img` 加载失败时显示，注意的是 `fallbackImg` 可能会在 `img` 加载成功时也进行了加载，只是不会显示（取决于浏览器实现）。\n\n:::\n\n::: warning\n不要在`swiper`里嵌套`scroller`，在`web`上过于复杂化而且手势会有冲突，相关`Issue`将不会处理。\n<br>\n<br>\n该组件场景是固定高度的内容列表，不支持为不同 swiper-item 设置不同高度。\n<br>\n<br>\n如果确实需要设置不同高度，可以通过 ref 获取 swiper, 通过 this.$refs.swiper.xheight = '100px' 设置。 切记，需要放在 $nextTick 中执行。\n:::\n",
  "tips": {
    "zh-CN": [
      {
        "q": "swiper-item 只有两项时无法循环播放",
        "a": "<p>是的，建议直接使用 <code>list</code> 来实现循环。因为实现原理是对<code>swiper-item</code>元素进行移动，需要至少有<code>3</code>个<code>swiper-item</code>才能保证有上一张和下一张可以切换。</p>\n"
      }
    ]
  },
  "props": {
    "list": {
      "type": "Array",
      "en": "image list, use swiper-item if you need to customize style",
      "zh-CN": "轮播图片列表，如果有自定义样式需求，请使用 swiper-item(使用 swiper-item 时仅有2个的情况下不支持循环)"
    },
    "direction": {
      "type": "String",
      "default": "horizontal",
      "en": "swiping direction",
      "zh-CN": "方向"
    },
    "show-dots": {
      "type": "Boolean",
      "default": true,
      "en": "if show indicators",
      "zh-CN": "是否显示提示点"
    },
    "show-desc-mask": {
      "type": "Boolean",
      "default": true,
      "en": "if show description mask",
      "zh-CN": "是否显示描述半透明遮罩"
    },
    "dots-position": {
      "type": "String",
      "default": "right",
      "en": "indicator position",
      "zh-CN": "提示点位置"
    },
    "dots-class": {
      "en": "custom indicator's classname",
      "zh-CN": "提示className"
    },
    "auto": {
      "type": "Boolean",
      "default": false,
      "en": "if auto playing",
      "zh-CN": "是否自动轮播"
    },
    "loop": {
      "type": "Boolean",
      "default": false,
      "en": "if use loop mode",
      "zh-CN": "是否循环"
    },
    "interval": {
      "type": "Number",
      "default": 3000,
      "en": "interval value",
      "zh-CN": "轮播停留时长"
    },
    "threshold": {
      "type": "Number",
      "default": 50,
      "en": "threshold value",
      "zh-CN": "当滑动超过这个距离时才滑动"
    },
    "duration": {
      "type": "Number",
      "default": 300,
      "en": "transition duration",
      "zh-CN": "切换动画时间"
    },
    "height": {
      "type": "String",
      "default": "180px",
      "en": "height value",
      "zh-CN": "高度值。如果为`100%`宽度并且知道宽高比，可以设置`aspect-ratio`自动计算高度"
    },
    "aspect-ratio": {
      "type": "Number",
      "en": "if specified, height will be caculated automatically",
      "zh-CN": "用以根据当前可用宽度计算高度值"
    },
    "min-moving-distance": {
      "type": "Number",
      "default": 0,
      "en": "min distance before moving",
      "zh-CN": "超过这个距离时才滑动"
    },
    "v-model": {
      "type": "Number",
      "default": 0,
      "en": "index value, use `v-model` for binding",
      "zh-CN": "index 绑定，使用`v-model`，一般不需要绑定"
    }
  },
  "events": {
    "on-index-change": {
      "params": "`(currentIndex)`",
      "en": "fires when index is changed",
      "zh-CN": "轮播 index 变化时触发"
    },
    "on-get-height": {
      "version": "v2.7.0",
      "params": "`(height)`",
      "en": "fires after height is caculated",
      "zh-CN": "高度获取后触发"
    }
  },
  "changes": {
    "v2.9.2": {
      "en": [
        "[fix] fix stuck swipe after setting min-moving-distance #2773",
        "[fix] fix error for repeat setting data in loop #2803"
      ],
      "zh-CN": [
        "[fix] 修复设置最小移动距离后滑动卡住 #2773",
        "[fix] 修复在循环模式下重复设置数据的错误 #2803"
      ]
    },
    "v2.7.7": {
      "en": [
        "[fix] fix cannot scroll body when touching with one item"
      ],
      "zh-CN": [
        "[fix] 修复只有一个 item 时无法滚动页面的问题"
      ]
    },
    "v2.7.6": {
      "en": [
        "[enhance] stop moving width one item"
      ],
      "zh-CN": [
        "[enhance] 只有一张图片时阻止滑动跟随"
      ]
    },
    "v2.7.0": {
      "en": [
        "[enhance] set shorter distance for first and last item for better experience",
        "[feature] add event:on-get-height #2112",
        "[enhance] stop interval if auto is set to false #2027"
      ],
      "zh-CN": [
        "[enhance] 非循环模式下对第一张和最后一张使用更短的拖动距离",
        "[feature] 添加事件 event:on-get-height #2112",
        "[enhance] auto 支持动态设置 #2027"
      ]
    },
    "v2.6.0": {
      "en": [
        "[enhance] support fallbackImg for prop:list #1923"
      ],
      "zh-CN": [
        "[enhance] 支持 list.fallbackImg 属性在图片加载失败时显示预设图片 #1923"
      ]
    },
    "v2.5.3": {
      "en": [
        "[fix] clear listTtwoLoopItem when list size !== 2 #1684 @weizs"
      ],
      "zh-CN": [
        "[fix] 轮播个数不为2时清除 listTtwoLoopItem 列表 #1684 @weizs"
      ]
    },
    "v2.5.1": {
      "en": [
        "[fix] Fix array-from issue with webpack@3 #1649"
      ],
      "zh-CN": [
        "[fix] 修复 array-from 在 webpack@3 下报错问题 #1649"
      ]
    },
    "v2.3.5": {
      "en": [
        "[fix] Fix repeat render bug #1458"
      ],
      "zh-CN": [
        "[fix] 修复重复渲染问题 #1458"
      ]
    },
    "v2.3.4": {
      "en": [
        "[fix] Fix click to fail when only two swiper-item and loop #1484 @unclay"
      ],
      "zh-CN": [
        "[fix] 修复只有两个轮播图且为 loop 时点击失效问题 #1484 @unclay"
      ]
    },
    "v2.2.1-rc.2": {
      "en": [
        "[enhance] Use document width as swiper width if initial width is 0 #1188",
        "[fix] Fix initial index > 0 not works"
      ],
      "zh-CN": [
        "[enhance] 如果初始化时获取不到宽度则直接使用视口宽度 #1188",
        "[fix] 修复初始化时 index > 0 不生效"
      ]
    },
    "v2.1.1-rc.3": {
      "en": [
        "[fix] Fix nodes list forEach function is undefined #991 @howyhuang"
      ],
      "zh-CN": [
        "[fix] 修复 node 列表没有 forEach 方法 #991 @howyhuang"
      ]
    },
    "v2.1.1-rc.2": {
      "en": [
        "[fix] Fix es6 iterator compability, use forEach"
      ],
      "zh-CN": [
        "[fix] 修复部分机子不支持 for of 遍历"
      ]
    }
  },
  "variables": [
    {
      "name": "swiper-indicator-active-color",
      "value": "#04BE02",
      "is_inherited": true,
      "inherited_name": "@theme-color",
      "desc": {}
    }
  ]
}
  const demos = []

  let componentList = []
  if (Array.isArray(metas.items)) {
    try {
      metas.items.forEach((item, index) => {
        const meta = {
          name: item,
          meta: metas[item]
        }
        if (meta.meta.props === null) {
          delete meta.meta.props
        }
        if (index === metas.items.length - 1) {
          if (meta.meta) {
            meta.meta.variables = metas.variables
          }
        }
        componentList.push(meta)
      })
    } catch (e) {
      console.log(e)
    }
  } else {
    componentList.push({
      meta: metas
    })
  }
  const gitMetas = require('./swiper_git_metas.json')
  const demoCode = decodeURIComponent(`%3Cpre%20class%3D%22hljs%22%3E%3Ccode%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Etemplate%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ediv%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Egroup-title%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3ETHX%20to%3A%20https%3A%2F%2Fgithub.com%2Fwechatui%2Fswiper%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Egroup-title%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Egroup-title%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3Elist%E6%A8%A1%E5%BC%8F%E4%B8%8B%EF%BC%8C%E9%BB%98%E8%AE%A4%E9%AB%98%E5%BA%A6%E4%B8%BA180px%2C%20%E5%A6%82%E6%9E%9C%E8%AE%BE%E7%BD%AEaspect-ratio%E4%BC%9A%E6%A0%B9%E6%8D%AE%E5%AE%BD%E5%BA%A6%E8%87%AA%E5%8A%A8%E8%AE%A1%E7%AE%97%E9%AB%98%E5%BA%A6%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Egroup-title%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Eswiper%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Alist%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22demo01_list%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Ev-model%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22demo01_index%22%3C%2Fspan%3E%20%40%3Cspan%20class%3D%22hljs-attr%22%3Eon-index-change%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22demo01_onIndexChange%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Eswiper%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ep%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Eclass%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22copyright%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3EImage%20Source%3A%20http%3A%2F%2Fwww.gratisography.com%2F%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ep%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ep%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3Ecurrent%20index%3A%20%7B%7Bdemo01_index%7D%7D%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ep%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ex-button%3C%2Fspan%3E%20%40%3Cspan%20class%3D%22hljs-attr%22%3Eclick.native%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22demo01_index%20%3D%200%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3Ego%20to%200%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ex-button%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ex-button%3C%2Fspan%3E%20%40%3Cspan%20class%3D%22hljs-attr%22%3Eclick.native%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22demo01_index%20%3D%201%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3Ego%20to%201%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ex-button%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ex-button%3C%2Fspan%3E%20%40%3Cspan%20class%3D%22hljs-attr%22%3Eclick.native%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22demo01_index%20%3D%202%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3Ego%20to%202%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ex-button%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ebr%3C%2Fspan%3E%2F%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ebr%3C%2Fspan%3E%2F%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Edivider%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%E5%8D%8E%E4%B8%BD%E7%9A%84%E5%88%86%E5%89%B2%E7%BA%BF%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Edivider%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Egroup-title%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%E8%AE%BE%E7%BD%AEmin-moving-distance%E4%B8%BA120%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Egroup-title%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Eswiper%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Alist%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22demo01_list%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Ev-model%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22demo02_index%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Amin-moving-distance%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22120%22%3C%2Fspan%3E%20%40%3Cspan%20class%3D%22hljs-attr%22%3Eon-index-change%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22demo01_onIndexChange%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Eswiper%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ebr%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ebr%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Edivider%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%E5%8D%8E%E4%B8%BD%E7%9A%84%E5%88%86%E5%89%B2%E7%BA%BF%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Edivider%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%0A%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Egroup-title%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%E8%AE%BE%E7%BD%AEaspect-ratio%2C%20%E5%B0%86%E8%87%AA%E5%8A%A8%E6%A0%B9%E6%8D%AE%E5%AE%BD%E5%BA%A6%E8%AE%A1%E7%AE%97%E9%AB%98%E5%BA%A6%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Egroup-title%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Eswiper%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Alist%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22demo02_list%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Estyle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22width%3A85%25%3Bmargin%3A0%20auto%3B%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Aaspect-ratio%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22300%2F800%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Edots-position%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22center%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Eswiper%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ebr%3C%2Fspan%3E%2F%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ebr%3C%2Fspan%3E%2F%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Edivider%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%E5%8D%8E%E4%B8%BD%E7%9A%84%E5%88%86%E5%89%B2%E7%BA%BF%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Edivider%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Egroup-title%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%E8%87%AA%E5%8A%A8%E8%BD%AE%E6%92%AD%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Egroup-title%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Eswiper%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Alist%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22demo03_list%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Eauto%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Estyle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22width%3A80%25%3Bmargin%3A0%20auto%3B%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Eheight%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22180px%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Edots-class%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22custom-bottom%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Edots-position%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22center%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Eswiper%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ebr%3C%2Fspan%3E%2F%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ebr%3C%2Fspan%3E%2F%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Edivider%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%E5%8D%8E%E4%B8%BD%E7%9A%84%E5%88%86%E5%89%B2%E7%BA%BF%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Edivider%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Egroup-title%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3Euse%20swiper-item%20for%20image%20list%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Egroup-title%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Eswiper%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Aaspect-ratio%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22300%2F800%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Eswiper-item%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Eclass%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22swiper-demo-img%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Ev-for%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22(item%2C%20index)%20in%20demo04_list%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Akey%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22index%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Eimg%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Asrc%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22item%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Eswiper-item%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Eswiper%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ebr%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ebr%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Egroup-title%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3Eset%20index%20%3D%201%20with%20swiper-item%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Egroup-title%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Eswiper%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Aaspect-ratio%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22300%2F800%22%3C%2Fspan%3E%20%40%3Cspan%20class%3D%22hljs-attr%22%3Eon-index-change%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22onSwiperItemIndexChange%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Ev-model%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22swiperItemIndex%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Eswiper-item%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Eclass%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22swiper-demo-img%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Ev-for%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22(item%2C%20index)%20in%20demo04_list%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Akey%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22index%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Eimg%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Asrc%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22item%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Eswiper-item%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Eswiper%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ebr%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%7B%7B%20swiperItemIndex%20%7D%7D%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ebr%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ex-button%3C%2Fspan%3E%20%40%3Cspan%20class%3D%22hljs-attr%22%3Eclick.native%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22swiperItemIndex%20%3D%200%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3Ego%20to%200%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ex-button%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ex-button%3C%2Fspan%3E%20%40%3Cspan%20class%3D%22hljs-attr%22%3Eclick.native%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22swiperItemIndex%20%3D%201%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3Ego%20to%201%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ex-button%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ex-button%3C%2Fspan%3E%20%40%3Cspan%20class%3D%22hljs-attr%22%3Eclick.native%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22swiperItemIndex%20%3D%202%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3Ego%20to%202%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ex-button%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%0A%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ebr%3C%2Fspan%3E%2F%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ebr%3C%2Fspan%3E%2F%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Edivider%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%E5%8D%8E%E4%B8%BD%E7%9A%84%E5%88%86%E5%89%B2%E7%BA%BF%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Edivider%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Egroup-title%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3EAsync%20setting%20list%20data%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Egroup-title%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Eswiper%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Alist%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22demo05_list%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Eauto%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Eheight%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22180px%22%3C%2Fspan%3E%20%40%3Cspan%20class%3D%22hljs-attr%22%3Eon-index-change%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22demo05_onIndexChange%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Eswiper%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ep%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%20current%20index%3A%20%7B%7Bdemo05_index%7D%7D%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ep%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ex-button%3C%2Fspan%3E%20%40%3Cspan%20class%3D%22hljs-attr%22%3Eclick.native%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22demo05_onLoad(1)%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Etype%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22primary%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Estyle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22margin%3A%2010px%200%3B%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3ELoad%20list1%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ex-button%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ex-button%3C%2Fspan%3E%20%40%3Cspan%20class%3D%22hljs-attr%22%3Eclick.native%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22demo05_onLoad(2)%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Etype%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22primary%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Estyle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22margin%3A%2010px%200%3B%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3ELoad%20list2%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ex-button%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ebr%3C%2Fspan%3E%2F%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ebr%3C%2Fspan%3E%2F%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Edivider%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%E5%8D%8E%E4%B8%BD%E7%9A%84%E5%88%86%E5%89%B2%E7%BA%BF%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Edivider%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Egroup-title%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%E5%BC%95%E5%85%A5swiper-item%E8%87%AA%E5%AE%9A%E4%B9%89item%E5%86%85%E5%AE%B9%EF%BC%8C%E7%94%A8height%E5%AE%9A%E4%B9%89%E9%AB%98%E5%BA%A6%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Egroup-title%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Eswiper%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Eauto%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Eheight%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22100px%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Eswiper-item%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Eclass%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22black%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Eh2%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Eclass%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22title%20fadeInUp%20animated%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%E5%AE%83%E6%97%A0%E5%AD%94%E4%B8%8D%E5%85%A5%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Eh2%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Eswiper-item%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Eswiper-item%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Eclass%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22black%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Eh2%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Eclass%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22title%20fadeInUp%20animated%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%E4%BD%A0%E6%97%A0%E5%A4%84%E5%8F%AF%E8%97%8F%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Eh2%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Eswiper-item%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Eswiper-item%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Eclass%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22black%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Eh2%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Eclass%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22title%20fadeInUp%20animated%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%E4%B8%8D%E6%98%AF%E5%AE%83%E5%8F%AF%E6%81%B6%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Eh2%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Eswiper-item%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Eswiper-item%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Eclass%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22black%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Eh2%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Eclass%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22title%20fadeInUp%20animated%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%E8%80%8C%E6%98%AF%E5%AE%83%E4%B8%8D%E6%87%82%E4%BD%A0%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Eh2%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Eswiper-item%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Eswiper-item%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Eclass%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22black%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Eh2%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Eclass%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22title%20fadeInUp%20animated%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%E6%88%91%E4%BB%AC%E8%AF%95%E5%9B%BE%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Eh2%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Eswiper-item%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Eswiper-item%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Eclass%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22black%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Eh2%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Eclass%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22title%20fadeInUp%20animated%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%E5%81%9A%E4%BA%9B%E6%94%B9%E5%8F%98%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Eh2%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Eswiper-item%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Eswiper%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ebr%3C%2Fspan%3E%2F%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ebr%3C%2Fspan%3E%2F%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Edivider%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%E5%8D%8E%E4%B8%BD%E7%9A%84%E5%88%86%E5%89%B2%E7%BA%BF%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Edivider%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Egroup-title%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%E5%9E%82%E7%9B%B4%E6%96%B9%E5%90%91%E6%96%87%E5%AD%97%E6%BB%9A%E5%8A%A8%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Egroup-title%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Eswiper%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Eauto%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Eheight%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%2230px%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Edirection%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22vertical%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Ainterval%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E2000%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Eclass%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22text-scroll%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Ashow-dots%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22false%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Eswiper-item%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ep%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%E4%B9%89%E5%8A%A1%E7%88%B1%E4%BA%86%20%E5%AE%8C%E6%88%90%E4%BC%A0%E5%A5%87%E4%B8%96%E7%95%8CH5-%E7%8E%8B%E8%80%85%E5%BD%92%E6%9D%A5%E4%BB%BB%E5%8A%A1%20%E8%8E%B7%E5%BE%9720%E9%87%91%E5%B8%81%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ep%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Eswiper-item%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Eswiper-item%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ep%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%E5%9F%BA%E6%9C%AC%E4%B8%96%E7%A5%9E%20%E5%85%91%E6%8D%A2%E3%80%8A%E4%BC%A0%E5%A5%87%E4%B8%96%E7%95%8CH5%E3%80%8B%E7%95%85%E7%8E%A9%E7%BA%A7%E7%A4%BC%E5%8C%85%20%E6%B6%88%E8%80%9730%E9%87%91%E5%B8%81%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ep%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Eswiper-item%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Eswiper-item%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ep%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%E9%9B%B6%E5%93%A5%E7%AB%A0%E9%AD%9A%20%E5%AE%8C%E6%88%90%E4%BC%A0%E5%A5%87%E4%B8%96%E7%95%8CH5-%E7%8E%8B%E8%80%85%E5%BD%92%E6%9D%A5%E4%BB%BB%E5%8A%A1%20%E8%8E%B7%E5%BE%9730%E9%87%91%E5%B8%81%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ep%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Eswiper-item%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Eswiper-item%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ep%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%E5%81%9A%E8%BF%8E%E8%80%8C%E7%82%BA%20%E5%85%91%E6%8D%A2%E3%80%90%E9%A5%BF%E4%BA%86%E4%B9%88%E3%80%91%E7%95%85%E4%BA%AB%E7%BE%8E%E9%A3%9F%E7%BA%A2%E5%8C%85%20%E6%B6%88%E8%80%9720%E9%87%91%E5%B8%81%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ep%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Eswiper-item%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Eswiper-item%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ep%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%E5%8F%AA%E7%9F%A5%E9%81%93%E4%B8%8D%E7%9F%A5%E9%81%93%20%E5%85%91%E6%8D%A2%E3%80%90%E9%A5%BF%E4%BA%86%E4%B9%88%E3%80%91%E7%95%85%E4%BA%AB%E7%BE%8E%E9%A3%9F%E7%BA%A2%E5%8C%85%20%E6%B6%88%E8%80%9720%E9%87%91%E5%B8%81%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ep%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Eswiper-item%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Eswiper-item%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ep%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%E5%9F%BA%E6%9C%AC%E4%B8%96%E7%A5%9E%20%E5%85%91%E6%8D%A2%E3%80%8A%E4%BC%A0%E5%A5%87%E4%B8%96%E7%95%8CH5%E3%80%8B%E7%95%85%E7%8E%A9%E7%BA%A7%E7%A4%BC%E5%8C%85%20%E6%B6%88%E8%80%9730%E9%87%91%E5%B8%81%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ep%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Eswiper-item%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Eswiper%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ebr%3C%2Fspan%3E%2F%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ebr%3C%2Fspan%3E%2F%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Edivider%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%E5%8D%8E%E4%B8%BD%E7%9A%84%E5%88%86%E5%89%B2%E7%BA%BF%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Edivider%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Egroup-title%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%E5%BE%AA%E7%8E%AF%E6%A8%A1%E5%BC%8F%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Egroup-title%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Eswiper%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Eloop%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Eauto%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Alist%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22demo06_list%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Aindex%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22demo06_index%22%3C%2Fspan%3E%20%40%3Cspan%20class%3D%22hljs-attr%22%3Eon-index-change%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22demo06_onIndexChange%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Eswiper%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ep%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3Ecurrent%20index%3A%20%7B%7Bdemo06_index%7D%7D%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ep%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Egroup-title%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%E5%BE%AA%E7%8E%AF%E6%A8%A1%E5%BC%8F%EF%BC%88%E5%8F%AA%E6%9C%89%E4%B8%A4%E4%B8%AA%E4%B8%94%E5%8F%AF%E7%82%B9%E5%87%BB%EF%BC%89%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Egroup-title%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Eswiper%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Eloop%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Eauto%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Alist%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22demo07_list%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Aindex%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22demo07_index%22%3C%2Fspan%3E%20%40%3Cspan%20class%3D%22hljs-attr%22%3Eon-index-change%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22demo07_onIndexChange%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Eswiper%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ep%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3Ecurrent%20index%3A%20%7B%7Bdemo07_index%7D%7D%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ep%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ediv%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Etemplate%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%0A%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Escript%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22javascript%22%3E%0A%3Cspan%20class%3D%22hljs-keyword%22%3Eimport%3C%2Fspan%3E%20%7B%20Swiper%2C%20GroupTitle%2C%20SwiperItem%2C%20XButton%2C%20Divider%20%7D%20%3Cspan%20class%3D%22hljs-keyword%22%3Efrom%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-string%22%3E'vux'%3C%2Fspan%3E%0A%0A%3Cspan%20class%3D%22hljs-keyword%22%3Econst%3C%2Fspan%3E%20baseList%20%3D%20%5B%7B%0A%20%20%3Cspan%20class%3D%22hljs-attr%22%3Eurl%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-string%22%3E'javascript%3A'%3C%2Fspan%3E%2C%0A%20%20%3Cspan%20class%3D%22hljs-attr%22%3Eimg%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-string%22%3E'https%3A%2F%2Fww1.sinaimg.cn%2Flarge%2F663d3650gy1fq66vvsr72j20p00gogo2.jpg'%3C%2Fspan%3E%2C%0A%20%20%3Cspan%20class%3D%22hljs-attr%22%3Etitle%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-string%22%3E'%E9%80%81%E4%BD%A0%E4%B8%80%E6%9C%B5fua'%3C%2Fspan%3E%0A%7D%2C%20%7B%0A%20%20%3Cspan%20class%3D%22hljs-attr%22%3Eurl%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-string%22%3E'javascript%3A'%3C%2Fspan%3E%2C%0A%20%20%3Cspan%20class%3D%22hljs-attr%22%3Eimg%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-string%22%3E'https%3A%2F%2Fww1.sinaimg.cn%2Flarge%2F663d3650gy1fq66vw1k2wj20p00goq7n.jpg'%3C%2Fspan%3E%2C%0A%20%20%3Cspan%20class%3D%22hljs-attr%22%3Etitle%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-string%22%3E'%E9%80%81%E4%BD%A0%E4%B8%80%E8%BE%86%E8%BD%A6'%3C%2Fspan%3E%0A%7D%2C%20%7B%0A%20%20%3Cspan%20class%3D%22hljs-attr%22%3Eurl%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-string%22%3E'javascript%3A'%3C%2Fspan%3E%2C%0A%20%20%3Cspan%20class%3D%22hljs-attr%22%3Eimg%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-string%22%3E'https%3A%2F%2Fstatic.vux.li%2Fdemo%2F5.jpg'%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-comment%22%3E%2F%2F%20404%3C%2Fspan%3E%0A%20%20title%3A%20%3Cspan%20class%3D%22hljs-string%22%3E'%E9%80%81%E4%BD%A0%E4%B8%80%E6%AC%A1%E6%97%85%E8%A1%8C'%3C%2Fspan%3E%2C%0A%20%20%3Cspan%20class%3D%22hljs-attr%22%3EfallbackImg%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-string%22%3E'https%3A%2F%2Fww1.sinaimg.cn%2Flarge%2F663d3650gy1fq66vw50iwj20ff0aaaci.jpg'%3C%2Fspan%3E%0A%7D%5D%0A%0A%3Cspan%20class%3D%22hljs-keyword%22%3Econst%3C%2Fspan%3E%20imgList%20%3D%20%5B%0A%20%20%3Cspan%20class%3D%22hljs-string%22%3E'http%3A%2F%2Fplaceholder.qiniudn.com%2F800x300%2FFF3B3B%2Fffffff'%3C%2Fspan%3E%2C%0A%20%20%3Cspan%20class%3D%22hljs-string%22%3E'http%3A%2F%2Fplaceholder.qiniudn.com%2F800x300%2FFFEF7D%2Fffffff'%3C%2Fspan%3E%2C%0A%20%20%3Cspan%20class%3D%22hljs-string%22%3E'http%3A%2F%2Fplaceholder.qiniudn.com%2F800x300%2F8AEEB1%2Fffffff'%3C%2Fspan%3E%0A%5D%0A%0A%3Cspan%20class%3D%22hljs-keyword%22%3Econst%3C%2Fspan%3E%20urlList%20%3D%20baseList.map(%3Cspan%20class%3D%22hljs-function%22%3E(%3Cspan%20class%3D%22hljs-params%22%3Eitem%2C%20index%3C%2Fspan%3E)%20%3D%26gt%3B%3C%2Fspan%3E%20(%7B%0A%20%20%3Cspan%20class%3D%22hljs-attr%22%3Eurl%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-string%22%3E'http%3A%2F%2Fm.baidu.com'%3C%2Fspan%3E%2C%0A%20%20%3Cspan%20class%3D%22hljs-attr%22%3Eimg%3C%2Fspan%3E%3A%20item.img%2C%0A%20%20%3Cspan%20class%3D%22hljs-attr%22%3EfallbackImg%3C%2Fspan%3E%3A%20item.fallbackImg%2C%0A%20%20%3Cspan%20class%3D%22hljs-attr%22%3Etitle%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-string%22%3E%60(%E5%8F%AF%E7%82%B9%E5%87%BB)%3Cspan%20class%3D%22hljs-subst%22%3E%24%7Bitem.title%7D%3C%2Fspan%3E%60%3C%2Fspan%3E%0A%7D))%0A%0A%3Cspan%20class%3D%22hljs-keyword%22%3Econst%3C%2Fspan%3E%20demoList%20%3D%20imgList.map(%3Cspan%20class%3D%22hljs-function%22%3E(%3Cspan%20class%3D%22hljs-params%22%3Eone%2C%20index%3C%2Fspan%3E)%20%3D%26gt%3B%3C%2Fspan%3E%20(%7B%0A%20%20%3Cspan%20class%3D%22hljs-attr%22%3Eurl%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-string%22%3E'javascript%3A'%3C%2Fspan%3E%2C%0A%20%20%3Cspan%20class%3D%22hljs-attr%22%3Eimg%3C%2Fspan%3E%3A%20one%0A%7D))%0A%0A%3Cspan%20class%3D%22hljs-keyword%22%3Econst%3C%2Fspan%3E%20only2ClickList%20%3D%20baseList.slice(%3Cspan%20class%3D%22hljs-number%22%3E0%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-number%22%3E2%3C%2Fspan%3E).map(%3Cspan%20class%3D%22hljs-function%22%3E%3Cspan%20class%3D%22hljs-params%22%3Eitem%3C%2Fspan%3E%20%3D%26gt%3B%3C%2Fspan%3E%20%7B%0A%20%20item.url%20%3D%20%3Cspan%20class%3D%22hljs-string%22%3E'http%3A%2F%2Fm.baidu.com'%3C%2Fspan%3E%0A%20%20%3Cspan%20class%3D%22hljs-keyword%22%3Ereturn%3C%2Fspan%3E%20item%0A%7D)%0A%0A%3Cspan%20class%3D%22hljs-keyword%22%3Eexport%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-keyword%22%3Edefault%3C%2Fspan%3E%20%7B%0A%20%20%3Cspan%20class%3D%22hljs-attr%22%3Ecomponents%3C%2Fspan%3E%3A%20%7B%0A%20%20%20%20Swiper%2C%0A%20%20%20%20SwiperItem%2C%0A%20%20%20%20GroupTitle%2C%0A%20%20%20%20XButton%2C%0A%20%20%20%20Divider%0A%20%20%7D%2C%0A%20%20ready%20()%20%7B%0A%0A%20%20%7D%2C%0A%20%20%3Cspan%20class%3D%22hljs-attr%22%3Emethods%3C%2Fspan%3E%3A%20%7B%0A%20%20%20%20onSwiperItemIndexChange%20(index)%20%7B%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-built_in%22%3Econsole%3C%2Fspan%3E.log(%3Cspan%20class%3D%22hljs-string%22%3E'demo%20item%20change'%3C%2Fspan%3E%2C%20index)%0A%20%20%20%20%7D%2C%0A%20%20%20%20demo01_onIndexChange%20(index)%20%7B%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-keyword%22%3Ethis%3C%2Fspan%3E.demo01_index%20%3D%20index%0A%20%20%20%20%7D%2C%0A%20%20%20%20demo05_onIndexChange%20(index)%20%7B%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-keyword%22%3Ethis%3C%2Fspan%3E.demo05_index%20%3D%20index%0A%20%20%20%20%7D%2C%0A%20%20%20%20demo05_onLoad%20(id)%20%7B%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-keyword%22%3Ethis%3C%2Fspan%3E.demo05_list%20%3D%20id%20%3D%3D%3D%20%3Cspan%20class%3D%22hljs-number%22%3E1%3C%2Fspan%3E%20%3F%20baseList%20%3A%20demoList%0A%20%20%20%20%7D%2C%0A%20%20%20%20demo06_onIndexChange%20(index)%20%7B%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-keyword%22%3Ethis%3C%2Fspan%3E.demo06_index%20%3D%20index%0A%20%20%20%20%7D%2C%0A%20%20%20%20demo07_onIndexChange%20(index)%20%7B%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-keyword%22%3Ethis%3C%2Fspan%3E.demo07_index%20%3D%20index%0A%20%20%20%20%7D%0A%20%20%7D%2C%0A%20%20data%20()%20%7B%0A%20%20%20%20%3Cspan%20class%3D%22hljs-keyword%22%3Ereturn%3C%2Fspan%3E%20%7B%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3Edemo01_list%3C%2Fspan%3E%3A%20baseList%2C%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3Edemo02_list%3C%2Fspan%3E%3A%20demoList%2C%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3Edemo03_list%3C%2Fspan%3E%3A%20demoList%2C%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3Edemo04_list%3C%2Fspan%3E%3A%20imgList%2C%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3Edemo05_list%3C%2Fspan%3E%3A%20%5B%5D%2C%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3Edemo06_list%3C%2Fspan%3E%3A%20urlList%2C%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3Edemo07_list%3C%2Fspan%3E%3A%20only2ClickList%2C%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3Edemo01_index%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-number%22%3E0%3C%2Fspan%3E%2C%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3Edemo02_index%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-number%22%3E1%3C%2Fspan%3E%2C%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3Edemo05_index%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-number%22%3E0%3C%2Fspan%3E%2C%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3Edemo06_index%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-number%22%3E0%3C%2Fspan%3E%2C%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3Edemo07_index%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-number%22%3E0%3C%2Fspan%3E%2C%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3EswiperItemIndex%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-number%22%3E1%3C%2Fspan%3E%0A%20%20%20%20%7D%0A%20%20%7D%0A%7D%0A%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Escript%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%0A%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Estyle%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Escoped%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22css%22%3E%0A%3Cspan%20class%3D%22hljs-selector-class%22%3E.copyright%3C%2Fspan%3E%20%7B%0A%20%20%3Cspan%20class%3D%22hljs-attribute%22%3Efont-size%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-number%22%3E12px%3C%2Fspan%3E%3B%0A%20%20%3Cspan%20class%3D%22hljs-attribute%22%3Ecolor%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-number%22%3E%23ccc%3C%2Fspan%3E%3B%0A%20%20%3Cspan%20class%3D%22hljs-attribute%22%3Etext-align%3C%2Fspan%3E%3A%20center%3B%0A%7D%0A%3Cspan%20class%3D%22hljs-selector-class%22%3E.text-scroll%3C%2Fspan%3E%20%7B%0A%20%20%3Cspan%20class%3D%22hljs-attribute%22%3Eborder%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-number%22%3E1px%3C%2Fspan%3E%20solid%20%3Cspan%20class%3D%22hljs-number%22%3E%23ddd%3C%2Fspan%3E%3B%0A%20%20%3Cspan%20class%3D%22hljs-attribute%22%3Eborder-left%3C%2Fspan%3E%3A%20none%3B%0A%20%20%3Cspan%20class%3D%22hljs-attribute%22%3Eborder-right%3C%2Fspan%3E%3A%20none%3B%0A%7D%0A%3Cspan%20class%3D%22hljs-selector-class%22%3E.text-scroll%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-selector-tag%22%3Ep%3C%2Fspan%3E%7B%0A%20%20%3Cspan%20class%3D%22hljs-attribute%22%3Efont-size%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-number%22%3E12px%3C%2Fspan%3E%3B%0A%20%20%3Cspan%20class%3D%22hljs-attribute%22%3Etext-align%3C%2Fspan%3E%3A%20center%3B%0A%20%20%3Cspan%20class%3D%22hljs-attribute%22%3Eline-height%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-number%22%3E30px%3C%2Fspan%3E%3B%0A%7D%0A%3Cspan%20class%3D%22hljs-selector-class%22%3E.black%3C%2Fspan%3E%20%7B%0A%20%20%3Cspan%20class%3D%22hljs-attribute%22%3Ebackground-color%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-number%22%3E%23000%3C%2Fspan%3E%3B%0A%7D%0A%3Cspan%20class%3D%22hljs-selector-class%22%3E.title%3C%2Fspan%3E%7B%0A%20%20%3Cspan%20class%3D%22hljs-attribute%22%3Eline-height%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-number%22%3E100px%3C%2Fspan%3E%3B%0A%20%20%3Cspan%20class%3D%22hljs-attribute%22%3Etext-align%3C%2Fspan%3E%3A%20center%3B%0A%20%20%3Cspan%20class%3D%22hljs-attribute%22%3Ecolor%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-number%22%3E%23fff%3C%2Fspan%3E%3B%0A%7D%0A%3Cspan%20class%3D%22hljs-selector-class%22%3E.animated%3C%2Fspan%3E%20%7B%0A%20%20%3Cspan%20class%3D%22hljs-attribute%22%3Eanimation-duration%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-number%22%3E1s%3C%2Fspan%3E%3B%0A%20%20%3Cspan%20class%3D%22hljs-attribute%22%3Eanimation-fill-mode%3C%2Fspan%3E%3A%20both%3B%0A%7D%0A%3Cspan%20class%3D%22hljs-selector-class%22%3E.vux-indicator%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-selector-class%22%3E.custom-bottom%3C%2Fspan%3E%20%7B%0A%20%20%3Cspan%20class%3D%22hljs-attribute%22%3Ebottom%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-number%22%3E30px%3C%2Fspan%3E%3B%0A%7D%0A%40-%3Cspan%20class%3D%22hljs-keyword%22%3Ewebkit%3C%2Fspan%3E-%3Cspan%20class%3D%22hljs-keyword%22%3Ekeyframes%3C%2Fspan%3E%20fadeInUp%20%7B%0A%20%20%3Cspan%20class%3D%22hljs-selector-tag%22%3Efrom%3C%2Fspan%3E%20%7B%0A%20%20%20%20%3Cspan%20class%3D%22hljs-attribute%22%3Eopacity%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-number%22%3E0%3C%2Fspan%3E%3B%0A%20%20%20%20%3Cspan%20class%3D%22hljs-attribute%22%3Etransform%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-built_in%22%3Etranslate3d%3C%2Fspan%3E(0%2C%20100%25%2C%200)%3B%0A%20%20%7D%0A%20%20100%25%20%7B%0A%20%20%20%20%3Cspan%20class%3D%22hljs-attribute%22%3Eopacity%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-number%22%3E1%3C%2Fspan%3E%3B%0A%20%20%20%20%3Cspan%20class%3D%22hljs-attribute%22%3Etransform%3C%2Fspan%3E%3A%20none%3B%0A%20%20%7D%0A%7D%0A%40%3Cspan%20class%3D%22hljs-keyword%22%3Ekeyframes%3C%2Fspan%3E%20fadeInUp%20%7B%0A%20%20%3Cspan%20class%3D%22hljs-selector-tag%22%3Efrom%3C%2Fspan%3E%20%7B%0A%20%20%20%20%3Cspan%20class%3D%22hljs-attribute%22%3Eopacity%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-number%22%3E0%3C%2Fspan%3E%3B%0A%20%20%20%20%3Cspan%20class%3D%22hljs-attribute%22%3Etransform%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-built_in%22%3Etranslate3d%3C%2Fspan%3E(0%2C%20100%25%2C%200)%3B%0A%20%20%7D%0A%20%20100%25%20%7B%0A%20%20%20%20%3Cspan%20class%3D%22hljs-attribute%22%3Eopacity%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-number%22%3E1%3C%2Fspan%3E%3B%0A%20%20%20%20%3Cspan%20class%3D%22hljs-attribute%22%3Etransform%3C%2Fspan%3E%3A%20none%3B%0A%20%20%7D%0A%7D%0A%3Cspan%20class%3D%22hljs-selector-class%22%3E.fadeInUp%3C%2Fspan%3E%20%7B%0A%20%20%3Cspan%20class%3D%22hljs-attribute%22%3Eanimation-name%3C%2Fspan%3E%3A%20fadeInUp%3B%0A%7D%0A%3Cspan%20class%3D%22hljs-selector-class%22%3E.swiper-demo-img%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-selector-tag%22%3Eimg%3C%2Fspan%3E%20%7B%0A%20%20%3Cspan%20class%3D%22hljs-attribute%22%3Ewidth%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-number%22%3E100%25%3C%2Fspan%3E%3B%0A%7D%0A%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Estyle%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%3C%2Fcode%3E%3C%2Fpre%3E`)

  const domainMap = {
    'development': 'http://localhost:8080/',
    'production': 'https://vux.li/demos/v2/'
  }

  export default {
    head: {
      title: 'Swiper component tutorial | VUX - Vue.js Mobile UI Component Framework',
      meta: [{
        name: 'description',
        content: 'Vue component swiper for the VUX framework.'
      }, {
        name: 'keywords',
        content: 'swiper, vue-swiper, vux-swiper, vue mobile components'
      }, {
        property: 'og:title',
        content: 'Swiper component tutorial | VUX - Vue.js Mobile UI Component Framework'
      }, {
        property: 'og:description',
        content: 'Vue component swiper for the VUX framework.'
      }],
      // https://support.google.com/webmasters/answer/189077?hl=en
      link: [{"rel":"alternate","hreflang":"zh-CN","href":"/zh-CN/components/swiper.html"}],
      script: [
        {
          innerHTML:'{"@context":"http://schema.org/","@type":"SoftwareApplication","name":"Vue Component swiper","screenshot":"","description":"Vue.js component for VUX","url":"/en/components/swiper.html","applicationCategory":"Component","author":{"@type":"Organization","name":"VUX","url":"https://vux.li"},"downloadUrl":"https://vux.li","softwareVersion":"2.9.2","aggregateRating":{"@type":"AggregateRating","ratingValue":5,"reviewCount":45},"operatingSystem":"iOS >= 7, Android >= 4.1","offers":{"@type":"Offer","price":0,"priceCurrency":"USD","availability":"http://schema.org/InStock"}}',
          type: 'application/ld+json'
        }
      ],
      __dangerouslyDisableSanitizers: ['script']
    },
    filters: {
      parseCode (str) {
        return str.replace(/`(.*?)`/g, '<code>$1</code>')
      }
    },
    async mounted () {
      const rs = await Axios.get('https://api.github.com/search/issues?q=repo:airyland/vux%20label:component/' + this.componentName)
      this.issues = rs.data.items
      this.hasReady = true
    },
    watch: {
      async sourceCodeDialogVisibility (val) {
        if (val) {
          await this.$nextTick()
          const mask = document.querySelector('.v-modal')
          mask && mask.addEventListener('click', () => {
            this.sourceCodeDialogVisibility = false
          })
        }
      }
    },
    methods: {
      onCopyError () {
        this.$message({
          type: 'error',
          message: 'copy fail!'
        })
      },
      onCopy () {
        this.$message({
          type: 'success',
          message: 'copy done!'
        })
      },
      showSourceCode () {
        this.sourceCodeDialogVisibility = true
      },
      getTypeHTML (type) {
        type = type || 'String'
        if (/,/.test(type)) {
          const list = type.split(',').map(function (one) {
            return one.replace(/^s+|s+$/g, '')
          }).map(function (one) {
            const type = one ?  one.toLowerCase() : 'string'
            return '<span class="type">' + type + '</span>'
          })
          return list.join('<br>')
        } else {
          type = type ?  type.toLowerCase() : 'string'
          return '<span class="type">' + type + '</span>'
        }
      }
    },
    computed: {
      lang () {
        if (this.$route.path.indexOf('/en/') !== -1) {
          return 'en'
        }
        if (this.$route.path.indexOf('/zh-CN/') !== -1) {
          return 'zh-CN'
        }
        return 'en'
      }
    },
    data () {
      return {
        demos,
        isBeta: false,
        hasReady: false,
        issues: [],
        componentName: 'swiper',
        demoCode,
        sourceCodeDialogVisibility: false,
        showQr: false,
        metas: metas,
        gitMetas,
        componentList,
        localImportCode: `import { Swiper } from 'vux'

export default {
  components: {
    Swiper
  }
}`,
        globalImportCode: `// you can also register globally

import Vue from 'vue'
import { Swiper } from 'vux'

Vue.component('swiper', Swiper)
`,
        needImport: true,
        toc: [],
        domain: domainMap[process.env.NODE_ENV]
      }
    }
  }
  </script>

  <style>
  .component-box {
    position: relative;
  }
  .component-demo {
    position: absolute;
    right: 5px;
    top: 15px;
  }
  .prop-color {
    display: inline-block;
    width: 10px;
    height: 10px;
    border: 1px solid #aaa;
  }
  .changelog-version {
    width: 110px;
    display: inline-block;
  }
  .component-extra-links {
    position: relative;
    font-size: 12px;
  }
  .component-extra-links a {
    padding-right: 10px;
    color: #999;
  }
  </style>
    