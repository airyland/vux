
  <template>
    <div class="component-box" :class="demos.length ? 'components-with-toc' : ''">

      <div :class="demos.length ? 'component-header-v2' : 'component-header-v1'">
        <a class="anchor" id="intro">Datetime</a>
        <div class="title-box">

          <el-badge value="Beta" v-if="isBeta">
            <h1 class="vux-component-name">Datetime</h1>
          </el-badge>
          <h1 v-else class="vux-component-name">Datetime</h1>

          <p class="component-extra-links">
            <a href="https://vux.li/demos/v2/#/component/datetime" target="_blank">demo url</a>
            <a v-if="!demos.length" href="https://github.com/airyland/vux/blob/v2/src/demos/Datetime.vue" target="_blank" @click.prevent="showSourceCode">demo source code</a>
            <a href="https://github.com/airyland/vux/blob/v2/src/components/datetime/metas.yml" target="_blank">edit document</a>
            <a href="https://github.com/airyland/vux/blob/v2/src/components/datetime/" target="_blank">component source code</a>
            <el-popover trigger="hover" v-if="hasReady">
              <div style="width:100%;text-align:center;">
                <img class="qr" width="100" src="https://qr.vux.li/api.php?text=https%3A%2F%2Fvux.li%2Fdemos%2Fv2%2F%23%2Fcomponent%2Fdatetime"/>
              </div>
              <a href="javascript:" slot="reference">
              view demos on mobile
              </a>
            </el-popover>
          </p>

          <div class="component-description">
            <template v-if="false">
            
            </template>
          </div>

        </div>

        <div v-if="!demos.length" class="component-demo" style="width:377px;height:600px;display:inline-block;border:1px solid #ececec;border-radius:5px;overflow:hidden;z-index:2500;">
          <iframe src="https://vux.li/demos/v2?locale=en&transition=none/#/component/datetime" width="375" height="600" border="0" frameborder="0"></iframe>
        </div>
        <div class="toc">
          <ul v-for="t in toc">
            <li>
              <a :href="'#' + (t.anchor || t.title)">{{ t.title }}</a>
              <ul v-if="t.list" v-for="_t in t.list">
                <li><a :href="'#' + _t.anchor">{{ _t.title.slice(0, 12) }}</a></li>
              </ul>
            </li>
          </ul>
        </div>
      
        <template v-if="needImport">
          <a class="anchor" id="install">Install</a>
          <h2>Install</h2>
          <el-tabs>
            <el-tab-pane label="Local Registration">
              <div class="import-code-box">
              <el-tooltip content="click to copy" placement="top">
                <span
                  v-clipboard:copy="localImportCode"
                  v-clipboard:success="onCopy"
                  v-clipboard:error="onCopyError">
                  <el-icon class="el-icon-document"></el-icon>
                </span>
              </el-tooltip>
              <pre class="hljs"><code><span class="hljs-keyword">import</span> { Datetime } <span class="hljs-keyword">from</span> <span class="hljs-string">'vux'</span>

<span class="hljs-keyword">export</span> <span class="hljs-keyword">default</span> {
  <span class="hljs-attr">components</span>: {
    Datetime
  }
}</code></pre>
            </div>
            </el-tab-pane>
            <el-tab-pane label="Global Registration">
              <div class="import-code-box">
                <el-tooltip content="click to copy" placement="top">
                  <span
                    v-clipboard:copy="globalImportCode"
                    v-clipboard:success="onCopy"
                    v-clipboard:error="onCopyError">
                    <el-icon class="el-icon-document"></el-icon>
                  </span>
                </el-tooltip>
                <pre class="hljs"><code><span class="hljs-comment">// you can also register globally</span>

<span class="hljs-keyword">import</span> Vue <span class="hljs-keyword">from</span> <span class="hljs-string">'vue'</span>
<span class="hljs-keyword">import</span> { Datetime } <span class="hljs-keyword">from</span> <span class="hljs-string">'vux'</span>

Vue.component(<span class="hljs-string">'datetime'</span>, Datetime)
</code></pre>
              </div> 
            </el-tab-pane>
          </el-tabs>   
        </template>

        <template v-else>
          <div class="tip">
            <p>You don't need to import this component.</p>
          </div>
        </template>

        <div class="tip" style="width:600px;" v-if="metas.tip">
          
        </div>
      
        <h2 v-if="metas.example">example</h2>
        <div v-if="metas.example" style="width:600px;">
          
        </div>
      </div>

      <div v-if="metas.extra && metas.extra['en']">
        
      </div>
      <div v-if="metas.extra && !metas.extra['en']">
        <div class="tip">
<p>需要在<code>Group</code>组件里使用</p>
</div>
<p>该组件支持以<code>plugin</code>形式调用：</p>
<pre class="hljs"><code><span class="hljs-comment">// 以 plugin 形式使用时，请在入口处引入：</span>
<span class="hljs-keyword">import</span> { DatetimePlugin } <span class="hljs-keyword">from</span> <span class="hljs-string">'vux'</span>
Vue.use(DatetimePlugin)

<span class="hljs-comment">// 组件内使用</span>
<span class="hljs-keyword">this</span>.$vux.datetime.show({
  <span class="hljs-attr">value</span>: <span class="hljs-string">''</span>, <span class="hljs-comment">// 其他参数同 props</span>
  onHide () {
    <span class="hljs-keyword">const</span> _this = <span class="hljs-keyword">this</span>
  },
  onShow () {
    <span class="hljs-keyword">const</span> _this = <span class="hljs-keyword">this</span>
  }
})

<span class="hljs-keyword">this</span>.$vux.datetime.hide()
</code></pre>

      </div>
      
      <a v-if="demos.length" class="anchor" id="examples">Examples</a>
      <br/>
      <template v-if="demos.length" v-for="demo in demos">
        <a class="anchor" :id="'examples:' + demo.title">{{ demo.title }}</a>
        <br/>
        <div class="demo-header">
          <span class="demo-title">{{ demo.title }}</span>
        </div>
        <div class="demos" :style="{height: demo.height}">
          <div class="demo-iframe-box">
            <lazy-component>
              <iframe
                :src="domain + '?no-background-color=' + demo.noBackgroundColor +'&locale=en&transition=none&hide-nav=true&hide-tab-bar=true#/components/' + demo.file"
                width="375"
                height="600"
                border="0"
                frameborder="0"
                style="margin: 0 auto;"></iframe>
            </lazy-component>
          </div>
          <div class="demo-code-box" :style="{overflow: demo.height === demo.oriHeight ? 'hidden' : 'scroll'}">
            <div v-html="demo.code" contenteditable></div>
            <div v-if="demo.height === demo.oriHeight" class="demo-code-masker" @click="demo.height='auto'">
              <div>
                  <img class="demo-qr" width="100" :src="'https://qr.vux.li/api.php?text=' + encodeURIComponent(domain + '?locale=en#/components/' + demo.file)"/>
                  <br/>
                  <span>
                    <el-icon class="el-icon-arrow-left"/>
                    <el-icon class="el-icon-arrow-right"/>
                    Show code
                  <br/>
                  <!--<span class="demo-path">src/demos/{{ demo.file }}.vue</span>-->
                </span>
              </div>
            </div>
            <span v-if="demo.height === 'auto'" class="hide-code" @click="demo.height=demo.oriHeight">
              <el-icon class="el-icon-close"></el-icon>
            </span>
          </div>
        </div>
      </template>

      <template v-for="component in componentList">
        <div>
          <a v-if="componentList.length > 1" class="anchor" :id="'components:' + component.name">{{ component.name }}</a>
          <a v-else class="anchor" id="api">API</a>
          <br/>
          <h2
            v-show="componentList.length > 1"
            class="vux-component-name-sub-item">{{ component.name }}</h2>
            
          <template v-if="component.meta.items && component.meta.description">
            <div v-html="component.meta.description"></div>
          </template>

          <template v-if="component.meta.props">
            <h2>Props</h2>
            <table>
              <thead>
                <tr>
                  <td>name</td>
                  <td style="width:48px;">type</td>
                  <td>default</td>
                  <td>description</td>
                  <td>required version</td>
                </tr>
              </thead>
              <tbody>
                <tr v-for="(prop, i) in component.meta.props">
                  <td class="prop-name">
                    <el-tooltip content="click to copy" placement="left" :hide-after="0" :open-delay="50">
                      <span
                      v-clipboard:copy="i"
                      v-clipboard:success="onCopy">{{ i }}</span>
                    </el-tooltip>
                  </td>
                  <td v-html="getTypeHTML(prop.type)"></td>
                  <td>{{ prop.default}}</td>
                  <td v-html="prop['en'].replace(/`(.*?)`/g, '<code>$1</code>')"></td>
                  <td>{{ prop.version || '--'}}</td>
                </tr>
              </tbody>
            </table>
          </template>

          <template v-if="component.meta.events">
            <h2>Events</h2>
            <table>
              <thead>
                <tr>
                  <td>name</td>
                  <td>params</td>
                  <td>description</td>
                  <td>required version</td>
                </tr>
              </thead>
              <tbody>
                <tr v-for="(event, i) in component.meta.events">
                  <td class="prop-name">
                    <el-tooltip content="click to copy" placement="left" :hide-after="0" :open-delay="50">
                      <span
                      v-clipboard:copy="'@' + i"
                      v-clipboard:success="onCopy">@{{ i }}</span>
                    </el-tooltip>
                  </td>
                  <td v-html="event.params ? event.params.replace(/`(.*?)`/g, '<code>$1</code>') : '--'"></td>
                  <td v-html="event['en'] ? event['en'].replace(/`(.*?)`/g, '<code>$1</code>') : '--'"></td>
                  <td>{{ event['version'] || '--' }}</td>
                </tr>
              </tbody>
            </table>
          </template>
      

          <template v-if="component.meta.slots">
            <h2>Slots</h2>
            <table>
              <thead>
                <tr>
                  <td>name</td>
                  <td>description</td>
                  <td>required version</td>
                </tr>
              </thead>
              <tbody>
                <tr v-for="(slot, i) in component.meta.slots" :class="{'slot-disabled': slot['status'] === 'deprecated'}">
                  <td class="prop-name">
                    <el-tooltip content="click to copy" placement="left" :hide-after="0" :open-delay="50">
                      <span
                      v-clipboard:copy="i"
                      v-clipboard:success="onCopy">{{ i === 'default' ? 'default' : i }}</span>
                    </el-tooltip>
                  </td>
                  <td v-html="slot['en'] ? slot['en'].replace(/`(.*?)`/g, '<code>$1</code>') : ''"></td>
                  <td>{{ slot['version'] || '--' }}</td>
                </tr>
              </tbody>
            </table>
          </template>
          
          <template v-if="component.meta.methods">
            <h2>Functions</h2>
            <table>
              <thead>
                <tr>
                  <td>name</td>
                  <td>params</td>
                  <td>description</td>
                  <td>required version</td>
                </tr>
              </thead>
              <tbody>
                <tr v-for="(method, i) in component.meta.methods">
                  <td class="prop-name">
                    <el-tooltip content="click to copy" placement="left" :hide-after="0" :open-delay="50">
                      <span
                      v-clipboard:copy="i"
                      v-clipboard:success="onCopy">{{ i }}</span>
                    </el-tooltip>
                  </td>
                  <td v-html="method['params'] ? method['params'].replace(/`(.*?)`/g, '<code>$1</code>') : ''"></td>
                  <td v-html="method['en'].replace(/`(.*?)`/g, '<code>$1</code>')"></td>
                  <td>{{ method['version'] }}</td>
                </tr>
              </tbody>
            </table>
          </template>

          <template v-if="component.meta.variables">
            <a class="anchor" id="variables">Variables</a>
            <br/>
            <h2>Variables</h2>
            <table>
              <thead>
                <tr>
                  <td>name</td>
                  <td>default</td>
                  <td>description</td>
                  <td>inherited name</td>
                </tr>
              </thead>
              <tbody>
                <tr v-for="(variable, i) in component.meta.variables">
                  <td class="prop-name">
                    <el-tooltip content="click to copy" placement="left" :hide-after="0" :open-delay="50">
                      <span
                      v-clipboard:copy="'@' + variable.name"
                      v-clipboard:success="onCopy">@{{ variable.name }}</span>
                    </el-tooltip>
                  </td>
                  <td>
                    <em
                      :ref="'propColor' + i"
                      v-if="!$refs['propColor' + i] || ($refs['propColor' + i][0] && $refs['propColor' + i][0].style.backgroundColor)"
                      class="prop-color"
                      :style="{ backgroundColor: variable.value }">
                    </em>
                    {{ variable.value }}
                  </td>
                  <td>{{ variable['desc']['en'] || '--' }}</td>
                  <td>{{ variable.inherited_name }}</td>
                </tr>
              </tbody>
            </table>
          </template>
      
          <template v-if="component.meta.tips && component.meta.tips['en']">
            <a class="anchor" id="tips">Tips</a>
            <br>
            <h2>Tips</h2>
            <div>
              <ul>
                <li v-for="tip in component.meta.tips['en']">
                <el-tag size="mini" type="success" class="component-tip-tag">Q</el-tag> <span class="component-tip-question">{{ tip.q }}</span>
                <div v-html="tip.a" class="tip-answer-box"></div>
                </li>
              </ul>
            </div>
          </template>
        </div>
      </template>

      <!--<h2>社区相关讨论</h2>
      [即将上线]
      -->
    
      <br>
      <div v-if="issues.length">
        <a class="anchor" id="Issues">Issues</a>
        <br/>
        <h2>Related issues</h2>
        <ul>
          <li v-for="issue in issues"><a target="_blank" :href="issue.html_url">#{{ issue.number}} <span style="color:#666;">{{ issue.title }}</span></a></li>
        </ul>
      </div>
      <br>
    
      <div v-if="gitMetas">
        <a class="anchor" id="contributors">Contributors</a>
        <h2>Contributors</h2>
        <p>Total commits quantity: {{ gitMetas.commitCount }}，Total contributors quantity: {{gitMetas.commitUniqueCount}}
        </p>
        <a v-for="person in gitMetas.commitMembers" class="contributor-item" :href="'https://github.com/' + person.authorName" target="_blank" :title="'contribute' + person.count">{{person.authorName}}</a>
      </div>
      <br>

      <div v-if="metas.changes">
        <a class="anchor" id="changelog">Changelog</a>
        <br/>
        <h2>Releases</h2>
        <ul v-if="metas.changes">
          <template v-for="(changelog, version) in metas.changes">
            <li v-for="log in changelog['en']">
              <router-link :to="'/en/changelog/' + version + '.html'" class="changelog-version">{{version}}</router-link> {{log}}
            </li>
          </template>
        </ul>
      </div>

      <h2 v-if="metas.references">Referrences</h2>
      <ul v-if="metas.references">
        <li v-for="link in metas.references['en']">
          <a :href="link.link" target="_blank">{{link.title}}</a>
        </li>
      </ul>

      <el-dialog
        class="sourcec-code-dialog"
        top="0"
        width="80%"
        :visible.sync="sourceCodeDialogVisibility">
        <div class="code-box" contenteditable v-html="demoCode"></div>
      </el-dialog>

    </div>
  </template>


  <script>
  import Axios from 'axios'

  // const metas = require('json-loader!yaml-loader!../../../src/components/datetime/metas.yml')
  const metas = {
  "category": {
    "en": "Form",
    "zh-CN": "表单"
  },
  "icon": "&#xe60a;",
  "extra": "::: tip\n需要在`Group`组件里使用\n:::\n\n\n该组件支持以`plugin`形式调用：\n\n``` js\n// 以 plugin 形式使用时，请在入口处引入：\nimport { DatetimePlugin } from 'vux'\nVue.use(DatetimePlugin)\n\n// 组件内使用\nthis.$vux.datetime.show({\n  value: '', // 其他参数同 props\n  onHide () {\n    const _this = this\n  },\n  onShow () {\n    const _this = this\n  }\n})\n\nthis.$vux.datetime.hide()\n```\n",
  "tips": {
    "zh-CN": [
      {
        "q": "是否支持秒(ss)",
        "a": "<p>不支持，目前常用需求场景并没有需要精确到秒。</p>\n"
      },
      {
        "q": "on-confirm 事件获取不到正确的值",
        "a": "<p>在 <code>v2.9.0</code> 之前 on-confirm 不会附带当前值参数，你需要在 <code>this.$nextTick</code> 后获取。\n相关 issue: <a href=\"https://github.com/airyland/vux/issues/2632\">#2632</a></p>\n"
      }
    ]
  },
  "tags": {
    "en": [
      "date",
      "datetime",
      "form"
    ],
    "zh-CN": [
      "日期",
      "选择",
      "表单"
    ]
  },
  "props": {
    "format": {
      "type": "String",
      "default": "YYYY-MM-DD",
      "en": "date format. Special characters are not supported, for example, YYYY-MM-DD HH:mm(do not support ss)",
      "zh-CN": "时间格式，不支持特殊字符，只能类似 YYYY-MM-DD HH:mm 这样的格式（不支持秒 ss）, 另外支持 YYYY-MM-DD A 这样的格式(A为上下午)"
    },
    "title": {
      "type": "String",
      "default": "",
      "en": "cell title",
      "zh-CN": "标题"
    },
    "value": {
      "type": "String",
      "default": "",
      "en": "form's value, use `v-model` for binding",
      "zh-CN": "表单值，`v-model`绑定"
    },
    "inline-desc": {
      "type": "String",
      "default": "",
      "en": "description of the cell",
      "zh-CN": "描述字符"
    },
    "placeholder": {
      "type": "String",
      "default": "",
      "en": "placeholder, works when value is empty",
      "zh-CN": "提示文字，当`value`为空时显示"
    },
    "min-year": {
      "type": "Number",
      "default": "",
      "en": "min-year of the form",
      "zh-CN": "可选择的最小年份"
    },
    "max-year": {
      "type": "Number",
      "default": "",
      "en": "max-year of the form",
      "zh-CN": "可选择的最大年份"
    },
    "min-hour": {
      "type": "Number",
      "default": 0,
      "en": "min hour",
      "zh-CN": "限定小时最小值"
    },
    "max-hour": {
      "type": "Number",
      "default": 23,
      "en": "max hour",
      "zh-CN": "限定小时最大值"
    },
    "confirm-text": {
      "type": "String",
      "default": "ok(确认)",
      "en": "confirm button's text",
      "zh-CN": "确认按钮文字"
    },
    "cancel-text": {
      "type": "String",
      "default": "cancel(取消)",
      "en": "cancel button's text",
      "zh-CN": "取消按钮文字"
    },
    "clear-text": {
      "type": "String",
      "default": "",
      "en": "custom button's text which shows in the middle of the header",
      "zh-CN": "显示在中间的自定义按钮的文字"
    },
    "year-row": {
      "type": "String",
      "default": "{value}",
      "en": "render template for the year column",
      "zh-CN": "年份的渲染模板"
    },
    "month-row": {
      "type": "String",
      "default": "{value}",
      "en": "render template for the month column",
      "zh-CN": "月份的渲染模板"
    },
    "day-row": {
      "type": "String",
      "default": "{value}",
      "en": "render template for the day column",
      "zh-CN": "日期的渲染模板"
    },
    "hour-row": {
      "type": "String",
      "default": "{value}",
      "en": "render template for the hour column",
      "zh-CN": "小时的渲染模板"
    },
    "minute-row": {
      "type": "String",
      "default": "{value}",
      "en": "render template for the minute column",
      "zh-CN": "分钟的渲染模板"
    },
    "start-date": {
      "type": "String",
      "en": "start date, must be YYYY-MM-DD. Please use `min-hour` and `max-hour` to limit the range of hours",
      "zh-CN": "限定最小日期，格式必须为 YYYY-MM-DD，注意该限制只能限定到日期，不能限定到小时分钟。小时限定请使用`min-hour`和`max-hour`"
    },
    "end-date": {
      "type": "String",
      "en": "end date, must be YYYY-MM-DD. Please use `min-hour` and `max-hour` to limit the range of hours",
      "zh-CN": "限定最大日期，格式必须为 YYYY-MM-DD，注意该限制只能限定到日期，不能限定到小时分钟"
    },
    "required": {
      "type": "Boolean",
      "default": false,
      "en": "if required",
      "zh-CN": "是否必填"
    },
    "display-format": {
      "version": "v2.1.1-rc.11",
      "type": "Function",
      "en": "used to format display value",
      "zh-CN": "自定义显示值"
    },
    "readonly": {
      "version": "v2.3.6",
      "en": "readonly mode, show like a cell",
      "zh-CN": "只读模式，显示类似于 cell"
    },
    "show": {
      "version": "v2.3.7",
      "type": "Boolean",
      "en": "control visibility of datetime, require vue^2.3",
      "zh-CN": "控制显示，要求 vue^2.3"
    },
    "minute-list": {
      "version": "v2.3.7",
      "type": "Array",
      "en": "specify minute list, for instance ['00', '15', '30', '45']",
      "zh-CN": "定义分钟列表，比如 ['00', '15', '30', '45']"
    },
    "hour-list": {
      "version": "v2.3.7",
      "type": "Array",
      "en": "specify hour list, for instance ['09', '10', '11', '12']",
      "zh-CN": "定义小时列表，比如 ['09', '10', '11', '12']"
    },
    "default-selected-value": {
      "version": "v2.4.1",
      "en": "set default selected value, works only when value is empty",
      "zh-CN": "设置默认选中日期，当前 value 为空时有效"
    },
    "compute-hours-function": {
      "version": "v2.5.5",
      "type": "Function",
      "en": "dynamically set hours list, params `(value, isToday, generateRange)`",
      "zh-CN": "动态设置小时列表，参数为 `(value, isToday, generateRange)`"
    },
    "compute-days-function": {
      "version": "v2.6.1",
      "type": "Function",
      "en": "dynamically set days list, params `({year, month, min, max}, generateRange)`",
      "zh-CN": "动态设置日期列表，参数为 `({year, month, min, max}, generateRange)`"
    },
    "order-map": {
      "version": "v2.9.0",
      "type": "Object",
      "en": "set column order, `{year: 1, month: 2, day: 3, hour: 4, minute: 5, noon: 6}`",
      "zh-CN": "自定义列顺序, 如 `{year: 1, month: 2, day: 3, hour: 4, minute: 5, noon: 6}`"
    }
  },
  "slots": {
    "default": {
      "en": "trigger element content",
      "zh-CN": "触发元素内容"
    },
    "title": {
      "version": "v2.3.6",
      "en": "title slot",
      "zh-CN": "title slot"
    }
  },
  "events": {
    "on-change": {
      "params": "`(value)`",
      "en": "$emits when value changes, `(newVal)`",
      "zh-CN": "表单值变化时触发, 参数 `(newVal)`"
    },
    "on-clear": {
      "en": "$emits when click the button in the middle of the header",
      "zh-CN": "点击显示在中间的自定义按钮时触发"
    },
    "on-show": {
      "en": "fires when datetime shows",
      "zh-CN": "弹窗显示时触发"
    },
    "on-hide": {
      "params": "`(type)`, type is one of [cancel, confirm]",
      "version": "v2.7.4",
      "en": "fires when datetime hides",
      "zh-CN": "弹窗关闭时触发"
    },
    "on-cancel": {
      "version": "v2.7.4",
      "en": "fires when cancel button is clicked or mask is clicked",
      "zh-CN": "点击取消按钮或者遮罩时触发，等同于事件 on-hide(cancel)"
    },
    "on-confirm": {
      "version": "v2.7.4",
      "params": "`(value)` v2.9.0 支持该参数",
      "en": "fires when confirm button is clicked",
      "zh-CN": "点击确定按钮时触发，等同于事件 on-hide(confirm)"
    }
  },
  "changes": {
    "v2.9.0": {
      "en": [
        "[feature] support order-map to customize column orders #2300",
        "[fix] fix mask cause body scroll in iOS #2593",
        "[feature] add arg:value for event:on-confirm #2632",
        "[fix] fire event:on-confirm after nextTick #2632",
        "[feature] support format YYYY-MM-DD A #2627 @jack87918"
      ],
      "zh-CN": [
        "[feature] 支持使用 order-map 自定义列顺序 #2300",
        "[fix] 修复遮罩导致页面滚动 #2593",
        "[feature] 事件 on-confirm 添加当前值 #2632",
        "[fix] 在 nextTick 后触发 on-confirm 事件 #2632",
        "[feature] 支持格式 YYYY-MM-DD A 选择上下午 #2627 @jack87918"
      ]
    },
    "v2.7.8": {
      "en": [
        "[fix] fix `on-hide` event trigger twice #2379",
        "[fix] fix cannot set `show` to `true` initially"
      ],
      "zh-CN": [
        "[fix] 修复 `on-hide` 事件触发两次的问题 #2379",
        "[fix] 修复初始化时 `show` 值为 `true` 无效的问题"
      ]
    },
    "v2.7.6": {
      "en": [
        "[fix] column value use number type, fix binding value is not equal to datetimepicker value #2296"
      ],
      "zh-CN": [
        "[fix] 列的值使用number类型，修正绑定值与datetimepicker值不相等 #2296"
      ]
    },
    "v2.7.4": {
      "en": [
        "[feature] add event:on-confirm event:on-cancel #2221"
      ],
      "zh-CN": [
        "[feature] 支持事件 on-confirm on-cancel #2221"
      ]
    },
    "v2.7.2": {
      "en": [
        "[enhance] set default start-date if end-date is specified but start-date is not #2158"
      ],
      "zh-CN": [
        "[enhance] 当指定结束日期但未指定开始日期时使用默认年第一天作为开始日期 #2158"
      ]
    },
    "v2.7.1": {
      "en": [
        "[fix] fix less variables do not work in plugin usage #2152"
      ],
      "zh-CN": [
        "[fix] 修复插件使用时 less 变量不生效问题 #2152"
      ]
    },
    "v2.7.0": {
      "en": [
        "[fix] fix ssr i18n bug",
        "[fix] fix datetime still shows when prop:readonly is true #2079"
      ],
      "zh-CN": [
        "[fix] 修复服务端渲染多语言 bug",
        "[fix] 修复 readonly 为 true 时点击还会显示弹窗的问题 #2079"
      ]
    },
    "v2.6.1": {
      "en": [
        "[feature] support prop:compute-days-function for dynamically setting days #1992"
      ],
      "zh-CN": [
        "[feature] 支持属性 compute-days-function 用以动态设置日期 #1992 "
      ]
    },
    "v2.6.0": {
      "en": [
        "[fix] fix i18n for cancel_text confirm_text"
      ],
      "zh-CN": [
        "[fix] 修复取消文字、确认文字国际化显示问题"
      ]
    },
    "v2.5.11": {
      "en": [
        "[fix] fix :show.syc=\"false\" do no work #1918",
        "[fix] fix prop:compute-hours-function not working when month is changed"
      ],
      "zh-CN": [
        "[fix] 修复 :show.sync 设为 false 无效 #1918",
        "[fix] 修复特定情况下月份变化不会触发小时重新渲染的问题"
      ]
    },
    "v2.5.10": {
      "en": [
        "[feature] support @cell-value-color #1874"
      ],
      "zh-CN": [
        "[feature] 值文字颜色受控于 @cell-value-color #1874"
      ]
    },
    "v2.5.9": {
      "en": [
        "[fix] fix error when format is YYYY #1861"
      ],
      "zh-CN": [
        "[fix] 修复格式为 YYYY 时的报错 #1861"
      ]
    },
    "v2.5.5": {
      "en": [
        "[feature] support prop:compute-hours-function #1749",
        "[enhance] better mask transition"
      ],
      "zh-CN": [
        "[feature] 支持动态设置小时列表 #1749",
        "[enhance] 更加流畅的遮罩层动画"
      ]
    },
    "v2.4.1": {
      "en": [
        "[fix] Re-render when readonly is changed #1593",
        "[feature] Support prop:default-selected-value #1576"
      ],
      "zh-CN": [
        "[fix] readonly 值变化时重新渲染 #1593",
        "[feature] 支持通过 prop:default-selected-value 设置默认选中日期 #1576"
      ]
    },
    "v2.4.0": {
      "en": [
        "[enhance] use the same popup header style as popup-picker"
      ],
      "zh-CN": [
        "[enhance] 统一弹窗头部样式，和 popup-picker 一致"
      ]
    },
    "v2.3.7": {
      "en": [
        "[feature] Add prop:show to control visibility #1538",
        "[fix] Fix range error with format YYYY-MM #1358",
        "[feature] Add prop:hourList prop:minuteList",
        "[fix] startDate year should overwrite minYear #1358"
      ],
      "zh-CN": [
        "[feature] 可以使用 :show.sync 来控制控件显示 #1358",
        "[fix] 修复格式为 YYYY-MM 时的日期范围错误 #1528",
        "[feature] 支持通过 prop:hourList prop:minuteList 自定义小时和分钟列表",
        "[fix] 开始日期年份应该覆盖最小年份(minYear) #1358"
      ]
    },
    "v2.3.6": {
      "en": [
        "[feature] Add slot:title",
        "[feature] Add prop:readonly",
        "[fix] Fix a bug caused by scroller #1406"
      ],
      "zh-CN": [
        "[feature] 添加 slot:title",
        "[feature] 添加 prop:readonly",
        "[fix] 修复 scroller 支持数字类型引入的 bug #1406"
      ]
    },
    "v2.3.4": {
      "en": [
        "[fix] do not trigger on-change on first-value-setting"
      ],
      "zh-CN": [
        "[fix] 初始化时不触发 on-change 事件"
      ]
    },
    "v2.2.1-rc.8": {
      "en": [
        "[enhance] now changing prop:format will trigger re-rendering"
      ],
      "zh-CN": [
        "[enhance] 修改 prop:format 会触发重新渲染"
      ]
    },
    "v2.2.0": {
      "en": [
        "[fix] render picker on nextTick #1180"
      ],
      "zh-CN": [
        "[fix] 在 nextTick 回调渲染 picker 避免赋值报错 #1180"
      ]
    },
    "v2.1.1-rc.11": {
      "en": [
        "[feature] Support prop:display-format #1086 @greedying"
      ],
      "zh-CN": [
        "[feature] 支持格式化显示 prop:display-format #1086 @greedying"
      ]
    },
    "v2.1.1-rc.7": {
      "en": [
        "[enhance] Support PC mouse drag  #1039 @michael829"
      ],
      "zh-CN": [
        "[enhance] 支持 PC 上鼠标选择 #1039 @michael829"
      ]
    },
    "v2.1.0": {
      "zh-CN": [
        "[fix] 修复`label`宽度没有受限于`group`设置"
      ]
    },
    "v2.1.0-rc.46": {
      "zh-CN": [
        "[feature] 支持配置`取消`和`确定`的文字颜色 #715 @greedying"
      ]
    }
  },
  "variables": [
    {
      "name": "datetime-header-item-font-color",
      "value": "#04BE02",
      "is_inherited": true,
      "inherited_name": "@theme-color",
      "desc": {}
    },
    {
      "name": "datetime-header-item-cancel-font-color",
      "value": "#828282",
      "is_inherited": false,
      "inherited_name": "",
      "desc": {}
    },
    {
      "name": "datetime-header-item-confirm-font-color",
      "value": "#04BE02",
      "is_inherited": true,
      "inherited_name": "@datetime-header-item-font-color",
      "desc": {}
    }
  ]
}
  const demos = []

  let componentList = []
  if (Array.isArray(metas.items)) {
    try {
      metas.items.forEach((item, index) => {
        const meta = {
          name: item,
          meta: metas[item]
        }
        if (meta.meta.props === null) {
          delete meta.meta.props
        }
        if (index === metas.items.length - 1) {
          if (meta.meta) {
            meta.meta.variables = metas.variables
          }
        }
        componentList.push(meta)
      })
    } catch (e) {
      console.log(e)
    }
  } else {
    componentList.push({
      meta: metas
    })
  }
  const gitMetas = require('./datetime_git_metas.json')
  const demoCode = decodeURIComponent(`%3Cpre%20class%3D%22hljs%22%3E%3Ccode%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Etemplate%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ediv%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ediv%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Estyle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22padding%3A15px%3B%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ex-button%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Etype%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22primary%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Eplain%3C%2Fspan%3E%20%40%3Cspan%20class%3D%22hljs-attr%22%3Eclick.native%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22showPlugin%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%7B%7B%20%24t('Used%20as%20a%20plugin')%20%7D%7D%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ex-button%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ediv%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Egroup%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Atitle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22%24t('Default%20format%3A%20YYYY-MM-DD')%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Edatetime%3C%2Fspan%3E%0A%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3Ev-model%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22value1%22%3C%2Fspan%3E%0A%20%20%20%20%20%20%20%20%40%3Cspan%20class%3D%22hljs-attr%22%3Eon-change%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22change%22%3C%2Fspan%3E%0A%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Atitle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22%24t('Birthday')%22%3C%2Fspan%3E%0A%20%20%20%20%20%20%20%20%40%3Cspan%20class%3D%22hljs-attr%22%3Eon-cancel%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22log('cancel')%22%3C%2Fspan%3E%0A%20%20%20%20%20%20%20%20%40%3Cspan%20class%3D%22hljs-attr%22%3Eon-confirm%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22onConfirm%22%3C%2Fspan%3E%0A%20%20%20%20%20%20%20%20%40%3Cspan%20class%3D%22hljs-attr%22%3Eon-hide%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22log('hide'%2C%20%24event)%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Edatetime%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Egroup%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Egroup%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Atitle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22%24t('Custom%20minute%20list%3A%20every%2015%20minutes')%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Edatetime%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Ev-model%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22minuteListValue%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Eformat%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22YYYY-MM-DD%20HH%3Amm%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Aminute-list%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22%5B'00'%2C%20'15'%2C%20'30'%2C%20'45'%5D%22%3C%2Fspan%3E%20%40%3Cspan%20class%3D%22hljs-attr%22%3Eon-change%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22change%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Atitle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22%24t('Birthday')%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Edatetime%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Egroup%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Egroup%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Atitle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22%24t('Custom%20hour%20list')%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Edatetime%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Ev-model%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22hourListValue%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Eformat%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22YYYY-MM-DD%20HH%3Amm%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Ahour-list%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22%5B'09'%2C%20'10'%2C%20'11'%2C%20'12'%2C%20'13'%2C%20'14'%2C%20'15'%2C%20'16'%5D%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Aminute-list%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22%5B'00'%2C%20'15'%2C%20'30'%2C%20'45'%5D%22%3C%2Fspan%3E%20%40%3Cspan%20class%3D%22hljs-attr%22%3Eon-change%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22change%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Atitle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22%24t('Birthday')%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Edatetime%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Egroup%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Egroup%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Etitle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22Readonly%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Edatetime%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Ev-model%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22valueReadonly%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Areadonly%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22readonly%22%3C%2Fspan%3E%20%40%3Cspan%20class%3D%22hljs-attr%22%3Eon-change%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22change%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Atitle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22%24t('Birthday')%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Edatetime%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Egroup%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ediv%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Estyle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22padding%3A15px%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ex-button%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Etype%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22primary%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Eplain%3C%2Fspan%3E%20%40%3Cspan%20class%3D%22hljs-attr%22%3Eclick.native%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22readonly%20%3D%20!readonly%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%20%7B%7B%20%24t('Toggle%20readonly')%20%7D%7D%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ex-button%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ediv%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%0A%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Egroup%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Atitle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22%24t('Format%20display%20value')%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Edatetime%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Ev-model%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22formatValue%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Adisplay-format%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22formatValueFunction%22%3C%2Fspan%3E%20%40%3Cspan%20class%3D%22hljs-attr%22%3Eon-change%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22change%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Atitle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22%24t('Birthday')%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Edatetime%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Egroup%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ediv%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Estyle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22padding%3A15px%3B%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ex-button%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Etype%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22primary%22%3C%2Fspan%3E%20%40%3Cspan%20class%3D%22hljs-attr%22%3Eclick.native%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22formatValue%20%3D%20'2017-11-11'%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%7B%7B%20%24t('Set%20value%3A%202017-11-11')%20%7D%7D%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ex-button%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ediv%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Egroup%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Atitle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22%24t('Define%20range%20of%20hours')%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Edatetime%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Ev-model%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22limitHourValue%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Eformat%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22YYYY-MM-DD%20HH%3Amm%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Amin-hour%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E9%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Amax-hour%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E18%3C%2Fspan%3E%20%40%3Cspan%20class%3D%22hljs-attr%22%3Eon-change%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22change%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Atitle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22%24t('Define%20range%20of%20hours')%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Ainline-desc%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22%24t('Working%20hours%3A%2009-18')%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Edatetime%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Egroup%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Egroup%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Atitle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22%24t('Set%20start-date%20and%20end-date')%20%2B%20'%202015-11-11%20~%202017-10-11'%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Edatetime%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Ev-model%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22limitHourValue%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Astart-date%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22startDate%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Aend-date%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22endDate%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Eformat%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22YYYY-MM-DD%20HH%3Amm%22%3C%2Fspan%3E%20%40%3Cspan%20class%3D%22hljs-attr%22%3Eon-change%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22change%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Atitle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22%24t('Start%20time')%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Edatetime%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Egroup%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%0A%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Egroup%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Atitle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22%24t('Set%20end-date%20only')%20%2B%20'%202017-10-11'%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Edatetime%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Ev-model%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22onlySetEndDateValue%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Aend-date%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22onlySetEndDate%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Eformat%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22YYYY-MM-DD%20HH%3Amm%22%3C%2Fspan%3E%20%40%3Cspan%20class%3D%22hljs-attr%22%3Eon-change%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22change%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Atitle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22%24t('Start%20time')%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Edatetime%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Egroup%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Egroup%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Atitle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22%24t('Format')%20%2B%20'%3A%20'%20%2B%20format%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Edatetime%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Ev-model%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22value2%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Aformat%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22format%22%3C%2Fspan%3E%20%40%3Cspan%20class%3D%22hljs-attr%22%3Eon-change%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22change%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Atitle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22%24t('Start%20time')%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Edatetime%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Egroup%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ediv%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Estyle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22padding%3A15px%3B%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ex-button%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Etype%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22primary%22%3C%2Fspan%3E%20%40%3Cspan%20class%3D%22hljs-attr%22%3Eclick.native%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22toggleFormat%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%7B%7B%20%24t('Toggle%20format')%20%7D%7D%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ex-button%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ediv%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Egroup%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Etitle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22noon%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Edatetime%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Etitle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22noon%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Ev-model%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22noonValue%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Eformat%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22YYYY-MM-DD%20A%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Edatetime%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Egroup%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Egroup%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Atitle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22%24t('Placeholder')%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Edatetime%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Ev-model%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22value3%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Edefault-selected-value%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%222017-06-18%2013%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Eformat%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22YYYY-MM-DD%20HH%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Aplaceholder%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22%24t('Please%20select')%22%3C%2Fspan%3E%20%40%3Cspan%20class%3D%22hljs-attr%22%3Eon-change%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22change%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Atitle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22%24t('Start%20time')%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Edatetime%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Egroup%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Egroup%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Atitle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22%24t('Set%20default-selected-value%20to%202017-11-11')%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Edatetime%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Ev-model%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22value3_1%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Edefault-selected-value%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%222017-11-11%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Eformat%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22YYYY-MM-DD%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Aplaceholder%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22%24t('Please%20select')%22%3C%2Fspan%3E%20%40%3Cspan%20class%3D%22hljs-attr%22%3Eon-change%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22change%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Atitle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22%24t('Start%20time')%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Ainline-desc%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22%20%24t('Current%20value')%20%2B%20%60%3A%20%24%7Bvalue3_1%7D%60%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Edatetime%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Egroup%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Egroup%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Atitle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22%24t('Set%20min-year%20and%20max-year')%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Edatetime%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Ev-model%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22value4%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Aplaceholder%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22%24t('Please%20select')%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Amin-year%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E2000%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Amax-year%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E2016%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Eformat%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22YYYY-MM-DD%20HH%3Amm%22%3C%2Fspan%3E%20%40%3Cspan%20class%3D%22hljs-attr%22%3Eon-change%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22change%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Atitle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22%24t('Years%20after%202000')%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Edatetime%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Egroup%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Egroup%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Atitle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22%24t('Prop%3A%20compute-hours-function')%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Edatetime%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Eformat%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22YYYY-MM-DD%20HH%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Ev-model%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22computeHoursValue%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Acompute-hours-function%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22computeHoursFunction%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Atitle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22%24t('Birthday')%22%3C%2Fspan%3E%20%40%3Cspan%20class%3D%22hljs-attr%22%3Eon-change%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22change%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Edatetime%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Egroup%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Egroup%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Atitle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22%24t('Prop%3A%20compute-days-function')%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Edatetime%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Eformat%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22YYYY-MM-DD%20HH%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Ev-model%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22computeDaysValue%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Acompute-days-function%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22computeDaysFunction%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Atitle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22%24t('Birthday')%22%3C%2Fspan%3E%20%40%3Cspan%20class%3D%22hljs-attr%22%3Eon-change%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22change%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Edatetime%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Egroup%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Egroup%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Atitle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22%24t('Specified%20template%20text%20in%20Chinese')%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Edatetime%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Ev-model%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22value5%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Aplaceholder%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22%24t('Please%20select')%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Amin-year%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E2000%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Amax-year%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E2016%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Eformat%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22YYYY-MM-DD%20HH%3Amm%22%3C%2Fspan%3E%20%40%3Cspan%20class%3D%22hljs-attr%22%3Eon-change%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22change%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Atitle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22%24t('Chinese')%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Eyear-row%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22%7Bvalue%7D%E5%B9%B4%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Emonth-row%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22%7Bvalue%7D%E6%9C%88%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Eday-row%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22%7Bvalue%7D%E6%97%A5%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Ehour-row%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22%7Bvalue%7D%E7%82%B9%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Eminute-row%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22%7Bvalue%7D%E5%88%86%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Econfirm-text%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22%E5%AE%8C%E6%88%90%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Ecancel-text%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22%E5%8F%96%E6%B6%88%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Edatetime%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Egroup%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Egroup%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Atitle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22%24t('Show%20center%20button%20and%20clear%20the%20value')%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Edatetime%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Ev-model%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22value6%22%3C%2Fspan%3E%20%40%3Cspan%20class%3D%22hljs-attr%22%3Eon-change%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22change%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Atitle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22%24t('Birthday')%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Eclear-text%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22clear%22%3C%2Fspan%3E%20%40%3Cspan%20class%3D%22hljs-attr%22%3Eon-clear%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22clearValue%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Edatetime%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Egroup%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Egroup%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Atitle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22%24t('Show%20center%20button%20to%20set%20date%20to%20today')%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Edatetime%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Ev-model%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22value7%22%3C%2Fspan%3E%20%40%3Cspan%20class%3D%22hljs-attr%22%3Eon-change%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22change%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Atitle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22%24t('Birthday')%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Eclear-text%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22today%22%3C%2Fspan%3E%20%40%3Cspan%20class%3D%22hljs-attr%22%3Eon-clear%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22setToday%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Edatetime%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Egroup%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%0A%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Egroup%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Atitle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22%24t('Custom%20trigger%20slot')%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Edatetime%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Ev-model%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22value7%22%3C%2Fspan%3E%20%40%3Cspan%20class%3D%22hljs-attr%22%3Eon-change%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22change%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Atitle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22%24t('Birthday')%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Eclear-text%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22today%22%3C%2Fspan%3E%20%40%3Cspan%20class%3D%22hljs-attr%22%3Eon-clear%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22setToday%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ex-button%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%7B%7B%24t('Click%20me')%7D%7D%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ex-button%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Edatetime%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Egroup%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Egroup%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Atitle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22%24t('Required')%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Edatetime%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Ev-model%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22value8%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Atitle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22%24t('Required')%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Eclear-text%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22clear%22%3C%2Fspan%3E%20%40%3Cspan%20class%3D%22hljs-attr%22%3Eon-clear%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22clearValue8%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Arequired%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22true%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Edatetime%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Egroup%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Egroup%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Atitle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22%24t('Use%20prop%3A%20show.sync%20(vue%5E2.3)%20to%20control%20visibility')%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Edatetime%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Ev-model%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22value9%22%3C%2Fspan%3E%20%40%3Cspan%20class%3D%22hljs-attr%22%3Eon-change%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22change%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Atitle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22%24t('Birthday')%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Ashow.sync%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22visibility%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Edatetime%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Egroup%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ediv%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Estyle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22padding%3A15px%3B%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ex-button%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Etype%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22primary%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Eplain%3C%2Fspan%3E%20%40%3Cspan%20class%3D%22hljs-attr%22%3Eclick.native%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22visibility%20%3D%20true%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%E6%98%BE%E7%A4%BA%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ex-button%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ediv%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Egroup%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Atitle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22%24t('Default%20format%3A%20YYYY-MM-DD')%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Edatetime%3C%2Fspan%3E%0A%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Aorder-map%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22%7B%0A%20%20%20%20%20%20%20%20%20%20year%3A%203%2C%0A%20%20%20%20%20%20%20%20%20%20month%3A%202%2C%0A%20%20%20%20%20%20%20%20%20%20day%3A%201%0A%20%20%20%20%20%20%20%20%7D%22%3C%2Fspan%3E%0A%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3Ev-model%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22value1%22%3C%2Fspan%3E%0A%20%20%20%20%20%20%20%20%40%3Cspan%20class%3D%22hljs-attr%22%3Eon-change%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22change%22%3C%2Fspan%3E%0A%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3Etitle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22customize%20column%20order%22%3C%2Fspan%3E%0A%20%20%20%20%20%20%20%20%40%3Cspan%20class%3D%22hljs-attr%22%3Eon-cancel%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22log('cancel')%22%3C%2Fspan%3E%0A%20%20%20%20%20%20%20%20%40%3Cspan%20class%3D%22hljs-attr%22%3Eon-confirm%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22onConfirm%22%3C%2Fspan%3E%0A%20%20%20%20%20%20%20%20%40%3Cspan%20class%3D%22hljs-attr%22%3Eon-hide%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22log('hide'%2C%20%24event)%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Edatetime%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Egroup%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%0A%0A%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ediv%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Etemplate%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%0A%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ei18n%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A'Default%20format%3A%20YYYY-MM-DD'%3A%0A%20%20zh-CN%3A%20%E9%BB%98%E8%AE%A4%E6%A0%BC%E5%BC%8F%EF%BC%9AYYYY-MM-DD%0AFormat%3A%0A%20%20zh-CN%3A%20%E6%A0%BC%E5%BC%8F%0AStart%20time%3A%0A%20%20zh-CN%3A%20%E5%BC%80%E5%A7%8B%E6%97%B6%E9%97%B4%0APlaceholder%3A%0A%20%20zh-CN%3A%20%E6%8F%90%E7%A4%BA%E6%96%87%E5%AD%97%0APlease%20select%3A%0A%20%20zh-CN%3A%20%E8%AF%B7%E9%80%89%E6%8B%A9%0ASet%20min-year%20and%20max-year%3A%0A%20%20zh-CN%3A%20%E8%AE%BE%E7%BD%AE%E5%BC%80%E5%A7%8B%E5%92%8C%E7%BB%93%E6%9D%9F%E5%B9%B4%E4%BB%BD%0AYears%20after%202000%3A%0A%20%20zh-CN%3A%202000%E5%B9%B4%E4%BB%A5%E5%90%8E%E7%9A%84%E6%97%B6%E9%97%B4%0ASpecified%20template%20text%20in%20Chinese%3A%0A%20%20zh-CN%3A%20%E8%87%AA%E5%AE%9A%E4%B9%89%E4%B8%AD%E6%96%87%E6%98%BE%E7%A4%BA%E6%A8%A1%E6%9D%BF%0AShow%20center%20button%20and%20clear%20the%20value%3A%0A%20%20zh-CN%3A%20%E6%98%BE%E7%A4%BA%E4%B8%AD%E9%97%B4%E7%9A%84%E6%B8%85%E9%99%A4%E6%8C%89%E9%92%AE%0AShow%20center%20button%20to%20set%20date%20to%20today%3A%0A%20%20zh-CN%3A%20%E6%98%BE%E7%A4%BA%E4%B8%AD%E9%97%B4%E7%9A%84%E8%AE%BE%E7%BD%AE%E6%97%A5%E6%9C%9F%E4%B8%BA%E4%BB%8A%E5%A4%A9%E7%9A%84%E6%8C%89%E9%92%AE%0ABirthday%3A%0A%20%20zh-CN%3A%20%E7%94%9F%E6%97%A5%0AChinese%3A%0A%20%20zh-CN%3A%20%E4%B8%AD%E6%96%87%0AClick%20me%3A%0A%20%20zh-CN%3A%20%E7%82%B9%E6%88%91%0ACustom%20trigger%20slot%3A%0A%20%20zh-CN%3A%20%E8%87%AA%E5%AE%9A%E4%B9%89%E8%A7%A6%E5%8F%91%E5%86%85%E5%AE%B9%0ADefine%20range%20of%20hours%3A%0A%20%20zh-CN%3A%20%E9%99%90%E5%AE%9A%E5%B0%8F%E6%97%B6%E8%8C%83%E5%9B%B4%0A'Working%20hours%3A%2009-18'%3A%0A%20%20zh-CN%3A%20%E5%B7%A5%E4%BD%9C%E6%97%B6%E9%97%B4%E4%B8%BA%2009-18%0ASet%20start-date%20and%20end-date%3A%0A%20%20zh-CN%3A%20%E8%AE%BE%E7%BD%AE%E5%BC%80%E5%A7%8B%E6%97%B6%E9%97%B4%E5%92%8C%E7%BB%93%E6%9D%9F%E6%97%A5%E6%9C%9F%0A'Click%20to%20change%20value%20to%3A%202017-11-11'%3A%0A%20%20zh-CN%3A%20%E8%AE%BE%E7%BD%AE%E6%97%B6%E9%97%B4%E4%B8%BA%202017-11-11%0AFormat%20display%20value%3A%0A%20%20zh-CN%3A%20%E6%A0%BC%E5%BC%8F%E5%8C%96%E6%98%BE%E7%A4%BA%0AToggle%20format%3A%0A%20%20zh-CN%3A%20%E6%94%B9%E5%8F%98%E6%A0%BC%E5%BC%8F%0A'Custom%20minute%20list%3A%20every%2015%20minutes'%3A%0A%20%20zh-CN%3A%20%E8%87%AA%E5%AE%9A%E4%B9%89%E5%88%86%E9%92%9F%E5%88%97%E8%A1%A8%EF%BC%88%E6%AF%8F15%E5%88%86%E9%92%9F%EF%BC%89%0ACustom%20hour%20list%3A%0A%20%20zh-CN%3A%20%E5%AE%9A%E4%B9%89%E5%B0%8F%E6%97%B6%E5%88%97%E8%A1%A8%0A'Use%20prop%3A%20show.sync%20(vue%5E2.3)%20to%20control%20visibility'%3A%0A%20%20zh-CN%3A%20'%E4%BD%BF%E7%94%A8%20prop%3A%20show.sync%20%E6%8E%A7%E5%88%B6%E6%98%BE%E7%A4%BA(vue%5E2.3)'%0AUsed%20as%20a%20plugin%3A%0A%20%20zh-CN%3A%20%E6%8F%92%E4%BB%B6%E5%BD%A2%E5%BC%8F%E8%B0%83%E7%94%A8%0ASet%20default-selected-value%20to%202017-11-11%3A%0A%20%20zh-CN%3A%20%E8%AE%BE%E7%BD%AE%E9%BB%98%E8%AE%A4%E9%80%89%E4%B8%AD%E5%80%BC%E4%B8%BA%202017-11-11%0A'Prop%3A%20compute-hours-function'%3A%0A%20%20zh-CN%3A%20%E8%87%AA%E5%AE%9A%E4%B9%89%E5%B0%8F%E6%97%B6%E5%88%97%E8%A1%A8%E7%94%9F%E6%88%90%E9%80%BB%E8%BE%91%0A'Prop%3A%20compute-days-function'%3A%0A%20%20zh-CN%3A%20%E8%87%AA%E5%AE%9A%E4%B9%89%E6%97%A5%E6%9C%9F%E5%88%97%E8%A1%A8%E7%94%9F%E6%88%90%E9%80%BB%E8%BE%91%0AToggle%20readonly%3A%0A%20%20zh-CN%3A%20%E5%88%87%E6%8D%A2%20readonly%20%E5%B1%9E%E6%80%A7%0A'Set%20value%3A%202017-11-11'%3A%0A%20%20zh-CN%3A%20%E8%AE%BE%E7%BD%AE%E6%97%B6%E9%97%B4%E4%B8%BA2017-11-11%0ASet%20end-date%20only%3A%0A%20%20zh-CN%3A%20%E5%8F%AA%E8%AE%BE%E7%BD%AE%E7%BB%93%E6%9D%9F%E6%97%B6%E9%97%B4%0A%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ei18n%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%0A%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Escript%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22javascript%22%3E%0A%3Cspan%20class%3D%22hljs-keyword%22%3Eimport%3C%2Fspan%3E%20%7B%20Datetime%2C%20Group%2C%20XButton%20%7D%20%3Cspan%20class%3D%22hljs-keyword%22%3Efrom%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-string%22%3E'vux'%3C%2Fspan%3E%0A%0A%3Cspan%20class%3D%22hljs-keyword%22%3Eexport%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-keyword%22%3Edefault%3C%2Fspan%3E%20%7B%0A%20%20%3Cspan%20class%3D%22hljs-attr%22%3Ecomponents%3C%2Fspan%3E%3A%20%7B%0A%20%20%20%20Datetime%2C%0A%20%20%20%20Group%2C%0A%20%20%20%20XButton%0A%20%20%7D%2C%0A%20%20data%20()%20%7B%0A%20%20%20%20%3Cspan%20class%3D%22hljs-keyword%22%3Ereturn%3C%2Fspan%3E%20%7B%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3EnoonValue%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-string%22%3E'2018-04-13%20PM'%3C%2Fspan%3E%2C%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3Ereadonly%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-literal%22%3Etrue%3C%2Fspan%3E%2C%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3EminuteListValue%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-string%22%3E'2017-06-12%2009%3A00'%3C%2Fspan%3E%2C%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3EhourListValue%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-string%22%3E'2017-06-12%2009%3A00'%3C%2Fspan%3E%2C%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3Eformat%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-string%22%3E'YYYY-MM-DD%20HH%3Amm'%3C%2Fspan%3E%2C%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3Evalue1%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-string%22%3E'2015-11-12'%3C%2Fspan%3E%2C%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3EvalueReadonly%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-string%22%3E'2015-11-12'%3C%2Fspan%3E%2C%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3Evalue2%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-string%22%3E''%3C%2Fspan%3E%2C%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3Evalue3%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-string%22%3E''%3C%2Fspan%3E%2C%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3Evalue3_1%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-string%22%3E''%3C%2Fspan%3E%2C%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3Evalue4%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-string%22%3E''%3C%2Fspan%3E%2C%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3Evalue5%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-string%22%3E''%3C%2Fspan%3E%2C%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3Evalue6%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-string%22%3E'2016-08-18'%3C%2Fspan%3E%2C%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3Evalue7%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-string%22%3E''%3C%2Fspan%3E%2C%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3Evalue8%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-string%22%3E''%3C%2Fspan%3E%2C%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3ElimitHourValue%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-string%22%3E''%3C%2Fspan%3E%2C%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3EstartDate%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-string%22%3E'2015-11-11'%3C%2Fspan%3E%2C%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3EendDate%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-string%22%3E'2017-10-11'%3C%2Fspan%3E%2C%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3EformatValue%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-string%22%3E'2017-10-11'%3C%2Fspan%3E%2C%0A%20%20%20%20%20%20formatValueFunction%20(val)%20%7B%0A%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-keyword%22%3Ereturn%3C%2Fspan%3E%20val.replace(%3Cspan%20class%3D%22hljs-regexp%22%3E%2F-%2Fg%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-string%22%3E'%24'%3C%2Fspan%3E)%0A%20%20%20%20%20%20%7D%2C%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3Evalue9%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-string%22%3E''%3C%2Fspan%3E%2C%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3Evisibility%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-literal%22%3Efalse%3C%2Fspan%3E%2C%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3EcomputeHoursValue%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-string%22%3E''%3C%2Fspan%3E%2C%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3EcomputeDaysValue%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-string%22%3E''%3C%2Fspan%3E%2C%0A%20%20%20%20%20%20computeHoursFunction%20(date%2C%20isToday%2C%20generateRange)%20%7B%0A%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-keyword%22%3Eif%3C%2Fspan%3E%20(isToday)%20%7B%0A%20%20%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-keyword%22%3Ereturn%3C%2Fspan%3E%20generateRange(%3Cspan%20class%3D%22hljs-keyword%22%3Enew%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-built_in%22%3EDate%3C%2Fspan%3E().getHours()%2C%20%3Cspan%20class%3D%22hljs-number%22%3E23%3C%2Fspan%3E)%0A%20%20%20%20%20%20%20%20%7D%20%3Cspan%20class%3D%22hljs-keyword%22%3Eelse%3C%2Fspan%3E%20%7B%0A%20%20%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-keyword%22%3Ereturn%3C%2Fspan%3E%20generateRange(%3Cspan%20class%3D%22hljs-number%22%3E0%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-number%22%3E23%3C%2Fspan%3E)%0A%20%20%20%20%20%20%20%20%7D%0A%20%20%20%20%20%20%7D%2C%0A%20%20%20%20%20%20computeDaysFunction%20(options%2C%20generateRange)%20%7B%0A%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-keyword%22%3Ereturn%3C%2Fspan%3E%20%5Boptions.month%5D%20%3Cspan%20class%3D%22hljs-comment%22%3E%2F%2F%20if%20current%20month%20is%20n%2C%20days%20are%20%5Bn%5D%3C%2Fspan%3E%0A%20%20%20%20%20%20%7D%2C%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3EonlySetEndDate%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-string%22%3E'2017-10-11'%3C%2Fspan%3E%2C%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3EonlySetEndDateValue%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-string%22%3E''%3C%2Fspan%3E%0A%20%20%20%20%7D%0A%20%20%7D%2C%0A%20%20%3Cspan%20class%3D%22hljs-attr%22%3Emethods%3C%2Fspan%3E%3A%20%7B%0A%20%20%20%20log%20(str1%2C%20str2%20%3D%20%3Cspan%20class%3D%22hljs-string%22%3E''%3C%2Fspan%3E)%20%7B%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-built_in%22%3Econsole%3C%2Fspan%3E.log(str1%2C%20str2)%0A%20%20%20%20%7D%2C%0A%20%20%20%20onConfirm%20(val)%20%7B%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-built_in%22%3Econsole%3C%2Fspan%3E.log(%3Cspan%20class%3D%22hljs-string%22%3E'on-confirm%20arg'%3C%2Fspan%3E%2C%20val)%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-built_in%22%3Econsole%3C%2Fspan%3E.log(%3Cspan%20class%3D%22hljs-string%22%3E'current%20value'%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-keyword%22%3Ethis%3C%2Fspan%3E.value1)%0A%20%20%20%20%7D%2C%0A%20%20%20%20showPlugin%20()%20%7B%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-keyword%22%3Ethis%3C%2Fspan%3E.%24vux.datetime.show(%7B%0A%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3EcancelText%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-string%22%3E'%E5%8F%96%E6%B6%88'%3C%2Fspan%3E%2C%0A%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3EconfirmText%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-string%22%3E'%E7%A1%AE%E5%AE%9A'%3C%2Fspan%3E%2C%0A%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3Eformat%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-string%22%3E'YYYY-MM-DD%20HH'%3C%2Fspan%3E%2C%0A%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3Evalue%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-string%22%3E'2017-05-20%2018'%3C%2Fspan%3E%2C%0A%20%20%20%20%20%20%20%20onConfirm%20(val)%20%7B%0A%20%20%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-built_in%22%3Econsole%3C%2Fspan%3E.log(%3Cspan%20class%3D%22hljs-string%22%3E'plugin%20confirm'%3C%2Fspan%3E%2C%20val)%0A%20%20%20%20%20%20%20%20%7D%2C%0A%20%20%20%20%20%20%20%20onShow%20()%20%7B%0A%20%20%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-built_in%22%3Econsole%3C%2Fspan%3E.log(%3Cspan%20class%3D%22hljs-string%22%3E'plugin%20show'%3C%2Fspan%3E)%0A%20%20%20%20%20%20%20%20%7D%2C%0A%20%20%20%20%20%20%20%20onHide%20()%20%7B%0A%20%20%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-built_in%22%3Econsole%3C%2Fspan%3E.log(%3Cspan%20class%3D%22hljs-string%22%3E'plugin%20hide'%3C%2Fspan%3E)%0A%20%20%20%20%20%20%20%20%7D%0A%20%20%20%20%20%20%7D)%0A%20%20%20%20%7D%2C%0A%20%20%20%20toggleFormat%20()%20%7B%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-keyword%22%3Eif%3C%2Fspan%3E%20(%3Cspan%20class%3D%22hljs-keyword%22%3Ethis%3C%2Fspan%3E.format%20%3D%3D%3D%20%3Cspan%20class%3D%22hljs-string%22%3E'YYYY-MM-DD'%3C%2Fspan%3E)%20%7B%0A%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-keyword%22%3Ethis%3C%2Fspan%3E.format%20%3D%20%3Cspan%20class%3D%22hljs-string%22%3E'YYYY-MM-DD%20HH%3Amm'%3C%2Fspan%3E%0A%20%20%20%20%20%20%7D%20%3Cspan%20class%3D%22hljs-keyword%22%3Eelse%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-keyword%22%3Eif%3C%2Fspan%3E%20(%3Cspan%20class%3D%22hljs-keyword%22%3Ethis%3C%2Fspan%3E.format%20%3D%3D%3D%20%3Cspan%20class%3D%22hljs-string%22%3E'YYYY-MM-DD%20HH%3Amm'%3C%2Fspan%3E)%20%7B%0A%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-keyword%22%3Ethis%3C%2Fspan%3E.format%20%3D%20%3Cspan%20class%3D%22hljs-string%22%3E'YYYY-MM-DD'%3C%2Fspan%3E%0A%20%20%20%20%20%20%7D%0A%20%20%20%20%7D%2C%0A%20%20%20%20change%20(value)%20%7B%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-built_in%22%3Econsole%3C%2Fspan%3E.log(%3Cspan%20class%3D%22hljs-string%22%3E'change'%3C%2Fspan%3E%2C%20value)%0A%20%20%20%20%7D%2C%0A%20%20%20%20clearValue%20(value)%20%7B%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-keyword%22%3Ethis%3C%2Fspan%3E.value6%20%3D%20%3Cspan%20class%3D%22hljs-string%22%3E''%3C%2Fspan%3E%0A%20%20%20%20%7D%2C%0A%20%20%20%20clearValue8%20(value)%20%7B%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-keyword%22%3Ethis%3C%2Fspan%3E.value8%20%3D%20%3Cspan%20class%3D%22hljs-string%22%3E''%3C%2Fspan%3E%0A%20%20%20%20%7D%2C%0A%20%20%20%20setToday%20(value)%20%7B%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-keyword%22%3Elet%3C%2Fspan%3E%20now%20%3D%20%3Cspan%20class%3D%22hljs-keyword%22%3Enew%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-built_in%22%3EDate%3C%2Fspan%3E()%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-keyword%22%3Elet%3C%2Fspan%3E%20cmonth%20%3D%20now.getMonth()%20%2B%20%3Cspan%20class%3D%22hljs-number%22%3E1%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-keyword%22%3Elet%3C%2Fspan%3E%20day%20%3D%20now.getDate()%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-keyword%22%3Eif%3C%2Fspan%3E%20(cmonth%20%26lt%3B%20%3Cspan%20class%3D%22hljs-number%22%3E10%3C%2Fspan%3E)%20cmonth%20%3D%20%3Cspan%20class%3D%22hljs-string%22%3E'0'%3C%2Fspan%3E%20%2B%20cmonth%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-keyword%22%3Eif%3C%2Fspan%3E%20(day%20%26lt%3B%20%3Cspan%20class%3D%22hljs-number%22%3E10%3C%2Fspan%3E)%20day%20%3D%20%3Cspan%20class%3D%22hljs-string%22%3E'0'%3C%2Fspan%3E%20%2B%20day%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-keyword%22%3Ethis%3C%2Fspan%3E.value7%20%3D%20now.getFullYear()%20%2B%20%3Cspan%20class%3D%22hljs-string%22%3E'-'%3C%2Fspan%3E%20%2B%20cmonth%20%2B%20%3Cspan%20class%3D%22hljs-string%22%3E'-'%3C%2Fspan%3E%20%2B%20day%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-built_in%22%3Econsole%3C%2Fspan%3E.log(%3Cspan%20class%3D%22hljs-string%22%3E'set%20today%20ok'%3C%2Fspan%3E)%0A%20%20%20%20%7D%0A%20%20%7D%0A%7D%0A%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Escript%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%0A%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Estyle%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Escoped%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Elang%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22less%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22css%22%3E%0A%3Cspan%20class%3D%22hljs-selector-class%22%3E.center%3C%2Fspan%3E%20%7B%0A%20%20%3Cspan%20class%3D%22hljs-attribute%22%3Epadding-top%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-number%22%3E10px%3C%2Fspan%3E%3B%0A%20%20%3Cspan%20class%3D%22hljs-attribute%22%3Epadding-left%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-number%22%3E15px%3C%2Fspan%3E%3B%0A%20%20%3Cspan%20class%3D%22hljs-attribute%22%3Ecolor%3C%2Fspan%3E%3A%20green%3B%0A%7D%0A%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Estyle%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%3C%2Fcode%3E%3C%2Fpre%3E`)

  const domainMap = {
    'development': 'http://localhost:8080/',
    'production': 'https://vux.li/demos/v2/'
  }

  export default {
    head: {
      title: 'Datetime component tutorial | VUX - Vue.js Mobile UI Component Framework',
      meta: [{
        name: 'description',
        content: 'Vue component datetime for the VUX framework.'
      }, {
        name: 'keywords',
        content: 'datetime, vue-datetime, vux-datetime, vue mobile components'
      }, {
        property: 'og:title',
        content: 'Datetime component tutorial | VUX - Vue.js Mobile UI Component Framework'
      }, {
        property: 'og:description',
        content: 'Vue component datetime for the VUX framework.'
      }],
      // https://support.google.com/webmasters/answer/189077?hl=en
      link: [{"rel":"alternate","hreflang":"zh-CN","href":"/zh-CN/components/datetime.html"}],
      script: [
        {
          innerHTML:'{"@context":"http://schema.org/","@type":"SoftwareApplication","name":"Vue Component datetime","screenshot":"","description":"Vue.js component for VUX","url":"/en/components/datetime.html","applicationCategory":"Component","author":{"@type":"Organization","name":"VUX","url":"https://vux.li"},"downloadUrl":"https://vux.li","softwareVersion":"2.9.2","aggregateRating":{"@type":"AggregateRating","ratingValue":5,"reviewCount":94},"operatingSystem":"iOS >= 7, Android >= 4.1","offers":{"@type":"Offer","price":0,"priceCurrency":"USD","availability":"http://schema.org/InStock"}}',
          type: 'application/ld+json'
        }
      ],
      __dangerouslyDisableSanitizers: ['script']
    },
    filters: {
      parseCode (str) {
        return str.replace(/`(.*?)`/g, '<code>$1</code>')
      }
    },
    async mounted () {
      const rs = await Axios.get('https://api.github.com/search/issues?q=repo:airyland/vux%20label:component/' + this.componentName)
      this.issues = rs.data.items
      this.hasReady = true
    },
    watch: {
      async sourceCodeDialogVisibility (val) {
        if (val) {
          await this.$nextTick()
          const mask = document.querySelector('.v-modal')
          mask && mask.addEventListener('click', () => {
            this.sourceCodeDialogVisibility = false
          })
        }
      }
    },
    methods: {
      onCopyError () {
        this.$message({
          type: 'error',
          message: 'copy fail!'
        })
      },
      onCopy () {
        this.$message({
          type: 'success',
          message: 'copy done!'
        })
      },
      showSourceCode () {
        this.sourceCodeDialogVisibility = true
      },
      getTypeHTML (type) {
        type = type || 'String'
        if (/,/.test(type)) {
          const list = type.split(',').map(function (one) {
            return one.replace(/^s+|s+$/g, '')
          }).map(function (one) {
            const type = one ?  one.toLowerCase() : 'string'
            return '<span class="type">' + type + '</span>'
          })
          return list.join('<br>')
        } else {
          type = type ?  type.toLowerCase() : 'string'
          return '<span class="type">' + type + '</span>'
        }
      }
    },
    computed: {
      lang () {
        if (this.$route.path.indexOf('/en/') !== -1) {
          return 'en'
        }
        if (this.$route.path.indexOf('/zh-CN/') !== -1) {
          return 'zh-CN'
        }
        return 'en'
      }
    },
    data () {
      return {
        demos,
        isBeta: false,
        hasReady: false,
        issues: [],
        componentName: 'datetime',
        demoCode,
        sourceCodeDialogVisibility: false,
        showQr: false,
        metas: metas,
        gitMetas,
        componentList,
        localImportCode: `import { Datetime } from 'vux'

export default {
  components: {
    Datetime
  }
}`,
        globalImportCode: `// you can also register globally

import Vue from 'vue'
import { Datetime } from 'vux'

Vue.component('datetime', Datetime)
`,
        needImport: true,
        toc: [],
        domain: domainMap[process.env.NODE_ENV]
      }
    }
  }
  </script>

  <style>
  .component-box {
    position: relative;
  }
  .component-demo {
    position: absolute;
    right: 5px;
    top: 15px;
  }
  .prop-color {
    display: inline-block;
    width: 10px;
    height: 10px;
    border: 1px solid #aaa;
  }
  .changelog-version {
    width: 110px;
    display: inline-block;
  }
  .component-extra-links {
    position: relative;
    font-size: 12px;
  }
  .component-extra-links a {
    padding-right: 10px;
    color: #999;
  }
  </style>
    