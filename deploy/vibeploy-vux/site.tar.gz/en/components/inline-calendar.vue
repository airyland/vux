
  <template>
    <div class="component-box" :class="demos.length ? 'components-with-toc' : ''">

      <div :class="demos.length ? 'component-header-v2' : 'component-header-v1'">
        <a class="anchor" id="intro">InlineCalendar</a>
        <div class="title-box">

          <el-badge value="Beta" v-if="isBeta">
            <h1 class="vux-component-name">InlineCalendar</h1>
          </el-badge>
          <h1 v-else class="vux-component-name">InlineCalendar</h1>

          <p class="component-extra-links">
            <a href="https://vux.li/demos/v2/#/component/inline-calendar" target="_blank">demo url</a>
            <a v-if="!demos.length" href="https://github.com/airyland/vux/blob/v2/src/demos/InlineCalendar.vue" target="_blank" @click.prevent="showSourceCode">demo source code</a>
            <a href="https://github.com/airyland/vux/blob/v2/src/components/inline-calendar/metas.yml" target="_blank">edit document</a>
            <a href="https://github.com/airyland/vux/blob/v2/src/components/inline-calendar/" target="_blank">component source code</a>
            <el-popover trigger="hover" v-if="hasReady">
              <div style="width:100%;text-align:center;">
                <img class="qr" width="100" src="https://qr.vux.li/api.php?text=https%3A%2F%2Fvux.li%2Fdemos%2Fv2%2F%23%2Fcomponent%2Finline-calendar"/>
              </div>
              <a href="javascript:" slot="reference">
              view demos on mobile
              </a>
            </el-popover>
          </p>

          <div class="component-description">
            <template v-if="false">
            
            </template>
          </div>

        </div>

        <div v-if="!demos.length" class="component-demo" style="width:377px;height:600px;display:inline-block;border:1px solid #ececec;border-radius:5px;overflow:hidden;z-index:2500;">
          <iframe src="https://vux.li/demos/v2?locale=en&transition=none/#/component/inline-calendar" width="375" height="600" border="0" frameborder="0"></iframe>
        </div>
        <div class="toc">
          <ul v-for="t in toc">
            <li>
              <a :href="'#' + (t.anchor || t.title)">{{ t.title }}</a>
              <ul v-if="t.list" v-for="_t in t.list">
                <li><a :href="'#' + _t.anchor">{{ _t.title.slice(0, 12) }}</a></li>
              </ul>
            </li>
          </ul>
        </div>
      
        <template v-if="needImport">
          <a class="anchor" id="install">Install</a>
          <h2>Install</h2>
          <el-tabs>
            <el-tab-pane label="Local Registration">
              <div class="import-code-box">
              <el-tooltip content="click to copy" placement="top">
                <span
                  v-clipboard:copy="localImportCode"
                  v-clipboard:success="onCopy"
                  v-clipboard:error="onCopyError">
                  <el-icon class="el-icon-document"></el-icon>
                </span>
              </el-tooltip>
              <pre class="hljs"><code><span class="hljs-keyword">import</span> { InlineCalendar } <span class="hljs-keyword">from</span> <span class="hljs-string">'vux'</span>

<span class="hljs-keyword">export</span> <span class="hljs-keyword">default</span> {
  <span class="hljs-attr">components</span>: {
    InlineCalendar
  }
}</code></pre>
            </div>
            </el-tab-pane>
            <el-tab-pane label="Global Registration">
              <div class="import-code-box">
                <el-tooltip content="click to copy" placement="top">
                  <span
                    v-clipboard:copy="globalImportCode"
                    v-clipboard:success="onCopy"
                    v-clipboard:error="onCopyError">
                    <el-icon class="el-icon-document"></el-icon>
                  </span>
                </el-tooltip>
                <pre class="hljs"><code><span class="hljs-comment">// you can also register globally</span>

<span class="hljs-keyword">import</span> Vue <span class="hljs-keyword">from</span> <span class="hljs-string">'vue'</span>
<span class="hljs-keyword">import</span> { InlineCalendar } <span class="hljs-keyword">from</span> <span class="hljs-string">'vux'</span>

Vue.component(<span class="hljs-string">'inline-calendar'</span>, InlineCalendar)
</code></pre>
              </div> 
            </el-tab-pane>
          </el-tabs>   
        </template>

        <template v-else>
          <div class="tip">
            <p>You don't need to import this component.</p>
          </div>
        </template>

        <div class="tip" style="width:600px;" v-if="metas.tip">
          
        </div>
      
        <h2 v-if="metas.example">example</h2>
        <div v-if="metas.example" style="width:600px;">
          
        </div>
      </div>

      <div v-if="metas.extra && metas.extra['en']">
        
      </div>
      <div v-if="metas.extra && !metas.extra['en']">
        
      </div>
      
      <a v-if="demos.length" class="anchor" id="examples">Examples</a>
      <br/>
      <template v-if="demos.length" v-for="demo in demos">
        <a class="anchor" :id="'examples:' + demo.title">{{ demo.title }}</a>
        <br/>
        <div class="demo-header">
          <span class="demo-title">{{ demo.title }}</span>
        </div>
        <div class="demos" :style="{height: demo.height}">
          <div class="demo-iframe-box">
            <lazy-component>
              <iframe
                :src="domain + '?no-background-color=' + demo.noBackgroundColor +'&locale=en&transition=none&hide-nav=true&hide-tab-bar=true#/components/' + demo.file"
                width="375"
                height="600"
                border="0"
                frameborder="0"
                style="margin: 0 auto;"></iframe>
            </lazy-component>
          </div>
          <div class="demo-code-box" :style="{overflow: demo.height === demo.oriHeight ? 'hidden' : 'scroll'}">
            <div v-html="demo.code" contenteditable></div>
            <div v-if="demo.height === demo.oriHeight" class="demo-code-masker" @click="demo.height='auto'">
              <div>
                  <img class="demo-qr" width="100" :src="'https://qr.vux.li/api.php?text=' + encodeURIComponent(domain + '?locale=en#/components/' + demo.file)"/>
                  <br/>
                  <span>
                    <el-icon class="el-icon-arrow-left"/>
                    <el-icon class="el-icon-arrow-right"/>
                    Show code
                  <br/>
                  <!--<span class="demo-path">src/demos/{{ demo.file }}.vue</span>-->
                </span>
              </div>
            </div>
            <span v-if="demo.height === 'auto'" class="hide-code" @click="demo.height=demo.oriHeight">
              <el-icon class="el-icon-close"></el-icon>
            </span>
          </div>
        </div>
      </template>

      <template v-for="component in componentList">
        <div>
          <a v-if="componentList.length > 1" class="anchor" :id="'components:' + component.name">{{ component.name }}</a>
          <a v-else class="anchor" id="api">API</a>
          <br/>
          <h2
            v-show="componentList.length > 1"
            class="vux-component-name-sub-item">{{ component.name }}</h2>
            
          <template v-if="component.meta.items && component.meta.description">
            <div v-html="component.meta.description"></div>
          </template>

          <template v-if="component.meta.props">
            <h2>Props</h2>
            <table>
              <thead>
                <tr>
                  <td>name</td>
                  <td style="width:48px;">type</td>
                  <td>default</td>
                  <td>description</td>
                  <td>required version</td>
                </tr>
              </thead>
              <tbody>
                <tr v-for="(prop, i) in component.meta.props">
                  <td class="prop-name">
                    <el-tooltip content="click to copy" placement="left" :hide-after="0" :open-delay="50">
                      <span
                      v-clipboard:copy="i"
                      v-clipboard:success="onCopy">{{ i }}</span>
                    </el-tooltip>
                  </td>
                  <td v-html="getTypeHTML(prop.type)"></td>
                  <td>{{ prop.default}}</td>
                  <td v-html="prop['en'].replace(/`(.*?)`/g, '<code>$1</code>')"></td>
                  <td>{{ prop.version || '--'}}</td>
                </tr>
              </tbody>
            </table>
          </template>

          <template v-if="component.meta.events">
            <h2>Events</h2>
            <table>
              <thead>
                <tr>
                  <td>name</td>
                  <td>params</td>
                  <td>description</td>
                  <td>required version</td>
                </tr>
              </thead>
              <tbody>
                <tr v-for="(event, i) in component.meta.events">
                  <td class="prop-name">
                    <el-tooltip content="click to copy" placement="left" :hide-after="0" :open-delay="50">
                      <span
                      v-clipboard:copy="'@' + i"
                      v-clipboard:success="onCopy">@{{ i }}</span>
                    </el-tooltip>
                  </td>
                  <td v-html="event.params ? event.params.replace(/`(.*?)`/g, '<code>$1</code>') : '--'"></td>
                  <td v-html="event['en'] ? event['en'].replace(/`(.*?)`/g, '<code>$1</code>') : '--'"></td>
                  <td>{{ event['version'] || '--' }}</td>
                </tr>
              </tbody>
            </table>
          </template>
      

          <template v-if="component.meta.slots">
            <h2>Slots</h2>
            <table>
              <thead>
                <tr>
                  <td>name</td>
                  <td>description</td>
                  <td>required version</td>
                </tr>
              </thead>
              <tbody>
                <tr v-for="(slot, i) in component.meta.slots" :class="{'slot-disabled': slot['status'] === 'deprecated'}">
                  <td class="prop-name">
                    <el-tooltip content="click to copy" placement="left" :hide-after="0" :open-delay="50">
                      <span
                      v-clipboard:copy="i"
                      v-clipboard:success="onCopy">{{ i === 'default' ? 'default' : i }}</span>
                    </el-tooltip>
                  </td>
                  <td v-html="slot['en'] ? slot['en'].replace(/`(.*?)`/g, '<code>$1</code>') : ''"></td>
                  <td>{{ slot['version'] || '--' }}</td>
                </tr>
              </tbody>
            </table>
          </template>
          
          <template v-if="component.meta.methods">
            <h2>Functions</h2>
            <table>
              <thead>
                <tr>
                  <td>name</td>
                  <td>params</td>
                  <td>description</td>
                  <td>required version</td>
                </tr>
              </thead>
              <tbody>
                <tr v-for="(method, i) in component.meta.methods">
                  <td class="prop-name">
                    <el-tooltip content="click to copy" placement="left" :hide-after="0" :open-delay="50">
                      <span
                      v-clipboard:copy="i"
                      v-clipboard:success="onCopy">{{ i }}</span>
                    </el-tooltip>
                  </td>
                  <td v-html="method['params'] ? method['params'].replace(/`(.*?)`/g, '<code>$1</code>') : ''"></td>
                  <td v-html="method['en'].replace(/`(.*?)`/g, '<code>$1</code>')"></td>
                  <td>{{ method['version'] }}</td>
                </tr>
              </tbody>
            </table>
          </template>

          <template v-if="component.meta.variables">
            <a class="anchor" id="variables">Variables</a>
            <br/>
            <h2>Variables</h2>
            <table>
              <thead>
                <tr>
                  <td>name</td>
                  <td>default</td>
                  <td>description</td>
                  <td>inherited name</td>
                </tr>
              </thead>
              <tbody>
                <tr v-for="(variable, i) in component.meta.variables">
                  <td class="prop-name">
                    <el-tooltip content="click to copy" placement="left" :hide-after="0" :open-delay="50">
                      <span
                      v-clipboard:copy="'@' + variable.name"
                      v-clipboard:success="onCopy">@{{ variable.name }}</span>
                    </el-tooltip>
                  </td>
                  <td>
                    <em
                      :ref="'propColor' + i"
                      v-if="!$refs['propColor' + i] || ($refs['propColor' + i][0] && $refs['propColor' + i][0].style.backgroundColor)"
                      class="prop-color"
                      :style="{ backgroundColor: variable.value }">
                    </em>
                    {{ variable.value }}
                  </td>
                  <td>{{ variable['desc']['en'] || '--' }}</td>
                  <td>{{ variable.inherited_name }}</td>
                </tr>
              </tbody>
            </table>
          </template>
      
          <template v-if="component.meta.tips && component.meta.tips['en']">
            <a class="anchor" id="tips">Tips</a>
            <br>
            <h2>Tips</h2>
            <div>
              <ul>
                <li v-for="tip in component.meta.tips['en']">
                <el-tag size="mini" type="success" class="component-tip-tag">Q</el-tag> <span class="component-tip-question">{{ tip.q }}</span>
                <div v-html="tip.a" class="tip-answer-box"></div>
                </li>
              </ul>
            </div>
          </template>
        </div>
      </template>

      <!--<h2>社区相关讨论</h2>
      [即将上线]
      -->
    
      <br>
      <div v-if="issues.length">
        <a class="anchor" id="Issues">Issues</a>
        <br/>
        <h2>Related issues</h2>
        <ul>
          <li v-for="issue in issues"><a target="_blank" :href="issue.html_url">#{{ issue.number}} <span style="color:#666;">{{ issue.title }}</span></a></li>
        </ul>
      </div>
      <br>
    
      <div v-if="gitMetas">
        <a class="anchor" id="contributors">Contributors</a>
        <h2>Contributors</h2>
        <p>Total commits quantity: {{ gitMetas.commitCount }}，Total contributors quantity: {{gitMetas.commitUniqueCount}}
        </p>
        <a v-for="person in gitMetas.commitMembers" class="contributor-item" :href="'https://github.com/' + person.authorName" target="_blank" :title="'contribute' + person.count">{{person.authorName}}</a>
      </div>
      <br>

      <div v-if="metas.changes">
        <a class="anchor" id="changelog">Changelog</a>
        <br/>
        <h2>Releases</h2>
        <ul v-if="metas.changes">
          <template v-for="(changelog, version) in metas.changes">
            <li v-for="log in changelog['en']">
              <router-link :to="'/en/changelog/' + version + '.html'" class="changelog-version">{{version}}</router-link> {{log}}
            </li>
          </template>
        </ul>
      </div>

      <h2 v-if="metas.references">Referrences</h2>
      <ul v-if="metas.references">
        <li v-for="link in metas.references['en']">
          <a :href="link.link" target="_blank">{{link.title}}</a>
        </li>
      </ul>

      <el-dialog
        class="sourcec-code-dialog"
        top="0"
        width="80%"
        :visible.sync="sourceCodeDialogVisibility">
        <div class="code-box" contenteditable v-html="demoCode"></div>
      </el-dialog>

    </div>
  </template>


  <script>
  import Axios from 'axios'

  // const metas = require('json-loader!yaml-loader!../../../src/components/inline-calendar/metas.yml')
  const metas = {
  "category": {
    "en": "Form",
    "zh-CN": "表单"
  },
  "icon": "&#xe62b;",
  "tags": {
    "en": [
      "form",
      "calendar"
    ],
    "zh-CN": [
      "日历",
      "表单"
    ]
  },
  "props": {
    "value": {
      "type": "String, Array",
      "default": "",
      "en": "calendar value, use `v-modle` for binding. String (including empty) means single seleciton; array (including empty array) means multiple selection.",
      "zh-CN": "当前选中日期，使用`v-model`绑定。值为字符串(包括空字符串)时表示单选日期，为数组(包括空数组)时表示多选。"
    },
    "render-month": {
      "type": "Array",
      "default": "",
      "en": "specify which date to render, for example [2018, 8]",
      "zh-CN": "指定渲染日期，如 [2018, 8]"
    },
    "start-date": {
      "type": "String",
      "default": "",
      "en": "start date with format `YYYY-MM-dd`",
      "zh-CN": "起始日期，格式为 `YYYY-MM-dd`"
    },
    "end-date": {
      "type": "String",
      "default": "",
      "en": "end date with format `YYYY-MM-dd`",
      "zh-CN": "结束日期，格式为`YYYY-MM-dd`"
    },
    "show-last-month": {
      "type": "Boolean",
      "default": true,
      "en": "if show last month's days",
      "zh-CN": "是否显示上个月的日期"
    },
    "show-next-month": {
      "type": "Boolean",
      "default": true,
      "en": "if show next month's days",
      "zh-CN": "是否显示下个月的日期"
    },
    "highlight-weekend": {
      "type": "Boolean",
      "default": false,
      "en": "if highlight weekend days",
      "zh-CN": "是否高亮周末"
    },
    "return-six-rows": {
      "type": "Boolean",
      "default": true,
      "en": "if always show six rows",
      "zh-CN": "是否总是渲染6行日期"
    },
    "hide-header": {
      "type": "Boolean",
      "default": false,
      "en": "if hiding header",
      "zh-CN": "是否隐藏日历头部"
    },
    "hide-week-list": {
      "type": "Boolean",
      "default": false,
      "en": "if hiding week list",
      "zh-CN": "是否隐藏星期列表"
    },
    "replace-text-list": {
      "type": "Object",
      "default": "",
      "en": "replace list, for example, {'TODAY':'今'}",
      "zh-CN": "替换列表，可以将默认的日期换成文字，比如今天的日期替换成今，{'TODAY':'今'}"
    },
    "weeks-list": {
      "type": "Array",
      "default": "['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa']",
      "en": "week list, starting from `Sunday`",
      "zh-CN": "星期列表，从周日开始"
    },
    "render-function": {
      "type": "Function",
      "default": "",
      "en": "render function to add extra contents, params `(line, row, dateData)`",
      "zh-CN": "用于为特定日期添加额外的html内容，参数为(行index,列index,日期详细属性)"
    },
    "render-on-value-change": {
      "type": "Boolean",
      "default": true,
      "en": "if re-render calendar if value changes, should set to false when showing multi months",
      "zh-CN": "当日期变化时是否重新渲染日历，如果是渲染了多个日历的话需要设为false"
    },
    "disable-past": {
      "type": "Boolean",
      "default": false,
      "en": "if disable the past days, can work with start-date",
      "zh-CN": "禁止选择过去的日期，该选项可以与 start-date 同时使用"
    },
    "disable-future": {
      "type": "Boolean",
      "default": false,
      "en": "if disable future days, can work with end-date",
      "zh-CN": "禁止选择未来的日期，该选项可以 end-date 同时使用"
    },
    "marks": {
      "version": "v2.6.0",
      "type": "Array",
      "en": "(beta) style marks for specified date list",
      "zh-CN": "(beta) 自定义日期标记"
    },
    "disable-weekend": {
      "version": "v2.7.0",
      "type": "Boolean",
      "default": false,
      "en": "whether disable weekends",
      "zh-CN": "是否禁用周六日"
    },
    "disable-date-function": {
      "version": "v2.7.0",
      "type": "Function",
      "params": "`(date)`",
      "en": "check if a date should be disabled",
      "zh-CN": "自定义标记特定日期是否应该禁用，返回 true 表示禁用，false 表示不禁用，不返回表示和原有逻辑一致(这样不影响和 disable-weekend 等禁用属性同时使用)"
    }
  },
  "slots": {
    "each-day": {
      "version": "v2.3.5",
      "en": "you can custom how to display each day",
      "zh-CN": "用以自定义每一天的显示渲染，推荐使用该 slot 来替代 render-function"
    }
  },
  "events": {
    "on-change": {
      "en": "emits when value is changed",
      "zh-CN": "值变化时触发"
    },
    "on-view-change": {
      "version": "v2.5.12",
      "params": "(data, index)",
      "en": "fires when render month is changed",
      "zh-CN": "渲染月份变化时触发。初始化时会触发一次，如果不希望处理初始化时的触发，可以检查第二个参数是否为 0"
    },
    "on-select-single-date": {
      "version": "2.7.6",
      "params": "(currentValue)",
      "en": "fires when date is selected in radio mode",
      "zh-CN": "单选模式下选中日期时触发"
    }
  },
  "methods": {
    "getDates": {
      "version": "v2.5.11",
      "en": "get current date list",
      "zh-CN": "获取当前日期列表"
    },
    "switchViewToToday": {
      "version": "v2.5.12",
      "en": "render current month",
      "zh-CN": "渲染当天所在月份"
    },
    "switchViewToMonth": {
      "version": "v2.5.12",
      "params": "(year, month)",
      "en": "render specified year and month",
      "zh-CN": "渲染特定年月日期"
    },
    "switchViewToCurrentValue": {
      "version": "v2.5.12",
      "en": "render with current value's month",
      "zh-CN": "渲染当前值所在月份"
    }
  },
  "changes": {
    "v2.7.6": {
      "en": [
        "[feature] add event:on-select-single-date"
      ],
      "zh-CN": [
        "[feature] 添加事件 on-select-single-date"
      ]
    },
    "v2.7.3": {
      "en": [
        "[fix] disable-date-function result conflicts with disable-weekend #2189"
      ],
      "zh-CN": [
        "[fix] 修复 disable-date-function 取值与禁用周末逻辑冲突 #2189"
      ]
    },
    "v2.7.2": {
      "en": [
        "[fix] fix reset-value issue in multiple mode #2160",
        "[fix] fix props missing in calendar #2105",
        "[fix] fix disabled weekends still selectable #2178"
      ],
      "zh-CN": [
        "[fix] 修复多选情况下重置值时没有正确渲染的问题 #2160",
        "[fix] 修复部分属性没有继承 inline-calendar 的问题 #2105",
        "[fix] 修复禁用周末日期仍能点击的问题 #2178"
      ]
    },
    "v2.7.0": {
      "en": [
        "[enhance] call render function on created hook instead of mounted(ssr)",
        "[feature] add prop:disable-weekend #2105",
        "[feature] add prop:disable-date-function #2105",
        "[fix] remove useless re-render function #2066"
      ],
      "zh-CN": [
        "[enhance] 在 created hook 执行渲染而不是 mounted(ssr)",
        "[feature] 添加属性 prop:disable-weekend 来禁用周末 #2105",
        "[feature] 添加属性 prop:disable-date-function 自定义标记禁用日期 #2105",
        "[fix] 移除重复的多次重复渲染 #2066"
      ]
    },
    "v2.6.0": {
      "en": [
        "[feature] (beta) Support prop:marks to style specified date item",
        "[fix] fix i18n for days"
      ],
      "zh-CN": [
        "[feature] (beta) 支持属性 marks 用以自定义特定日期显示样式",
        "[fix] 修复星期文字 i18n"
      ]
    },
    "v2.5.12": {
      "en": [
        "[feature] add method:switchViewToToday switchViewToMonth",
        "[feature] support event:on-view-change"
      ],
      "zh-CN": [
        "[feature] 支持 switchViewToToday, switchViewToMonth 等手动渲染方法",
        "[feature] 支持事件 on-view-change，方便切换月份时请求数据"
      ]
    },
    "v2.5.11": {
      "en": [
        "[feature] support method:getDates",
        "[feature] support less variable @calendar-bg-color"
      ],
      "zh-CN": [
        "[feature] 支持方法 getDates 用于需要获取渲染日期列表的场合",
        "[feature] 支持 less 变量 @calendar-bg-color"
      ]
    },
    "v2.5.9": {
      "en": [
        "[fix] donot set value to empty string when clicking on current selected item #1862"
      ],
      "zh-CN": [
        "[fix] 点击当前日期项时不把值置为空 #1862"
      ]
    },
    "v2.5.8": {
      "en": [
        "[fix] fix on-change event fires twice #1847"
      ],
      "zh-CN": [
        "[fix] 修复 on-change 事件触发两次问题 #1847"
      ]
    },
    "v2.5.5": {
      "en": [
        "[feature] support multi select #1446 #1467"
      ],
      "zh-CN": [
        "[feature] 支持多选 #1446 #1467"
      ]
    },
    "v2.4.0": {
      "en": [
        "[enhance] re-render when render-month is changed"
      ],
      "zh-CN": [
        "[enhance] 当 render-month 变化时重新渲染日历"
      ]
    },
    "v2.3.8": {
      "en": [
        "[enhance] prevent from clicking invisiable date #1564"
      ],
      "zh-CN": [
        "[enhance] 不可见日期不可点击 #1564"
      ]
    },
    "v2.3.6": {
      "en": [
        "[change] render-function params day => date #1361"
      ],
      "zh-CN": [
        "[change] render-function 参数 day => date（在 3.0 版本前不会影响目前使用）#1361"
      ]
    },
    "v2.3.5": {
      "en": [
        "[feature] Support slot:each-day"
      ],
      "zh-CN": [
        "[feature] 支持自定义每一天的 html 渲染 slot:each-day"
      ]
    },
    "v2.3.1": {
      "en": [
        "[fix] Fix render-function-generated-content visibility issue #1409"
      ],
      "zh-CN": [
        "[fix] 修复 render-function 生成的内容错误显示问题 #1409"
      ]
    },
    "v2.2.2": {
      "en": [
        "[enhance] when replace text of date is empty string, span of date will not show"
      ],
      "zh-CN": [
        "[enhance] 当日期的替代文字为空字符串时，包含日期的 `span` 元素将不显示"
      ]
    },
    "v2.2.1-rc.2": {
      "en": [
        "[enhance] Now next month's day can be clicked and will automatically switch to next month's view #1192",
        "[fix] fix start-date and end-date not reactive #1219"
      ],
      "zh-CN": [
        "[enhance] 可以点击下个月日期并自动切换到下个月 #1192",
        "[fix] 修复 start-date 和 end-date 变化后不重新渲染的问题 #1219"
      ]
    },
    "v2.1.1-rc.10": {
      "en": [
        "[feature] Add more less variables. #896"
      ],
      "zh-CN": [
        "[feature] 支持多个 less 变量. #896"
      ]
    },
    "v2.1.1-rc.5": {
      "en": [
        "[fix] fix render-function not reactive"
      ],
      "zh-CN": [
        "[fix] 修复 render-function 变化不重新渲染的问题"
      ]
    }
  }
}
  const demos = []

  let componentList = []
  if (Array.isArray(metas.items)) {
    try {
      metas.items.forEach((item, index) => {
        const meta = {
          name: item,
          meta: metas[item]
        }
        if (meta.meta.props === null) {
          delete meta.meta.props
        }
        if (index === metas.items.length - 1) {
          if (meta.meta) {
            meta.meta.variables = metas.variables
          }
        }
        componentList.push(meta)
      })
    } catch (e) {
      console.log(e)
    }
  } else {
    componentList.push({
      meta: metas
    })
  }
  const gitMetas = require('./inline-calendar_git_metas.json')
  const demoCode = decodeURIComponent(`%3Cpre%20class%3D%22hljs%22%3E%3Ccode%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Etemplate%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ediv%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Einline-calendar%3C%2Fspan%3E%0A%20%20%3Cspan%20class%3D%22hljs-attr%22%3Eref%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22calendar%22%3C%2Fspan%3E%0A%20%20%40%3Cspan%20class%3D%22hljs-attr%22%3Eon-change%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22onChange%22%3C%2Fspan%3E%0A%20%20%40%3Cspan%20class%3D%22hljs-attr%22%3Eon-view-change%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22onViewChange%22%3C%2Fspan%3E%0A%20%20%3Cspan%20class%3D%22hljs-attr%22%3Eclass%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22inline-calendar-demo%22%3C%2Fspan%3E%0A%20%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Ashow.sync%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22show%22%3C%2Fspan%3E%0A%20%20%3Cspan%20class%3D%22hljs-attr%22%3Ev-model%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22value%22%3C%2Fspan%3E%0A%20%20%3Cspan%20class%3D%22hljs-attr%22%3Estart-date%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%222016-04-01%22%3C%2Fspan%3E%0A%20%20%3Cspan%20class%3D%22hljs-attr%22%3Eend-date%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%222018-05-30%22%3C%2Fspan%3E%0A%20%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Arange%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22range%22%3C%2Fspan%3E%0A%20%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Ashow-last-month%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22showLastMonth%22%3C%2Fspan%3E%0A%20%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Ashow-next-month%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22showNextMonth%22%3C%2Fspan%3E%0A%20%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Ahighlight-weekend%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22highlightWeekend%22%3C%2Fspan%3E%0A%20%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Areturn-six-rows%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22return6Rows%22%3C%2Fspan%3E%0A%20%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Ahide-header%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22hideHeader%22%3C%2Fspan%3E%0A%20%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Ahide-week-list%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22hideWeekList%22%3C%2Fspan%3E%0A%20%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Areplace-text-list%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22replaceTextList%22%3C%2Fspan%3E%0A%20%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Aweeks-list%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22weeksList%22%3C%2Fspan%3E%0A%20%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Arender-function%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22buildSlotFn%22%3C%2Fspan%3E%0A%20%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Adisable-past%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22disablePast%22%3C%2Fspan%3E%0A%20%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Adisable-future%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22disableFuture%22%3C%2Fspan%3E%0A%20%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Adisable-weekend%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22disableWeekend%22%3C%2Fspan%3E%0A%20%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Adisable-date-function%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22disableDateFunction%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Einline-calendar%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%0A%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Egroup%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ecell%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Atitle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22%24t('Current%20value')%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Avalue%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22value%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ecell%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ecell%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Atitle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22%24t('Start%20date')%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Evalue%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%222016-04-01%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ecell%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ecell%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Atitle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22%24t('End%20date')%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Evalue%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%222018-05-30%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ecell%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Egroup%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%0A%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ediv%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Estyle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22margin%3A%2015px%3B%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ex-button%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Etype%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22primary%22%3C%2Fspan%3E%20%40%3Cspan%20class%3D%22hljs-attr%22%3Eclick.native%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22%24refs.calendar.switchViewToToday()%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3EswitchViewToToday%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ex-button%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ex-button%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Etype%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22primary%22%3C%2Fspan%3E%20%40%3Cspan%20class%3D%22hljs-attr%22%3Eclick.native%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22%24refs.calendar.switchViewToMonth(2017%2C%2012)%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3EswitchViewToMonth(2017%2C%2012)%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ex-button%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ex-button%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Etype%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22primary%22%3C%2Fspan%3E%20%40%3Cspan%20class%3D%22hljs-attr%22%3Eclick.native%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22%24refs.calendar.switchViewToMonth(2018%2C%2010)%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3EswitchViewToMonth(2018%2C%2010)%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ex-button%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ex-button%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Etype%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22primary%22%3C%2Fspan%3E%20%40%3Cspan%20class%3D%22hljs-attr%22%3Eclick.native%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22%24refs.calendar.switchViewToCurrentValue()%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3EswitchViewToCurrentValue%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ex-button%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ediv%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%0A%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Egroup%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Atitle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22%24t('Control%20days')%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Estyle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22margin-top%3A%2030px%3B%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ex-switch%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Ev-model%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22disablePast%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Atitle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22%24t('Disable%20past')%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ex-switch%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ex-switch%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Ev-model%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22disableFuture%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Atitle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22%24t('Disable%20future')%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ex-switch%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ex-switch%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Ev-model%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22disableWeekend%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Atitle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22%24t('Disable%20weekend')%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ex-switch%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ex-switch%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Ev-model%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22showLastMonth%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Atitle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22%24t('Show%20last%20month')%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ex-switch%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ex-switch%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Ev-model%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22showNextMonth%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Atitle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22%24t('Show%20next%20month')%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ex-switch%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ex-switch%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Ev-model%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22return6Rows%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Ainline-desc%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22%24t('If%20not%2C%20the%20height%20of%20calendar%20would%20change')%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Atitle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22%24t('Always%20show%206%20rows')%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ex-switch%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ex-switch%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Ev-model%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22highlightWeekend%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Atitle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22%24t('Highlight%20weekend')%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ex-switch%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ecell%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Atitle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22%24t('Current%20value')%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Avalue%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22value%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ecell%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Egroup%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Egroup%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Atitle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22%24t('Control%20navs')%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ex-switch%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Ev-model%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22hideHeader%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Atitle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22%24t('Hide%20header')%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ex-switch%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ex-switch%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Ev-model%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22hideWeekList%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Atitle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22%24t('Hide%20week%20list')%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ex-switch%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ex-switch%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Ev-model%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22changeWeeksList%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Atitle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22%24t('Change%20week%20list')%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ex-switch%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Egroup%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Egroup%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Atitle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22%24t('Replace%20text')%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ex-switch%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Ev-model%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22replace%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Atitle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22%24t('Replace%20date%20text')%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ex-switch%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Egroup%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ebr%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ediv%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Estyle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22margin%3A%2015px%3B%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ex-button%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Etype%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22primary%22%3C%2Fspan%3E%20%40%3Cspan%20class%3D%22hljs-attr%22%3Eclick.native%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22value%3D'2020-11-11'%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%20%7B%7B%20%24t('Set%20time%20to')%20%7D%7D%202020-11-11%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ex-button%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ex-button%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Etype%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22primary%22%3C%2Fspan%3E%20%40%3Cspan%20class%3D%22hljs-attr%22%3Eclick.native%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22value%3D'2020-11-22'%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%20%7B%7B%20%24t('Set%20time%20to')%20%7D%7D%202020-11-22%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ex-button%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ex-button%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Etype%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22primary%22%3C%2Fspan%3E%20%40%3Cspan%20class%3D%22hljs-attr%22%3Eclick.native%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22value%3D'2016-08-09'%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%20%7B%7B%20%24t('Set%20time%20to')%20%7D%7D%202016-08-09%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ex-button%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ex-button%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Etype%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22primary%22%3C%2Fspan%3E%20%40%3Cspan%20class%3D%22hljs-attr%22%3Eclick.native%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22value%3D'TODAY'%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%20%7B%7B%20%24t('Set%20time%20to')%20%7D%7D%20today%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ex-button%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ex-button%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Etype%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22primary%22%3C%2Fspan%3E%20%40%3Cspan%20class%3D%22hljs-attr%22%3Eclick.native%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22value%3D'2016-06-05'%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%20%7B%7B%20%24t('Set%20time%20to')%20%7D%7D%202016-06-05%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ex-button%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ediv%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ebr%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Egroup%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Atitle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22%24t('Custom%20every%20day%20cell')%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ex-switch%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Ev-model%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22useCustomFn%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Ainline-desc%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22%24t('Add%20red%20dot%20for%20dates%20with%20number%208')%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Atitle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22%24t('Add%20custom%20contents%20in%20day%20cell')%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ex-switch%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Egroup%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%0A%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ebr%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%0A%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Edivider%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%20%7B%7B%20%24t('We%20can%20render%20a%20list%20of%20calendars%20order%20by%20month')%20%7D%7D%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Edivider%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Egroup%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ecell%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Atitle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22%24t('Current%20value')%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Avalue%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22listValue%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ecell%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Egroup%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ebr%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ediv%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Etemplate%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%0A%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ei18n%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0AStart%20date%3A%0A%20%20zh-CN%3A%20%E5%BC%80%E5%A7%8B%E6%97%A5%E6%9C%9F%0AEnd%20date%3A%0A%20%20zh-CN%3A%20%E7%BB%93%E6%9D%9F%E6%97%A5%E6%9C%9F%0AControl%20days%3A%0A%20%20zh-CN%3A%20%E6%8E%A7%E5%88%B6%E6%97%A5%E6%9C%9F%0ADisable%20past%3A%0A%20%20zh-CN%3A%20%E7%A6%81%E6%AD%A2%E9%80%89%E6%8B%A9%E6%9C%AA%E6%9D%A5%E7%9A%84%E6%97%A5%E6%9C%9F%0ADisable%20future%3A%0A%20%20zh-CN%3A%20%E7%A6%81%E6%AD%A2%E9%80%89%E6%8B%A9%E8%BF%87%E5%8E%BB%E7%9A%84%E6%97%A5%E6%9C%9F%0ADisable%20weekend%3A%0A%20%20zh-CN%3A%20%E7%A6%81%E6%AD%A2%E9%80%89%E6%8B%A9%E5%91%A8%E6%9C%AB%E6%97%A5%E6%9C%9F%0AShow%20last%20month%3A%0A%20%20zh-CN%3A%20%E6%98%BE%E7%A4%BA%E4%B8%8A%E4%B8%AA%E6%9C%88%0AShow%20next%20month%3A%0A%20%20zh-CN%3A%20%E6%98%BE%E7%A4%BA%E4%B8%8B%E4%B8%AA%E6%9C%88%0AAlways%20show%206%20rows%3A%0A%20%20zh-CN%3A%20%E5%9B%BA%E5%AE%9A%E6%98%BE%E7%A4%BA6%E8%A1%8C%0AIf%20not%2C%20the%20height%20of%20calendar%20would%20change%3A%0A%20%20zh-CN%3A%20%E5%90%A6%E5%88%99%EF%BC%8C%E6%97%A5%E5%8E%86%E7%9A%84%E9%AB%98%E5%BA%A6%E4%BC%9A%E5%8F%91%E7%94%9F%E6%94%B9%E5%8F%98%0AHighlight%20weekend%3A%0A%20%20zh-CN%3A%20%E9%AB%98%E4%BA%AE%E5%91%A8%E6%9C%AB%0AControl%20navs%3A%0A%20%20zh-CN%3A%20%E6%8E%A7%E5%88%B6%E5%AF%BC%E8%88%AA%E9%83%A8%E5%88%86%0AHide%20header%3A%0A%20%20zh-CN%3A%20%E9%9A%90%E8%97%8F%E6%97%A5%E5%8E%86%E5%A4%B4%E9%83%A8%0AHide%20week%20list%3A%0A%20%20zh-CN%3A%20%E9%9A%90%E8%97%8F%E6%98%9F%E6%9C%9F%E5%88%97%E8%A1%A8%0AChange%20week%20list%3A%0A%20%20zh-CN%3A%20%E5%88%87%E6%8D%A2%E6%98%9F%E6%9C%9F%E5%88%97%E8%A1%A8%0AReplace%20text%3A%0A%20%20zh-CN%3A%20%E6%9B%B4%E6%8D%A2%E6%96%87%E6%9C%AC%0AReplace%20date%20text%3A%0A%20%20zh-CN%3A%20%E6%9B%BF%E6%8D%A2%E6%97%A5%E6%9C%9F%E6%96%87%E6%9C%AC%0ASet%20time%20to%3A%0A%20%20zh-CN%3A%20%E8%AE%BE%E7%BD%AE%E4%B8%BA%0ACustom%20every%20day%20cell%3A%0A%20%20zh-CN%3A%20%E8%87%AA%E5%AE%9A%E4%B9%89%E6%97%A5%E6%9C%9F%E5%8D%95%E5%85%83%E6%A0%BC%0AAdd%20custom%20contents%20in%20day%20cell%3A%0A%20%20zh-CN%3A%20%E5%9C%A8%E6%97%A5%E6%9C%9F%E5%8D%95%E5%85%83%E6%A0%BC%E4%B8%AD%E6%B7%BB%E5%8A%A0%E8%87%AA%E5%AE%9A%E4%B9%89%E5%86%85%E5%AE%B9%0AAdd%20red%20dot%20for%20dates%20with%20number%208%3A%0A%20%20zh-CN%3A%20%E4%B8%BA%E5%B8%A6%E6%9C%89%E6%95%B0%E5%AD%978%E7%9A%84%E6%97%A5%E6%9C%9F%E6%B7%BB%E5%8A%A0%E7%BA%A2%E7%82%B9%0AWe%20can%20render%20a%20list%20of%20calendars%20order%20by%20month%3A%0A%20%20zh-CN%3A%20%E6%8C%89%E6%9C%88%E4%BB%BD%E9%A1%BA%E5%BA%8F%E6%B8%B2%E6%9F%93%E4%B8%80%E7%B3%BB%E5%88%97%E6%97%A5%E5%8E%86%0A%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ei18n%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%0A%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Escript%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22javascript%22%3E%0A%3Cspan%20class%3D%22hljs-keyword%22%3Eimport%3C%2Fspan%3E%20%7B%20InlineCalendar%2C%20Group%2C%20XSwitch%2C%20Radio%2C%20XButton%2C%20Cell%2C%20Divider%20%7D%20%3Cspan%20class%3D%22hljs-keyword%22%3Efrom%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-string%22%3E'vux'%3C%2Fspan%3E%0A%0A%3Cspan%20class%3D%22hljs-keyword%22%3Eexport%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-keyword%22%3Edefault%3C%2Fspan%3E%20%7B%0A%20%20%3Cspan%20class%3D%22hljs-attr%22%3Emethods%3C%2Fspan%3E%3A%20%7B%0A%20%20%20%20onChange%20(val)%20%7B%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-built_in%22%3Econsole%3C%2Fspan%3E.log(%3Cspan%20class%3D%22hljs-string%22%3E'on-change'%3C%2Fspan%3E%2C%20val)%0A%20%20%20%20%7D%2C%0A%20%20%20%20onViewChange%20(val%2C%20count)%20%7B%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-built_in%22%3Econsole%3C%2Fspan%3E.log(%3Cspan%20class%3D%22hljs-string%22%3E'on%20view%20change'%3C%2Fspan%3E%2C%20val%2C%20count)%0A%20%20%20%20%7D%0A%20%20%7D%2C%0A%20%20data%20()%20%7B%0A%20%20%20%20%3Cspan%20class%3D%22hljs-keyword%22%3Ereturn%3C%2Fspan%3E%20%7B%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3Eshow%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-literal%22%3Etrue%3C%2Fspan%3E%2C%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3Evalue%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-string%22%3E''%3C%2Fspan%3E%2C%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3ElistValue%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-string%22%3E''%3C%2Fspan%3E%2C%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3Erange%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-literal%22%3Efalse%3C%2Fspan%3E%2C%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3EshowLastMonth%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-literal%22%3Etrue%3C%2Fspan%3E%2C%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3EshowNextMonth%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-literal%22%3Etrue%3C%2Fspan%3E%2C%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3EhighlightWeekend%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-literal%22%3Efalse%3C%2Fspan%3E%2C%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3Ereturn6Rows%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-literal%22%3Etrue%3C%2Fspan%3E%2C%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3EhideHeader%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-literal%22%3Efalse%3C%2Fspan%3E%2C%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3EhideWeekList%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-literal%22%3Efalse%3C%2Fspan%3E%2C%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3EreplaceTextList%3C%2Fspan%3E%3A%20%7B%7D%2C%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3Ereplace%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-literal%22%3Efalse%3C%2Fspan%3E%2C%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3EchangeWeeksList%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-literal%22%3Efalse%3C%2Fspan%3E%2C%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3EweeksList%3C%2Fspan%3E%3A%20%5B%5D%2C%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3EuseCustomFn%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-literal%22%3Efalse%3C%2Fspan%3E%2C%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3EbuildSlotFn%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-function%22%3E%3Cspan%20class%3D%22hljs-params%22%3E()%3C%2Fspan%3E%20%3D%26gt%3B%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-string%22%3E''%3C%2Fspan%3E%2C%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3EdisablePast%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-literal%22%3Efalse%3C%2Fspan%3E%2C%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3EdisableFuture%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-literal%22%3Efalse%3C%2Fspan%3E%2C%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3EdisableWeekend%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-literal%22%3Efalse%3C%2Fspan%3E%2C%0A%20%20%20%20%20%20disableDateFunction%20(date)%20%7B%0A%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-keyword%22%3Eif%3C%2Fspan%3E%20(date.formatedDate%20%3D%3D%3D%20%3Cspan%20class%3D%22hljs-string%22%3E'2017-10-16'%3C%2Fspan%3E)%20%7B%0A%20%20%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-keyword%22%3Ereturn%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-literal%22%3Etrue%3C%2Fspan%3E%0A%20%20%20%20%20%20%20%20%7D%0A%20%20%20%20%20%20%7D%0A%20%20%20%20%7D%0A%20%20%7D%2C%0A%20%20%3Cspan%20class%3D%22hljs-attr%22%3Ewatch%3C%2Fspan%3E%3A%20%7B%0A%20%20%20%20replace%20(val)%20%7B%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-keyword%22%3Ethis%3C%2Fspan%3E.replaceTextList%20%3D%20val%20%3F%20%7B%0A%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-string%22%3E'TODAY'%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-string%22%3E'%E4%BB%8A'%3C%2Fspan%3E%0A%20%20%20%20%20%20%7D%20%3A%20%7B%7D%0A%20%20%20%20%7D%2C%0A%20%20%20%20useCustomFn%20(val)%20%7B%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-keyword%22%3Ethis%3C%2Fspan%3E.buildSlotFn%20%3D%20val%20%3F%20%3Cspan%20class%3D%22hljs-function%22%3E(%3Cspan%20class%3D%22hljs-params%22%3Eline%2C%20index%2C%20data%3C%2Fspan%3E)%20%3D%26gt%3B%3C%2Fspan%3E%20%7B%0A%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-keyword%22%3Ereturn%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-regexp%22%3E%2F8%2F%3C%2Fspan%3E.test(data.date)%20%3F%20%3Cspan%20class%3D%22hljs-string%22%3E'%26lt%3Bdiv%20style%3D%22font-size%3A12px%3Btext-align%3Acenter%3B%22%26gt%3B%26lt%3Bspan%20style%3D%22display%3Ainline-block%3Bwidth%3A5px%3Bheight%3A5px%3Bbackground-color%3Ared%3Bborder-radius%3A50%25%3B%22%26gt%3B%26lt%3B%2Fspan%26gt%3B%26lt%3B%2Fdiv%26gt%3B'%3C%2Fspan%3E%20%3A%20%3Cspan%20class%3D%22hljs-string%22%3E'%26lt%3Bdiv%20style%3D%22height%3A19px%3B%22%26gt%3B%26lt%3B%2Fdiv%26gt%3B'%3C%2Fspan%3E%0A%20%20%20%20%20%20%7D%20%3A%20%3Cspan%20class%3D%22hljs-function%22%3E%3Cspan%20class%3D%22hljs-params%22%3E()%3C%2Fspan%3E%20%3D%26gt%3B%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-string%22%3E''%3C%2Fspan%3E%0A%20%20%20%20%7D%2C%0A%20%20%20%20changeWeeksList%20(val)%20%7B%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-keyword%22%3Ethis%3C%2Fspan%3E.weeksList%20%3D%20val%20%3F%20%5B%3Cspan%20class%3D%22hljs-string%22%3E'%E6%97%A5'%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-string%22%3E'%E4%B8%80'%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-string%22%3E'%E4%BA%8C'%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-string%22%3E'%E4%B8%89'%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-string%22%3E'%E5%9B%9B'%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-string%22%3E'%E4%BA%94'%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-string%22%3E'%E5%85%AD%20'%3C%2Fspan%3E%5D%20%3A%20%5B%3Cspan%20class%3D%22hljs-string%22%3E'Su'%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-string%22%3E'Mo'%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-string%22%3E'Tu'%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-string%22%3E'We'%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-string%22%3E'Th'%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-string%22%3E'Fr'%3C%2Fspan%3E%2C%20%3Cspan%20class%3D%22hljs-string%22%3E'Sa'%3C%2Fspan%3E%5D%0A%20%20%20%20%7D%0A%20%20%7D%2C%0A%20%20%3Cspan%20class%3D%22hljs-attr%22%3Ecomponents%3C%2Fspan%3E%3A%20%7B%0A%20%20%20%20InlineCalendar%2C%0A%20%20%20%20Group%2C%0A%20%20%20%20XSwitch%2C%0A%20%20%20%20Radio%2C%0A%20%20%20%20XButton%2C%0A%20%20%20%20Cell%2C%0A%20%20%20%20Divider%0A%20%20%7D%0A%7D%0A%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Escript%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%0A%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Estyle%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Elang%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22less%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Escoped%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22css%22%3E%0A%3Cspan%20class%3D%22hljs-selector-class%22%3E.inline-calendar-demo%3C%2Fspan%3E%20%7B%0A%20%20%3Cspan%20class%3D%22hljs-attribute%22%3Ebackground%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-built_in%22%3Ergba%3C%2Fspan%3E(255%2C255%2C255%2C0.9)%3B%0A%7D%0A%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Estyle%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%3C%2Fcode%3E%3C%2Fpre%3E`)

  const domainMap = {
    'development': 'http://localhost:8080/',
    'production': 'https://vux.li/demos/v2/'
  }

  export default {
    head: {
      title: 'InlineCalendar component tutorial | VUX - Vue.js Mobile UI Component Framework',
      meta: [{
        name: 'description',
        content: 'Vue component inline-calendar for the VUX framework.'
      }, {
        name: 'keywords',
        content: 'inline-calendar, vue-inline-calendar, vux-inline-calendar, vue mobile components'
      }, {
        property: 'og:title',
        content: 'InlineCalendar component tutorial | VUX - Vue.js Mobile UI Component Framework'
      }, {
        property: 'og:description',
        content: 'Vue component inline-calendar for the VUX framework.'
      }],
      // https://support.google.com/webmasters/answer/189077?hl=en
      link: [{"rel":"alternate","hreflang":"zh-CN","href":"/zh-CN/components/inline-calendar.html"}],
      script: [
        {
          innerHTML:'{"@context":"http://schema.org/","@type":"SoftwareApplication","name":"Vue Component inline-calendar","screenshot":"","description":"Vue.js component for VUX","url":"/en/components/inline-calendar.html","applicationCategory":"Component","author":{"@type":"Organization","name":"VUX","url":"https://vux.li"},"downloadUrl":"https://vux.li","softwareVersion":"2.9.2","aggregateRating":{"@type":"AggregateRating","ratingValue":5,"reviewCount":65},"operatingSystem":"iOS >= 7, Android >= 4.1","offers":{"@type":"Offer","price":0,"priceCurrency":"USD","availability":"http://schema.org/InStock"}}',
          type: 'application/ld+json'
        }
      ],
      __dangerouslyDisableSanitizers: ['script']
    },
    filters: {
      parseCode (str) {
        return str.replace(/`(.*?)`/g, '<code>$1</code>')
      }
    },
    async mounted () {
      const rs = await Axios.get('https://api.github.com/search/issues?q=repo:airyland/vux%20label:component/' + this.componentName)
      this.issues = rs.data.items
      this.hasReady = true
    },
    watch: {
      async sourceCodeDialogVisibility (val) {
        if (val) {
          await this.$nextTick()
          const mask = document.querySelector('.v-modal')
          mask && mask.addEventListener('click', () => {
            this.sourceCodeDialogVisibility = false
          })
        }
      }
    },
    methods: {
      onCopyError () {
        this.$message({
          type: 'error',
          message: 'copy fail!'
        })
      },
      onCopy () {
        this.$message({
          type: 'success',
          message: 'copy done!'
        })
      },
      showSourceCode () {
        this.sourceCodeDialogVisibility = true
      },
      getTypeHTML (type) {
        type = type || 'String'
        if (/,/.test(type)) {
          const list = type.split(',').map(function (one) {
            return one.replace(/^s+|s+$/g, '')
          }).map(function (one) {
            const type = one ?  one.toLowerCase() : 'string'
            return '<span class="type">' + type + '</span>'
          })
          return list.join('<br>')
        } else {
          type = type ?  type.toLowerCase() : 'string'
          return '<span class="type">' + type + '</span>'
        }
      }
    },
    computed: {
      lang () {
        if (this.$route.path.indexOf('/en/') !== -1) {
          return 'en'
        }
        if (this.$route.path.indexOf('/zh-CN/') !== -1) {
          return 'zh-CN'
        }
        return 'en'
      }
    },
    data () {
      return {
        demos,
        isBeta: false,
        hasReady: false,
        issues: [],
        componentName: 'inline-calendar',
        demoCode,
        sourceCodeDialogVisibility: false,
        showQr: false,
        metas: metas,
        gitMetas,
        componentList,
        localImportCode: `import { InlineCalendar } from 'vux'

export default {
  components: {
    InlineCalendar
  }
}`,
        globalImportCode: `// you can also register globally

import Vue from 'vue'
import { InlineCalendar } from 'vux'

Vue.component('inline-calendar', InlineCalendar)
`,
        needImport: true,
        toc: [],
        domain: domainMap[process.env.NODE_ENV]
      }
    }
  }
  </script>

  <style>
  .component-box {
    position: relative;
  }
  .component-demo {
    position: absolute;
    right: 5px;
    top: 15px;
  }
  .prop-color {
    display: inline-block;
    width: 10px;
    height: 10px;
    border: 1px solid #aaa;
  }
  .changelog-version {
    width: 110px;
    display: inline-block;
  }
  .component-extra-links {
    position: relative;
    font-size: 12px;
  }
  .component-extra-links a {
    padding-right: 10px;
    color: #999;
  }
  </style>
    