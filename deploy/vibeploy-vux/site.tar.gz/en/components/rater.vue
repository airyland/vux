
  <template>
    <div class="component-box" :class="demos.length ? 'components-with-toc' : ''">

      <div :class="demos.length ? 'component-header-v2' : 'component-header-v1'">
        <a class="anchor" id="intro">Rater</a>
        <div class="title-box">

          <el-badge value="Beta" v-if="isBeta">
            <h1 class="vux-component-name">Rater</h1>
          </el-badge>
          <h1 v-else class="vux-component-name">Rater</h1>

          <p class="component-extra-links">
            <a href="https://vux.li/demos/v2/#/component/rater" target="_blank">demo url</a>
            <a v-if="!demos.length" href="https://github.com/airyland/vux/blob/v2/src/demos/Rater.vue" target="_blank" @click.prevent="showSourceCode">demo source code</a>
            <a href="https://github.com/airyland/vux/blob/v2/src/components/rater/metas.yml" target="_blank">edit document</a>
            <a href="https://github.com/airyland/vux/blob/v2/src/components/rater/" target="_blank">component source code</a>
            <el-popover trigger="hover" v-if="hasReady">
              <div style="width:100%;text-align:center;">
                <img class="qr" width="100" src="https://qr.vux.li/api.php?text=https%3A%2F%2Fvux.li%2Fdemos%2Fv2%2F%23%2Fcomponent%2Frater"/>
              </div>
              <a href="javascript:" slot="reference">
              view demos on mobile
              </a>
            </el-popover>
          </p>

          <div class="component-description">
            <template v-if="false">
            
            </template>
          </div>

        </div>

        <div v-if="!demos.length" class="component-demo" style="width:377px;height:600px;display:inline-block;border:1px solid #ececec;border-radius:5px;overflow:hidden;z-index:2500;">
          <iframe src="https://vux.li/demos/v2?locale=en&transition=none/#/component/rater" width="375" height="600" border="0" frameborder="0"></iframe>
        </div>
        <div class="toc">
          <ul v-for="t in toc">
            <li>
              <a :href="'#' + (t.anchor || t.title)">{{ t.title }}</a>
              <ul v-if="t.list" v-for="_t in t.list">
                <li><a :href="'#' + _t.anchor">{{ _t.title.slice(0, 12) }}</a></li>
              </ul>
            </li>
          </ul>
        </div>
      
        <template v-if="needImport">
          <a class="anchor" id="install">Install</a>
          <h2>Install</h2>
          <el-tabs>
            <el-tab-pane label="Local Registration">
              <div class="import-code-box">
              <el-tooltip content="click to copy" placement="top">
                <span
                  v-clipboard:copy="localImportCode"
                  v-clipboard:success="onCopy"
                  v-clipboard:error="onCopyError">
                  <el-icon class="el-icon-document"></el-icon>
                </span>
              </el-tooltip>
              <pre class="hljs"><code><span class="hljs-keyword">import</span> { Rater } <span class="hljs-keyword">from</span> <span class="hljs-string">'vux'</span>

<span class="hljs-keyword">export</span> <span class="hljs-keyword">default</span> {
  <span class="hljs-attr">components</span>: {
    Rater
  }
}</code></pre>
            </div>
            </el-tab-pane>
            <el-tab-pane label="Global Registration">
              <div class="import-code-box">
                <el-tooltip content="click to copy" placement="top">
                  <span
                    v-clipboard:copy="globalImportCode"
                    v-clipboard:success="onCopy"
                    v-clipboard:error="onCopyError">
                    <el-icon class="el-icon-document"></el-icon>
                  </span>
                </el-tooltip>
                <pre class="hljs"><code><span class="hljs-comment">// you can also register globally</span>

<span class="hljs-keyword">import</span> Vue <span class="hljs-keyword">from</span> <span class="hljs-string">'vue'</span>
<span class="hljs-keyword">import</span> { Rater } <span class="hljs-keyword">from</span> <span class="hljs-string">'vux'</span>

Vue.component(<span class="hljs-string">'rater'</span>, Rater)
</code></pre>
              </div> 
            </el-tab-pane>
          </el-tabs>   
        </template>

        <template v-else>
          <div class="tip">
            <p>You don't need to import this component.</p>
          </div>
        </template>

        <div class="tip" style="width:600px;" v-if="metas.tip">
          
        </div>
      
        <h2 v-if="metas.example">example</h2>
        <div v-if="metas.example" style="width:600px;">
          
        </div>
      </div>

      <div v-if="metas.extra && metas.extra['en']">
        
      </div>
      <div v-if="metas.extra && !metas.extra['en']">
        
      </div>
      
      <a v-if="demos.length" class="anchor" id="examples">Examples</a>
      <br/>
      <template v-if="demos.length" v-for="demo in demos">
        <a class="anchor" :id="'examples:' + demo.title">{{ demo.title }}</a>
        <br/>
        <div class="demo-header">
          <span class="demo-title">{{ demo.title }}</span>
        </div>
        <div class="demos" :style="{height: demo.height}">
          <div class="demo-iframe-box">
            <lazy-component>
              <iframe
                :src="domain + '?no-background-color=' + demo.noBackgroundColor +'&locale=en&transition=none&hide-nav=true&hide-tab-bar=true#/components/' + demo.file"
                width="375"
                height="600"
                border="0"
                frameborder="0"
                style="margin: 0 auto;"></iframe>
            </lazy-component>
          </div>
          <div class="demo-code-box" :style="{overflow: demo.height === demo.oriHeight ? 'hidden' : 'scroll'}">
            <div v-html="demo.code" contenteditable></div>
            <div v-if="demo.height === demo.oriHeight" class="demo-code-masker" @click="demo.height='auto'">
              <div>
                  <img class="demo-qr" width="100" :src="'https://qr.vux.li/api.php?text=' + encodeURIComponent(domain + '?locale=en#/components/' + demo.file)"/>
                  <br/>
                  <span>
                    <el-icon class="el-icon-arrow-left"/>
                    <el-icon class="el-icon-arrow-right"/>
                    Show code
                  <br/>
                  <!--<span class="demo-path">src/demos/{{ demo.file }}.vue</span>-->
                </span>
              </div>
            </div>
            <span v-if="demo.height === 'auto'" class="hide-code" @click="demo.height=demo.oriHeight">
              <el-icon class="el-icon-close"></el-icon>
            </span>
          </div>
        </div>
      </template>

      <template v-for="component in componentList">
        <div>
          <a v-if="componentList.length > 1" class="anchor" :id="'components:' + component.name">{{ component.name }}</a>
          <a v-else class="anchor" id="api">API</a>
          <br/>
          <h2
            v-show="componentList.length > 1"
            class="vux-component-name-sub-item">{{ component.name }}</h2>
            
          <template v-if="component.meta.items && component.meta.description">
            <div v-html="component.meta.description"></div>
          </template>

          <template v-if="component.meta.props">
            <h2>Props</h2>
            <table>
              <thead>
                <tr>
                  <td>name</td>
                  <td style="width:48px;">type</td>
                  <td>default</td>
                  <td>description</td>
                  <td>required version</td>
                </tr>
              </thead>
              <tbody>
                <tr v-for="(prop, i) in component.meta.props">
                  <td class="prop-name">
                    <el-tooltip content="click to copy" placement="left" :hide-after="0" :open-delay="50">
                      <span
                      v-clipboard:copy="i"
                      v-clipboard:success="onCopy">{{ i }}</span>
                    </el-tooltip>
                  </td>
                  <td v-html="getTypeHTML(prop.type)"></td>
                  <td>{{ prop.default}}</td>
                  <td v-html="prop['en'].replace(/`(.*?)`/g, '<code>$1</code>')"></td>
                  <td>{{ prop.version || '--'}}</td>
                </tr>
              </tbody>
            </table>
          </template>

          <template v-if="component.meta.events">
            <h2>Events</h2>
            <table>
              <thead>
                <tr>
                  <td>name</td>
                  <td>params</td>
                  <td>description</td>
                  <td>required version</td>
                </tr>
              </thead>
              <tbody>
                <tr v-for="(event, i) in component.meta.events">
                  <td class="prop-name">
                    <el-tooltip content="click to copy" placement="left" :hide-after="0" :open-delay="50">
                      <span
                      v-clipboard:copy="'@' + i"
                      v-clipboard:success="onCopy">@{{ i }}</span>
                    </el-tooltip>
                  </td>
                  <td v-html="event.params ? event.params.replace(/`(.*?)`/g, '<code>$1</code>') : '--'"></td>
                  <td v-html="event['en'] ? event['en'].replace(/`(.*?)`/g, '<code>$1</code>') : '--'"></td>
                  <td>{{ event['version'] || '--' }}</td>
                </tr>
              </tbody>
            </table>
          </template>
      

          <template v-if="component.meta.slots">
            <h2>Slots</h2>
            <table>
              <thead>
                <tr>
                  <td>name</td>
                  <td>description</td>
                  <td>required version</td>
                </tr>
              </thead>
              <tbody>
                <tr v-for="(slot, i) in component.meta.slots" :class="{'slot-disabled': slot['status'] === 'deprecated'}">
                  <td class="prop-name">
                    <el-tooltip content="click to copy" placement="left" :hide-after="0" :open-delay="50">
                      <span
                      v-clipboard:copy="i"
                      v-clipboard:success="onCopy">{{ i === 'default' ? 'default' : i }}</span>
                    </el-tooltip>
                  </td>
                  <td v-html="slot['en'] ? slot['en'].replace(/`(.*?)`/g, '<code>$1</code>') : ''"></td>
                  <td>{{ slot['version'] || '--' }}</td>
                </tr>
              </tbody>
            </table>
          </template>
          
          <template v-if="component.meta.methods">
            <h2>Functions</h2>
            <table>
              <thead>
                <tr>
                  <td>name</td>
                  <td>params</td>
                  <td>description</td>
                  <td>required version</td>
                </tr>
              </thead>
              <tbody>
                <tr v-for="(method, i) in component.meta.methods">
                  <td class="prop-name">
                    <el-tooltip content="click to copy" placement="left" :hide-after="0" :open-delay="50">
                      <span
                      v-clipboard:copy="i"
                      v-clipboard:success="onCopy">{{ i }}</span>
                    </el-tooltip>
                  </td>
                  <td v-html="method['params'] ? method['params'].replace(/`(.*?)`/g, '<code>$1</code>') : ''"></td>
                  <td v-html="method['en'].replace(/`(.*?)`/g, '<code>$1</code>')"></td>
                  <td>{{ method['version'] }}</td>
                </tr>
              </tbody>
            </table>
          </template>

          <template v-if="component.meta.variables">
            <a class="anchor" id="variables">Variables</a>
            <br/>
            <h2>Variables</h2>
            <table>
              <thead>
                <tr>
                  <td>name</td>
                  <td>default</td>
                  <td>description</td>
                  <td>inherited name</td>
                </tr>
              </thead>
              <tbody>
                <tr v-for="(variable, i) in component.meta.variables">
                  <td class="prop-name">
                    <el-tooltip content="click to copy" placement="left" :hide-after="0" :open-delay="50">
                      <span
                      v-clipboard:copy="'@' + variable.name"
                      v-clipboard:success="onCopy">@{{ variable.name }}</span>
                    </el-tooltip>
                  </td>
                  <td>
                    <em
                      :ref="'propColor' + i"
                      v-if="!$refs['propColor' + i] || ($refs['propColor' + i][0] && $refs['propColor' + i][0].style.backgroundColor)"
                      class="prop-color"
                      :style="{ backgroundColor: variable.value }">
                    </em>
                    {{ variable.value }}
                  </td>
                  <td>{{ variable['desc']['en'] || '--' }}</td>
                  <td>{{ variable.inherited_name }}</td>
                </tr>
              </tbody>
            </table>
          </template>
      
          <template v-if="component.meta.tips && component.meta.tips['en']">
            <a class="anchor" id="tips">Tips</a>
            <br>
            <h2>Tips</h2>
            <div>
              <ul>
                <li v-for="tip in component.meta.tips['en']">
                <el-tag size="mini" type="success" class="component-tip-tag">Q</el-tag> <span class="component-tip-question">{{ tip.q }}</span>
                <div v-html="tip.a" class="tip-answer-box"></div>
                </li>
              </ul>
            </div>
          </template>
        </div>
      </template>

      <!--<h2>社区相关讨论</h2>
      [即将上线]
      -->
    
      <br>
      <div v-if="issues.length">
        <a class="anchor" id="Issues">Issues</a>
        <br/>
        <h2>Related issues</h2>
        <ul>
          <li v-for="issue in issues"><a target="_blank" :href="issue.html_url">#{{ issue.number}} <span style="color:#666;">{{ issue.title }}</span></a></li>
        </ul>
      </div>
      <br>
    
      <div v-if="gitMetas">
        <a class="anchor" id="contributors">Contributors</a>
        <h2>Contributors</h2>
        <p>Total commits quantity: {{ gitMetas.commitCount }}，Total contributors quantity: {{gitMetas.commitUniqueCount}}
        </p>
        <a v-for="person in gitMetas.commitMembers" class="contributor-item" :href="'https://github.com/' + person.authorName" target="_blank" :title="'contribute' + person.count">{{person.authorName}}</a>
      </div>
      <br>

      <div v-if="metas.changes">
        <a class="anchor" id="changelog">Changelog</a>
        <br/>
        <h2>Releases</h2>
        <ul v-if="metas.changes">
          <template v-for="(changelog, version) in metas.changes">
            <li v-for="log in changelog['en']">
              <router-link :to="'/en/changelog/' + version + '.html'" class="changelog-version">{{version}}</router-link> {{log}}
            </li>
          </template>
        </ul>
      </div>

      <h2 v-if="metas.references">Referrences</h2>
      <ul v-if="metas.references">
        <li v-for="link in metas.references['en']">
          <a :href="link.link" target="_blank">{{link.title}}</a>
        </li>
      </ul>

      <el-dialog
        class="sourcec-code-dialog"
        top="0"
        width="80%"
        :visible.sync="sourceCodeDialogVisibility">
        <div class="code-box" contenteditable v-html="demoCode"></div>
      </el-dialog>

    </div>
  </template>


  <script>
  import Axios from 'axios'

  // const metas = require('json-loader!yaml-loader!../../../src/components/rater/metas.yml')
  const metas = {
  "category": {
    "en": "Form",
    "zh-CN": "表单"
  },
  "icon": "&#xe606;",
  "color": "#FF9900",
  "tags": {
    "en": [
      "form",
      "rate",
      "rater"
    ],
    "zh-CN": [
      "表单",
      "星级",
      "评分"
    ]
  },
  "props": {
    "max": {
      "type": "Number",
      "default": 5,
      "en": "total star number",
      "zh-CN": "最多可选个数"
    },
    "value": {
      "type": "Number",
      "default": 0,
      "en": "selected value, use `v-model` for binding",
      "zh-CN": "值，使用 v-model 绑定"
    },
    "disabled": {
      "type": "Boolean",
      "default": false,
      "en": "if disabled",
      "zh-CN": "是否禁用"
    },
    "star": {
      "type": "String",
      "default": "★",
      "en": "start's symbol text",
      "zh-CN": "字符"
    },
    "active-color": {
      "type": "String",
      "default": "#fc6",
      "en": "symbol color when selected",
      "zh-CN": "选中时的颜色"
    },
    "margin": {
      "type": "Number",
      "default": 2,
      "en": "margin value",
      "zh-CN": "间隙值"
    },
    "font-size": {
      "type": "Number",
      "default": 25,
      "en": "font size",
      "zh-CN": "字体大小"
    },
    "min": {
      "type": "Number",
      "version": "v2.7.9",
      "default": 0,
      "en": "min value",
      "zh-CN": "最小值"
    }
  },
  "changes": {
    "v2.7.9": {
      "en": [
        "[feature] prop:min add min value #2439"
      ],
      "zh-CN": [
        "[feature] prop:min 增加最小值 #2439"
      ]
    },
    "v2.7.3": {
      "en": [
        "[feature] prop:star support html #2182"
      ],
      "zh-CN": [
        "[feature] prop:star 支持 html #2182"
      ]
    }
  }
}
  const demos = []

  let componentList = []
  if (Array.isArray(metas.items)) {
    try {
      metas.items.forEach((item, index) => {
        const meta = {
          name: item,
          meta: metas[item]
        }
        if (meta.meta.props === null) {
          delete meta.meta.props
        }
        if (index === metas.items.length - 1) {
          if (meta.meta) {
            meta.meta.variables = metas.variables
          }
        }
        componentList.push(meta)
      })
    } catch (e) {
      console.log(e)
    }
  } else {
    componentList.push({
      meta: metas
    })
  }
  const gitMetas = require('./rater_git_metas.json')
  const demoCode = decodeURIComponent(`%3Cpre%20class%3D%22hljs%22%3E%3Ccode%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Etemplate%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ediv%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Egroup%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Etitle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22Normal%20Usage%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ecell%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Etitle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22set%20default%20score%20%3D%205%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Einline-desc%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22total%205%20stars%20if%20not%20specified%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Erater%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Ev-model%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22data3%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Erater%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ecell%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ecell%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Etitle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22change%20color%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Erater%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Ev-model%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22data3%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Amax%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%226%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Eactive-color%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22%2304BE02%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Erater%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ecell%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Egroup%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Egroup%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Etitle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22disabled%20%3D%20true%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ecell%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Etitle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22Your%20history%20score%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Erater%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Ev-model%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22data4%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Edisabled%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Erater%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ecell%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ecell%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Atitle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22'Decimal%20score%20'%20%2B%20data41%20%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Erater%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Ev-model%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22data41%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Eactive-color%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22%2304BE02%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Edisabled%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Erater%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ecell%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ecell%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Etitle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22custom%20font-size(15px)%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Erater%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Ev-model%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22data42%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Eactive-color%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22%2304BE02%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Afont-size%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%2215%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Edisabled%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Erater%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ecell%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Egroup%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Egroup%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Etitle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22custom%20star%2C%20some%20symbols%20like%20%E2%99%A5%20%E2%9D%A4%20are%20not%20proper.%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ecell%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Etitle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22loving%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Erater%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Ev-model%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22data4%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Estar%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22%E2%99%A1%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Eactive-color%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22red%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Amargin%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%2215%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Erater%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ecell%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ecell%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Etitle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22Use%20html%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Erater%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Ev-model%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22data41%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Estar%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22%26lt%3Bspan%26gt%3BX%26lt%3B%2Fspan%26gt%3B%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Eactive-color%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22red%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Amargin%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%2215%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Erater%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ecell%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ecell%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Etitle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22Sunshine%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Erater%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Ev-model%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22data5%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Estar%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22%E2%98%BC%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Eactive-color%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22%23FF9900%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Amargin%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%224%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Erater%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ecell%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ecell%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Etitle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22Smilies%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Erater%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Ev-model%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22data5%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Estar%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22%E2%98%BB%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Eactive-color%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22%23FF9900%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Amargin%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%224%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Erater%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ecell%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ecell%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Etitle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22Different%20stars%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Erater%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Ev-model%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22data5%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Estar%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22%E2%9C%A9%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Eactive-color%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22%23FF9900%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Amargin%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%224%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Erater%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ecell%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ecell%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Etitle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22How%20embarrass%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Erater%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Ev-model%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22data5%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Estar%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22%E5%9B%A7%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Eactive-color%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22%23FF9900%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Amargin%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%224%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Erater%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ecell%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Egroup%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Egroup%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Etitle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22two%20way%20binding%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ecell%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Etitle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22Your%20history%20score%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Erater%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Ev-model%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22data6%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Eactive-color%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22%2304BE02%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Erater%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ecell%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ecell%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Etitle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22range%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Eprimary%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22content%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Ainline-desc%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22data6%20%2B%20''%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Erange%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Ev-model%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22data6%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Astep%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%221%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Amin%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%220%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Amax%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%225%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Erange%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ecell%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Egroup%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Egroup%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Etitle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22set%20min%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Ecell%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Etitle%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22min%20%3D%203%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Erater%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3Ev-model%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%22data7%22%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-attr%22%3E%3Amin%3C%2Fspan%3E%3D%3Cspan%20class%3D%22hljs-string%22%3E%223%22%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Erater%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ecell%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%20%20%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Egroup%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%0A%20%20%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Ediv%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Etemplate%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%0A%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%3Cspan%20class%3D%22hljs-name%22%3Escript%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%3Cspan%20class%3D%22javascript%22%3E%0A%3Cspan%20class%3D%22hljs-keyword%22%3Eimport%3C%2Fspan%3E%20%7B%20Rater%2C%20Group%2C%20Cell%2C%20Range%20%7D%20%3Cspan%20class%3D%22hljs-keyword%22%3Efrom%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-string%22%3E'vux'%3C%2Fspan%3E%0A%0A%3Cspan%20class%3D%22hljs-keyword%22%3Eexport%3C%2Fspan%3E%20%3Cspan%20class%3D%22hljs-keyword%22%3Edefault%3C%2Fspan%3E%20%7B%0A%20%20%3Cspan%20class%3D%22hljs-attr%22%3Ecomponents%3C%2Fspan%3E%3A%20%7B%0A%20%20%20%20Rater%2C%0A%20%20%20%20Group%2C%0A%20%20%20%20Cell%2C%0A%20%20%20%20Range%0A%20%20%7D%2C%0A%20%20data%20()%20%7B%0A%20%20%20%20%3Cspan%20class%3D%22hljs-keyword%22%3Ereturn%3C%2Fspan%3E%20%7B%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3Edata1%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-number%22%3E0%3C%2Fspan%3E%2C%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3Edata2%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-number%22%3E5%3C%2Fspan%3E%2C%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3Edata3%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-string%22%3E'5'%3C%2Fspan%3E%2C%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3Edata4%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-number%22%3E3%3C%2Fspan%3E%2C%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3Edata41%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-number%22%3E3.7%3C%2Fspan%3E%2C%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3Edata42%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-number%22%3E3.5%3C%2Fspan%3E%2C%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3Edata5%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-number%22%3E3%3C%2Fspan%3E%2C%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3Edata6%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-number%22%3E3%3C%2Fspan%3E%2C%0A%20%20%20%20%20%20%3Cspan%20class%3D%22hljs-attr%22%3Edata7%3C%2Fspan%3E%3A%20%3Cspan%20class%3D%22hljs-number%22%3E0%3C%2Fspan%3E%0A%20%20%20%20%7D%0A%20%20%7D%0A%7D%0A%3C%2Fspan%3E%3Cspan%20class%3D%22hljs-tag%22%3E%26lt%3B%2F%3Cspan%20class%3D%22hljs-name%22%3Escript%3C%2Fspan%3E%26gt%3B%3C%2Fspan%3E%0A%3C%2Fcode%3E%3C%2Fpre%3E`)

  const domainMap = {
    'development': 'http://localhost:8080/',
    'production': 'https://vux.li/demos/v2/'
  }

  export default {
    head: {
      title: 'Rater component tutorial | VUX - Vue.js Mobile UI Component Framework',
      meta: [{
        name: 'description',
        content: 'Vue component rater for the VUX framework.'
      }, {
        name: 'keywords',
        content: 'rater, vue-rater, vux-rater, vue mobile components'
      }, {
        property: 'og:title',
        content: 'Rater component tutorial | VUX - Vue.js Mobile UI Component Framework'
      }, {
        property: 'og:description',
        content: 'Vue component rater for the VUX framework.'
      }],
      // https://support.google.com/webmasters/answer/189077?hl=en
      link: [{"rel":"alternate","hreflang":"zh-CN","href":"/zh-CN/components/rater.html"}],
      script: [
        {
          innerHTML:'{"@context":"http://schema.org/","@type":"SoftwareApplication","name":"Vue Component rater","screenshot":"","description":"Vue.js component for VUX","url":"/en/components/rater.html","applicationCategory":"Component","author":{"@type":"Organization","name":"VUX","url":"https://vux.li"},"downloadUrl":"https://vux.li","softwareVersion":"2.9.2","aggregateRating":{"@type":"AggregateRating","ratingValue":5,"reviewCount":12},"operatingSystem":"iOS >= 7, Android >= 4.1","offers":{"@type":"Offer","price":0,"priceCurrency":"USD","availability":"http://schema.org/InStock"}}',
          type: 'application/ld+json'
        }
      ],
      __dangerouslyDisableSanitizers: ['script']
    },
    filters: {
      parseCode (str) {
        return str.replace(/`(.*?)`/g, '<code>$1</code>')
      }
    },
    async mounted () {
      const rs = await Axios.get('https://api.github.com/search/issues?q=repo:airyland/vux%20label:component/' + this.componentName)
      this.issues = rs.data.items
      this.hasReady = true
    },
    watch: {
      async sourceCodeDialogVisibility (val) {
        if (val) {
          await this.$nextTick()
          const mask = document.querySelector('.v-modal')
          mask && mask.addEventListener('click', () => {
            this.sourceCodeDialogVisibility = false
          })
        }
      }
    },
    methods: {
      onCopyError () {
        this.$message({
          type: 'error',
          message: 'copy fail!'
        })
      },
      onCopy () {
        this.$message({
          type: 'success',
          message: 'copy done!'
        })
      },
      showSourceCode () {
        this.sourceCodeDialogVisibility = true
      },
      getTypeHTML (type) {
        type = type || 'String'
        if (/,/.test(type)) {
          const list = type.split(',').map(function (one) {
            return one.replace(/^s+|s+$/g, '')
          }).map(function (one) {
            const type = one ?  one.toLowerCase() : 'string'
            return '<span class="type">' + type + '</span>'
          })
          return list.join('<br>')
        } else {
          type = type ?  type.toLowerCase() : 'string'
          return '<span class="type">' + type + '</span>'
        }
      }
    },
    computed: {
      lang () {
        if (this.$route.path.indexOf('/en/') !== -1) {
          return 'en'
        }
        if (this.$route.path.indexOf('/zh-CN/') !== -1) {
          return 'zh-CN'
        }
        return 'en'
      }
    },
    data () {
      return {
        demos,
        isBeta: false,
        hasReady: false,
        issues: [],
        componentName: 'rater',
        demoCode,
        sourceCodeDialogVisibility: false,
        showQr: false,
        metas: metas,
        gitMetas,
        componentList,
        localImportCode: `import { Rater } from 'vux'

export default {
  components: {
    Rater
  }
}`,
        globalImportCode: `// you can also register globally

import Vue from 'vue'
import { Rater } from 'vux'

Vue.component('rater', Rater)
`,
        needImport: true,
        toc: [],
        domain: domainMap[process.env.NODE_ENV]
      }
    }
  }
  </script>

  <style>
  .component-box {
    position: relative;
  }
  .component-demo {
    position: absolute;
    right: 5px;
    top: 15px;
  }
  .prop-color {
    display: inline-block;
    width: 10px;
    height: 10px;
    border: 1px solid #aaa;
  }
  .changelog-version {
    width: 110px;
    display: inline-block;
  }
  .component-extra-links {
    position: relative;
    font-size: 12px;
  }
  .component-extra-links a {
    padding-right: 10px;
    color: #999;
  }
  </style>
    