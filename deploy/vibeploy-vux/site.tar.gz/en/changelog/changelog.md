---
title: VUX releases | VUX - Vue.js Mobile UI Component Framework
---


# VUX releases
<h2>next (not release yet)</h2>

### Selector
<ul><li><span style="font-size:15px;"><span class="change change-fix">fix</span>  fix the chinese bracket show error when direction=rtl <a href="https://github.com/airyland/vux/issues/2864" target="_blank">#2864</a> </span></li></ul>

### VChart
<ul><li><span style="font-size:15px;"><span class="change change-enhance">enhance</span>  v-point can set size and shape, v-line can set shape</span></li></ul>

<h2><a href="/en/changelog/v2.9.2.html">v2.9.2</a></h2>

### Confirm
<ul><li><span style="font-size:15px;"><span class="change change-feature">feature</span>  Support prop: showCancelButton showConfirmButton <a href="https://github.com/airyland/vux/issues/2795" target="_blank">#2795</a> </span></li></ul>

### DatetimeView
<ul><li><span style="font-size:15px;"><span class="change change-fix">fix</span>  fix render error for DOM not found <a href="https://github.com/airyland/vux/issues/2797" target="_blank">#2797</a> </span></li></ul>

### Range
<ul><li><span style="font-size:15px;"><span class="change change-feature">feature</span>  add on-touchstart and on-touchend events <a href="https://github.com/airyland/vux/issues/2804" target="_blank">#2804</a> </span></li></ul>

### Swiper
<ul><li><span style="font-size:15px;"><span class="change change-fix">fix</span>  fix stuck swipe after setting min-moving-distance <a href="https://github.com/airyland/vux/issues/2773" target="_blank">#2773</a> </span></li><li><span style="font-size:15px;"><span class="change change-fix">fix</span>  fix error for repeat setting data in loop <a href="https://github.com/airyland/vux/issues/2803" target="_blank">#2803</a> </span></li></ul>

### XButton
<ul><li><span style="font-size:15px;"><span class="change change-feature">feature</span>  support styles variable for button <a href="https://github.com/airyland/vux/issues/2748" target="_blank">#2748</a> </span></li></ul>

### XImg
<ul><li><span style="font-size:15px;"><span class="change change-enhance">enhance</span>  Support prop:separator <a href="https://github.com/airyland/vux/issues/2744" target="_blank">#2744</a> </span></li></ul>

### XInput
<ul><li><span style="font-size:15px;"><span class="change change-fix">fix</span>  fix corsor misplce when set mask <a href="https://github.com/airyland/vux/issues/2810" target="_blank">#2810</a> </span></li></ul>

<h2><a href="/en/changelog/v2.9.1.html">v2.9.1</a></h2>

### Alert
<ul><li><span style="font-size:15px;"><span class="change change-feature">feature</span>  add isVisible function for AlertPlugin <a href="https://github.com/airyland/vux/issues/2704" target="_blank">#2704</a> </span></li></ul>

### Confirm
<ul><li><span style="font-size:15px;"><span class="change change-feature">feature</span>  add isVisible function for ConfirmPlugin <a href="https://github.com/airyland/vux/issues/2704" target="_blank">#2704</a> </span></li></ul>

### Loading
<ul><li><span style="font-size:15px;"><span class="change change-feature">feature</span>  add isVisible function for LoadingPlugin <a href="https://github.com/airyland/vux/issues/2704" target="_blank">#2704</a> </span></li><li><span style="font-size:15px;"><span class="change change-fix">fix</span>  fix covered by element when using scroll plugins</span></li></ul>

### Popup
<ul><li><span style="font-size:15px;"><span class="change change-fix">fix</span>  fixed popup has black border on the right <a href="https://github.com/airyland/vux/issues/2651" target="_blank">#2651</a> </span></li></ul>

### Qrcode
<ul><li><span style="font-size:15px;"><span class="change change-fix">fix</span>  fix missing support for Chinese works <a href="https://github.com/airyland/vux/issues/2652" target="_blank">#2652</a> </span></li></ul>

### Tab
<ul><li><span style="font-size:15px;"><span class="change change-fix">fix</span>  fix box-sizing issue <a href="https://github.com/airyland/vux/issues/2621" target="_blank">#2621</a> . thanks to <a href="https://github.com/suncodeer" target="_blank">@suncodeer</a></span></li></ul>

### Toast
<ul><li><span style="font-size:15px;"><span class="change change-feature">feature</span>  add isVisible function for ToastPlugin <a href="https://github.com/airyland/vux/issues/2704" target="_blank">#2704</a> </span></li></ul>

### XCircle
<ul><li><span style="font-size:15px;"><span class="change change-feature">feature</span>  support show percent anticlockwise</span></li></ul>

<h2><a href="/en/changelog/v2.9.0.html">v2.9.0</a></h2>

<h2><a href="/en/changelog/v2.8.1.html">v2.8.1</a></h2>

<h2><a href="/en/changelog/v2.8.0.html">v2.8.0</a></h2>

<h2><a href="/en/changelog/v2.7.9.html">v2.7.9</a></h2>

<h2><a href="/en/changelog/v2.7.8.html">v2.7.8</a></h2>

<h2><a href="/en/changelog/v2.7.7.html">v2.7.7</a></h2>

<h2><a href="/en/changelog/2.7.6.html">2.7.6</a></h2>

<h2><a href="/en/changelog/v2.7.6.html">v2.7.6</a></h2>

<h2><a href="/en/changelog/v2.7.5.html">v2.7.5</a></h2>

<h2><a href="/en/changelog/v2.7.4.html">v2.7.4</a></h2>

<h2><a href="/en/changelog/v2.7.3.html">v2.7.3</a></h2>

<h2><a href="/en/changelog/v2.7.2.html">v2.7.2</a></h2>

<h2><a href="/en/changelog/v2.7.1.html">v2.7.1</a></h2>

<h2><a href="/en/changelog/v2.7.0.html">v2.7.0</a></h2>

<h2><a href="/en/changelog/v2.6.5.html">v2.6.5</a></h2>

<h2><a href="/en/changelog/v2.6.4.html">v2.6.4</a></h2>

<h2><a href="/en/changelog/v2.6.3.html">v2.6.3</a></h2>

<h2><a href="/en/changelog/v2.6.2.html">v2.6.2</a></h2>

<h2><a href="/en/changelog/v2.6.1.html">v2.6.1</a></h2>

<h2><a href="/en/changelog/v2.6.0.html">v2.6.0</a></h2>

<h2><a href="/en/changelog/v2.5.12.html">v2.5.12</a></h2>

<h2><a href="/en/changelog/v2.5.11.html">v2.5.11</a></h2>

<h2><a href="/en/changelog/v2.5.10.html">v2.5.10</a></h2>

<h2><a href="/en/changelog/v2.5.9.html">v2.5.9</a></h2>

<h2><a href="/en/changelog/v2.5.8.html">v2.5.8</a></h2>

<h2><a href="/en/changelog/v2.5.7.html">v2.5.7</a></h2>

<h2><a href="/en/changelog/v2.5.6.html">v2.5.6</a></h2>

<h2><a href="/en/changelog/v2.5.5.html">v2.5.5</a></h2>

<h2><a href="/en/changelog/v2.5.4.html">v2.5.4</a></h2>

<h2><a href="/en/changelog/v2.5.3.html">v2.5.3</a></h2>

<h2><a href="/en/changelog/v2.5.2.html">v2.5.2</a></h2>

<h2><a href="/en/changelog/v2.5.1.html">v2.5.1</a></h2>

<h2><a href="/en/changelog/v2.5.0.html">v2.5.0</a></h2>

<h2><a href="/en/changelog/v2.4.1.html">v2.4.1</a></h2>

<h2><a href="/en/changelog/v2.4.0.html">v2.4.0</a></h2>

<h2><a href="/en/changelog/v2.3.8.html">v2.3.8</a></h2>

<h2><a href="/en/changelog/v2.3.7.html">v2.3.7</a></h2>

<h2><a href="/en/changelog/v2.3.6.html">v2.3.6</a></h2>

<h2><a href="/en/changelog/v2.3.5.html">v2.3.5</a></h2>

<h2><a href="/en/changelog/v2.3.4.html">v2.3.4</a></h2>

<h2><a href="/en/changelog/v2.3.3.html">v2.3.3</a></h2>

<h2><a href="/en/changelog/v2.3.2.html">v2.3.2</a></h2>

<h2><a href="/en/changelog/v2.3.1.html">v2.3.1</a></h2>

<h2><a href="/en/changelog/v2.2.2.html">v2.2.2</a></h2>

<h2><a href="/en/changelog/v2.2.1.html">v2.2.1</a></h2>

<h2><a href="/en/changelog/v2.2.1-rc.8.html">v2.2.1-rc.8</a></h2>

<h2><a href="/en/changelog/v2.2.1-rc.7.html">v2.2.1-rc.7</a></h2>

<h2><a href="/en/changelog/v2.2.1-rc.6.html">v2.2.1-rc.6</a></h2>

<h2><a href="/en/changelog/v2.2.1-rc.4.html">v2.2.1-rc.4</a></h2>

<h2><a href="/en/changelog/v2.2.1-rc.3.html">v2.2.1-rc.3</a></h2>

<h2><a href="/en/changelog/v2.2.1-rc.2.html">v2.2.1-rc.2</a></h2>

<h2><a href="/en/changelog/v2.2.1-rc.1.html">v2.2.1-rc.1</a></h2>

<h2><a href="/en/changelog/v2.2.0.html">v2.2.0</a></h2>

<h2><a href="/en/changelog/v2.1.1-rc.14.html">v2.1.1-rc.14</a></h2>

<h2><a href="/en/changelog/v2.1.1-rc.13.html">v2.1.1-rc.13</a></h2>

<h2><a href="/en/changelog/v2.1.1-rc.12.html">v2.1.1-rc.12</a></h2>

<h2><a href="/en/changelog/v2.1.1-rc.11.html">v2.1.1-rc.11</a></h2>

<h2><a href="/en/changelog/v2.1.1-rc.10.html">v2.1.1-rc.10</a></h2>

<h2><a href="/en/changelog/v2.1.1-rc.9.html">v2.1.1-rc.9</a></h2>

<h2><a href="/en/changelog/v2.1.1-rc.8.html">v2.1.1-rc.8</a></h2>

<h2><a href="/en/changelog/v2.1.1-rc.7.html">v2.1.1-rc.7</a></h2>

<h2><a href="/en/changelog/v2.1.1-rc.6.html">v2.1.1-rc.6</a></h2>

<h2><a href="/en/changelog/v2.1.1-rc.5.html">v2.1.1-rc.5</a></h2>

<h2><a href="/en/changelog/v2.1.1-rc.4.html">v2.1.1-rc.4</a></h2>

<h2><a href="/en/changelog/v2.1.1-rc.3.html">v2.1.1-rc.3</a></h2>

<h2><a href="/en/changelog/v2.1.1-rc.2.html">v2.1.1-rc.2</a></h2>

<h2><a href="/en/changelog/v2.1.1-rc.1.html">v2.1.1-rc.1</a></h2>

<h2><a href="/en/changelog/v2.1.0.html">v2.1.0</a></h2>

<h2><a href="/en/changelog/v2.1.0-rc.51.html">v2.1.0-rc.51</a></h2>

<h2><a href="/en/changelog/v2.1.0-rc.50.html">v2.1.0-rc.50</a></h2>

<h2><a href="/en/changelog/v2.1.0-rc.49.html">v2.1.0-rc.49</a></h2>

<h2><a href="/en/changelog/v2.1.0-rc.48.html">v2.1.0-rc.48</a></h2>

<h2><a href="/en/changelog/v2.1.0-rc.47.html">v2.1.0-rc.47</a></h2>

<h2><a href="/en/changelog/v2.1.0-rc.46.html">v2.1.0-rc.46</a></h2>

<h2><a href="/en/changelog/v2.0.14.html">v2.0.14</a></h2>

<h2><a href="/en/changelog/v2.0.1.html">v2.0.1</a></h2>

<h2><a href="/en/changelog/v2.0.0.html">v2.0.0</a></h2>

