---
title: VUX Next released | VUX - Vue.js Mobile UI Component Framework
---


# VUX Next released
<h2><a href="/en/components/selector.html">Selector</a></h2>
<ul><li>[fix] fix the chinese bracket show error when direction=rtl #2864</li>
</ul>
<h2><a href="/en/components/v-chart.html">VChart</a></h2>
<ul><li>[enhance] v-point can set size and shape, v-line can set shape</li>
</ul>