
---
title: faq | VUX - Vue.js Mobile UI Component Framework
---

# faq
  
  * <router-link to="/en/faq/$t-is-not-defined.html">$t is not defined</router-link>
    
  * <router-link to="/en/faq/can-vux-used-in-weapp.html">VUX 能否在微信小程序里使用</router-link>
    
  * <router-link to="/en/faq/cannot-resolve-inline-desc.html">Can't resolve '../inline-desc' in</router-link>
    
  * <router-link to="/en/faq/difference-between-vux-template-and-webpack-template.html">vux2 和 Vue 官方 webpack 模板区别是什么？</router-link>
    
  * <router-link to="/en/faq/document-framework.html">文档是用什么工具编写的？</router-link>
    
  * <router-link to="/en/faq/does-vux-support-weex.html">Does VUX support weex</router-link>
    
  * <router-link to="/en/faq/dupicate-style.html">样式冗余</router-link>
    
  * <router-link to="/en/faq/is-vux-wechat-official-project.html">VUX 是否为微信团队项目</router-link>
    
  * <router-link to="/en/faq/Uncaught-SyntaxError-Unexpected-token-export.html">Uncaught SyntaxError: Unexpected token export</router-link>
    
  * <router-link to="/en/faq/vux-build-issue.html">VUX 打包体积过大</router-link>
    
  * <router-link to="/en/faq/vux-server-render-support.html">VUX 服务端渲染</router-link>
    
  * <router-link to="/en/faq/what-is-vux-virtual-component.html">什么是虚拟组件(virtual component)</router-link>
    
  * <router-link to="/en/faq/why-cannot-i-import-all-components.html">为什么不能引入全部组件</router-link>
    
  * <router-link to="/en/faq/why-cannot-i-use-vux-with-cdn.html">为什么不能直接引用 cdn 链接</router-link>
    
  * <router-link to="/en/faq/why-close-my-issue.html">为什么作者直接关闭了我提的 issue</router-link>
    
  * <router-link to="/en/faq/why-delete-my-issue-comment.html">为什么作者直接删除了我在 issue 下的评论</router-link>
    
  * <router-link to="/en/faq/why-use-vue-file-for-distribution.html">为什么使用 .vue 源码分发而不是 js 文件</router-link>
    
  * <router-link to="/en/faq/why-use-x-prefix-for-components.html">为什么部分组件要加`x-`前缀</router-link>
    
  * <router-link to="/en/faq/will-vux-stop-maintaining.html">担心停止维护</router-link>
    